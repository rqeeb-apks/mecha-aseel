package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import org.junit.Assert.assertEquals
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("دكتور الميكاترونكس", appName)
  }

  @Test
  fun `verify mechatronics reference table content`() {
    val table = com.example.data.model.MechatronicsCurriculum.mechatronicsReferenceTable
    org.junit.Assert.assertTrue("Table should have at least 15 mechatronics items", table.size >= 15)
    
    val force = table.firstOrNull { it.id == "force" }
    org.junit.Assert.assertNotNull(force)
    assertEquals("[M L T⁻²]", force?.dimensionFormula)
    assertEquals("نيوتن (N)", force?.siUnit)

    val siUnits = com.example.data.model.MechatronicsCurriculum.siBaseUnitsList
    assertEquals(7, siUnits.size)

    val prefixes = com.example.data.model.MechatronicsCurriculum.engineeringPrefixesList
    org.junit.Assert.assertTrue(prefixes.any { it.symbol == "μ" })
    org.junit.Assert.assertTrue(prefixes.any { it.symbol == "k" })
  }

  @Test
  fun `verify subscription payment number and fee`() {
    assertEquals("6710654", com.example.data.model.MechatronicsCurriculum.paymentNumber)
    assertEquals("10 ريال يمني شهرياً", com.example.data.model.MechatronicsCurriculum.subscriptionFee)
  }

  @Test
  fun `verify daily study offline explanation generation`() {
    val service = com.example.data.network.GeminiApiService()
    val explanation = service.generateOfflineDailyStudyExplanation("تحكم PID في محركات السيرفو", hasImage = true)
    org.junit.Assert.assertTrue(explanation.contains("تحكم PID") || explanation.contains("شرح"))
    org.junit.Assert.assertTrue(explanation.contains("القوانين والمعادلات") || explanation.contains("الفكرة الجوهرية"))
  }
}
