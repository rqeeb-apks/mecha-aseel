package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CompareArrows
import androidx.compose.material.icons.filled.Functions
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.PhysicalDimension
import com.example.ui.MechatronicsViewModel
import com.example.ui.theme.CircuitGreen
import com.example.ui.theme.TechCyanLight
import com.example.ui.theme.TechCyanPrimary
import com.example.ui.theme.TechGoldAccent
import com.example.ui.theme.TechNavyCard
import com.example.ui.theme.TechNavyDark
import com.example.ui.theme.TechNavyElevated
import com.example.ui.theme.TechNavySurface
import com.example.ui.theme.TextPrimaryDark
import com.example.ui.theme.TextSecondaryDark

@Composable
fun PhysicsDimensionsScreen(
    viewModel: MechatronicsViewModel,
    modifier: Modifier = Modifier
) {
    var selectedTab by remember { mutableIntStateOf(0) }
    val tabs = listOf("المرجع السريع والجدول ⚡", "الأبعاد والتطبيقات [M L T]", "محول الوحدات")

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(TechNavyDark)
    ) {
        // Top Header
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(TechNavySurface)
                .padding(horizontal = 16.dp, vertical = 14.dp)
        ) {
            Text(
                text = "التحويلات والأبعاد الفيزيائية",
                style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold),
                color = TextPrimaryDark
            )
            Text(
                text = "الجدول البحثي الشامل لمعادلات الأبعاد الهندسية والتحويل المباشر بين الوحدات",
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondaryDark
            )

            Spacer(modifier = Modifier.height(12.dp))

            TabRow(
                selectedTabIndex = selectedTab,
                containerColor = TechNavyCard,
                contentColor = TechCyanPrimary,
                indicator = { tabPositions ->
                    TabRowDefaults.SecondaryIndicator(
                        Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                        color = TechCyanPrimary
                    )
                },
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .border(1.dp, TechNavyElevated, RoundedCornerShape(12.dp))
            ) {
                tabs.forEachIndexed { index, title ->
                    Tab(
                        selected = selectedTab == index,
                        onClick = { selectedTab = index },
                        text = {
                            Text(
                                text = title,
                                fontWeight = if (selectedTab == index) FontWeight.Bold else FontWeight.Normal,
                                color = if (selectedTab == index) TechCyanPrimary else TextSecondaryDark,
                                fontSize = 12.sp
                            )
                        }
                    )
                }
            }
        }

        when (selectedTab) {
            0 -> QuickReferenceScreen(viewModel = viewModel)
            1 -> DimensionsTabContent(viewModel = viewModel)
            2 -> UnitConverterTabContent(viewModel = viewModel)
        }
    }
}

@Composable
fun DimensionsTabContent(
    viewModel: MechatronicsViewModel
) {
    val search by viewModel.dimensionSearch.collectAsState()
    val allDimensions = viewModel.allDimensions

    val filtered = allDimensions.filter { dim ->
        if (search.isBlank()) true
        else {
            dim.nameAr.contains(search, ignoreCase = true) ||
                    dim.nameEn.contains(search, ignoreCase = true) ||
                    dim.symbol.contains(search, ignoreCase = true) ||
                    dim.dimensionFormula.contains(search, ignoreCase = true) ||
                    dim.siUnit.contains(search, ignoreCase = true)
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp)
    ) {
        item {
            OutlinedTextField(
                value = search,
                onValueChange = { viewModel.setDimensionSearch(it) },
                placeholder = { Text("ابحث في الكميات الفيزيائية (عزم، ضغط، قدرة...)", color = TextSecondaryDark) },
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Default.Search,
                        contentDescription = null,
                        tint = TechCyanPrimary
                    )
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("dimensions_search_input"),
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = TechNavySurface,
                    unfocusedContainerColor = TechNavySurface,
                    focusedBorderColor = TechCyanPrimary,
                    unfocusedBorderColor = TechNavyCard,
                    focusedTextColor = TextPrimaryDark,
                    unfocusedTextColor = TextPrimaryDark
                ),
                singleLine = true
            )
            Spacer(modifier = Modifier.height(14.dp))
        }

        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(TechNavySurface)
                    .border(1.dp, TechNavyCard, RoundedCornerShape(12.dp))
                    .padding(12.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Info,
                        contentDescription = null,
                        tint = TechGoldAccent,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "صيغة الأبعاد تعبر عن الكميات المشتقة بدلالة الكميات الأساسية: الكتلة [M]، الطول [L]، الزمن [T]، التيار الكهربائي [I].",
                        style = MaterialTheme.typography.bodySmall.copy(fontSize = 12.sp, lineHeight = 18.sp),
                        color = TextPrimaryDark
                    )
                }
            }
            Spacer(modifier = Modifier.height(12.dp))
        }

        items(filtered) { dim ->
            PhysicalDimensionCard(dim = dim)
            Spacer(modifier = Modifier.height(10.dp))
        }
    }
}

@Composable
fun PhysicalDimensionCard(
    dim: PhysicalDimension
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("dimension_card_${dim.symbol}"),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = TechNavySurface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "${dim.nameAr} (${dim.symbol})",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = TextPrimaryDark
                    )
                    Text(
                        text = dim.nameEn,
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondaryDark
                    )
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(TechNavyDark)
                        .border(1.dp, TechCyanPrimary, RoundedCornerShape(8.dp))
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = dim.dimensionFormula,
                        style = MaterialTheme.typography.titleSmall.copy(
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold
                        ),
                        color = TechCyanLight
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "وحدة القياس SI:",
                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                    color = TechGoldAccent
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = dim.siUnit,
                    style = MaterialTheme.typography.bodySmall,
                    color = TextPrimaryDark
                )
            }

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = "معادلة الاشتقاق: ${dim.derivation}",
                style = MaterialTheme.typography.bodySmall,
                color = Color(0xFFCAD3C8)
            )

            Spacer(modifier = Modifier.height(6.dp))

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(TechNavyCard)
                    .padding(8.dp)
            ) {
                Text(
                    text = "تطبيق الميكاترونكس: ${dim.mechatronicsApplication}",
                    style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                    color = TechCyanLight
                )
            }
        }
    }
}

@Composable
fun UnitConverterTabContent(
    viewModel: MechatronicsViewModel
) {
    val categories = viewModel.categories
    val selectedCategory by viewModel.selectedCategory.collectAsState()
    val fromUnit by viewModel.fromUnit.collectAsState()
    val toUnit by viewModel.toUnit.collectAsState()
    val inputValue by viewModel.inputValue.collectAsState()
    val convertedValue by viewModel.convertedValue.collectAsState()

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp)
    ) {
        // Category Chips
        item {
            Text(
                text = "اختر مجال التحويل الهندسي:",
                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                color = TechGoldAccent
            )
            Spacer(modifier = Modifier.height(6.dp))

            LazyRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(categories) { cat ->
                    val isSelected = cat.id == selectedCategory.id
                    FilterChip(
                        selected = isSelected,
                        onClick = { viewModel.selectCategory(cat) },
                        label = { Text(cat.nameAr) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = TechCyanPrimary,
                            selectedLabelColor = TechNavyDark,
                            containerColor = TechNavySurface,
                            labelColor = TextPrimaryDark
                        ),
                        shape = RoundedCornerShape(10.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
        }

        // Converter Card
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("unit_converter_card"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = TechNavySurface),
                elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(18.dp)
                ) {
                    Text(
                        text = "التحويل في ${selectedCategory.nameAr} (${selectedCategory.nameEn})",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = TechCyanPrimary
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    // Input Field
                    Text(
                        text = "القيمة المدخلة:",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextSecondaryDark
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    OutlinedTextField(
                        value = inputValue,
                        onValueChange = { viewModel.setInputValue(it) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("converter_input_field"),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = TechNavyDark,
                            unfocusedContainerColor = TechNavyDark,
                            focusedBorderColor = TechCyanPrimary,
                            unfocusedBorderColor = TechNavyCard,
                            focusedTextColor = TextPrimaryDark,
                            unfocusedTextColor = TextPrimaryDark
                        ),
                        singleLine = true
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    // From Unit selector
                    Text(
                        text = "من وحدة:",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextSecondaryDark
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        items(selectedCategory.units) { u ->
                            val isSelected = u.symbol == fromUnit.symbol
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (isSelected) TechCyanPrimary else TechNavyCard)
                                    .clickable { viewModel.setFromUnit(u) }
                                    .padding(horizontal = 10.dp, vertical = 6.dp)
                            ) {
                                Text(
                                    text = u.name,
                                    fontSize = 12.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                    color = if (isSelected) TechNavyDark else TextPrimaryDark
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Swap or Arrow indicator
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(TechNavyElevated),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.CompareArrows,
                                contentDescription = "تحويل",
                                tint = TechGoldAccent,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // To Unit selector
                    Text(
                        text = "إلى وحدة:",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextSecondaryDark
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        items(selectedCategory.units) { u ->
                            val isSelected = u.symbol == toUnit.symbol
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (isSelected) CircuitGreen else TechNavyCard)
                                    .clickable { viewModel.setToUnit(u) }
                                    .padding(horizontal = 10.dp, vertical = 6.dp)
                            ) {
                                Text(
                                    text = u.name,
                                    fontSize = 12.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                    color = if (isSelected) TechNavyDark else TextPrimaryDark
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(18.dp))

                    // Converted Output Box
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(TechNavyDark)
                            .border(1.dp, CircuitGreen.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                            .padding(16.dp)
                    ) {
                        Column {
                            Text(
                                text = "النتيجة المحسوبة:",
                                style = MaterialTheme.typography.labelSmall,
                                color = CircuitGreen
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "$convertedValue ${toUnit.symbol}",
                                style = MaterialTheme.typography.headlineMedium.copy(
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.ExtraBold
                                ),
                                color = TextPrimaryDark
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "$inputValue ${fromUnit.symbol} = $convertedValue ${toUnit.symbol}",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondaryDark
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
        }

        // Standard Conversion Multipliers Reference Table
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = TechNavySurface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "جدول معاملات التحويل بالنسبة للوحدة الأساسية (${selectedCategory.baseUnit}):",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                        color = TechGoldAccent
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    selectedCategory.units.forEach { u ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "1 ${u.name}",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextPrimaryDark
                            )
                            Text(
                                text = "= ${u.factorToBase} ${selectedCategory.baseUnit}",
                                style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace),
                                color = TechCyanLight
                            )
                        }
                    }
                }
            }
        }
    }
}
