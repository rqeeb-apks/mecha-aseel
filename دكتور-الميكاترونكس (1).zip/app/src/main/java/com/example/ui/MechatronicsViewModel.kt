package com.example.ui

import android.app.Application
import android.content.Context
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.OpenableColumns
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.db.AppDatabase
import com.example.data.db.BookmarkedLessonEntity
import com.example.data.db.SavedSummaryEntity
import com.example.data.db.StudentProfileEntity
import com.example.data.model.AcademicYear
import com.example.data.model.ConversionUnit
import com.example.data.model.DimensionCategory
import com.example.data.model.EngineeringPrefixItem
import com.example.data.model.Lesson
import com.example.data.model.MechatronicsCurriculum
import com.example.data.model.MechatronicsReferenceItem
import com.example.data.model.PhysicalDimension
import com.example.data.model.SIBaseUnitItem
import com.example.data.model.Subject
import com.example.data.model.UnitCategory
import com.example.data.network.GeminiApiService
import com.example.data.repository.MechatronicsRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlin.math.PI

sealed interface AiOperationState {
    object Idle : AiOperationState
    object Loading : AiOperationState
    data class Success(val content: String, val isImageResult: Boolean = false) : AiOperationState
    data class Error(val message: String) : AiOperationState
}

class MechatronicsViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: MechatronicsRepository
    private val geminiService = GeminiApiService()

    init {
        val db = AppDatabase.getDatabase(application)
        repository = MechatronicsRepository(db.mechatronicsDao())
    }

    val studentProfile: StateFlow<StudentProfileEntity?> = repository.studentProfile
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val savedSummaries: StateFlow<List<SavedSummaryEntity>> = repository.summaries
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val bookmarkedLessons: StateFlow<List<BookmarkedLessonEntity>> = repository.bookmarks
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Curriculum Navigation State
    private val _selectedYearId = MutableStateFlow(1)
    val selectedYearId = _selectedYearId.asStateFlow()

    private val _selectedSubject = MutableStateFlow<Subject?>(null)
    val selectedSubject = _selectedSubject.asStateFlow()

    private val _selectedLesson = MutableStateFlow<Lesson?>(null)
    val selectedLesson = _selectedLesson.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery = _searchQuery.asStateFlow()

    fun selectYear(yearId: Int) {
        _selectedYearId.value = yearId
        _selectedSubject.value = null
        _selectedLesson.value = null
    }

    fun selectSubject(subject: Subject?) {
        _selectedSubject.value = subject
        _selectedLesson.value = null
    }

    fun selectLesson(lesson: Lesson?) {
        _selectedLesson.value = lesson
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun toggleBookmark(lesson: Lesson, subject: Subject, yearId: Int, isBookmarked: Boolean) {
        viewModelScope.launch {
            repository.toggleBookmark(
                lessonId = lesson.id,
                subjectId = subject.id,
                yearId = yearId,
                title = lesson.title,
                arabicTitle = lesson.arabicTitle,
                currentlyBookmarked = isBookmarked
            )
        }
    }

    // Physical Unit Converter State
    val categories: List<UnitCategory> = MechatronicsCurriculum.unitCategories
    private val _selectedCategory = MutableStateFlow(categories.first())
    val selectedCategory = _selectedCategory.asStateFlow()

    private val _fromUnit = MutableStateFlow(categories.first().units.first())
    val fromUnit = _fromUnit.asStateFlow()

    private val _toUnit = MutableStateFlow(categories.first().units.getOrElse(1) { categories.first().units.first() })
    val toUnit = _toUnit.asStateFlow()

    private val _inputValue = MutableStateFlow("1.0")
    val inputValue = _inputValue.asStateFlow()

    private val _convertedValue = MutableStateFlow("")
    val convertedValue = _convertedValue.asStateFlow()

    init {
        computeUnitConversion()
    }

    fun selectCategory(category: UnitCategory) {
        _selectedCategory.value = category
        _fromUnit.value = category.units.first()
        _toUnit.value = category.units.getOrElse(1) { category.units.first() }
        computeUnitConversion()
    }

    fun setFromUnit(unit: ConversionUnit) {
        _fromUnit.value = unit
        computeUnitConversion()
    }

    fun setToUnit(unit: ConversionUnit) {
        _toUnit.value = unit
        computeUnitConversion()
    }

    fun setInputValue(value: String) {
        _inputValue.value = value
        computeUnitConversion()
    }

    private fun computeUnitConversion() {
        val num = _inputValue.value.toDoubleOrNull()
        if (num == null) {
            _convertedValue.value = "---"
            return
        }
        val fromFactor = _fromUnit.value.factorToBase
        val toFactor = _toUnit.value.factorToBase
        val inBase = num * fromFactor
        val result = inBase / toFactor
        _convertedValue.value = String.format("%.4f", result).trimEnd('0').trimEnd('.')
    }

    // Physical Dimensions State
    val allDimensions: List<PhysicalDimension> = MechatronicsCurriculum.physicalDimensions
    private val _dimensionSearch = MutableStateFlow("")
    val dimensionSearch = _dimensionSearch.asStateFlow()

    fun setDimensionSearch(query: String) {
        _dimensionSearch.value = query
    }

    // Quick Reference Searchable Matrix Table State
    val referenceTable: List<MechatronicsReferenceItem> = MechatronicsCurriculum.mechatronicsReferenceTable
    val siBaseUnits: List<SIBaseUnitItem> = MechatronicsCurriculum.siBaseUnitsList
    val engineeringPrefixes: List<EngineeringPrefixItem> = MechatronicsCurriculum.engineeringPrefixesList

    private val _referenceSearch = MutableStateFlow("")
    val referenceSearch = _referenceSearch.asStateFlow()

    private val _selectedRefCategory = MutableStateFlow(DimensionCategory.ALL)
    val selectedRefCategory = _selectedRefCategory.asStateFlow()

    private val _isTableView = MutableStateFlow(true)
    val isTableView = _isTableView.asStateFlow()

    private val _activeDetailItem = MutableStateFlow<MechatronicsReferenceItem?>(null)
    val activeDetailItem = _activeDetailItem.asStateFlow()

    fun setReferenceSearch(query: String) {
        _referenceSearch.value = query
    }

    fun setReferenceCategory(category: DimensionCategory) {
        _selectedRefCategory.value = category
    }

    fun toggleViewMode() {
        _isTableView.value = !_isTableView.value
    }

    fun selectDetailItem(item: MechatronicsReferenceItem?) {
        _activeDetailItem.value = item
    }

    // Engineering Math & Circuits Solvers State
    // 1. Ohm's Law Solver (V, I, R, P)
    private val _ohmVoltage = MutableStateFlow("12.0")
    val ohmVoltage = _ohmVoltage.asStateFlow()

    private val _ohmCurrent = MutableStateFlow("0.5")
    val ohmCurrent = _ohmCurrent.asStateFlow()

    private val _ohmResistance = MutableStateFlow("24.0")
    val ohmResistance = _ohmResistance.asStateFlow()

    private val _ohmPower = MutableStateFlow("6.0")
    val ohmPower = _ohmPower.asStateFlow()

    fun calculateOhmFromVI(voltageStr: String, currentStr: String) {
        _ohmVoltage.value = voltageStr
        _ohmCurrent.value = currentStr
        val v = voltageStr.toDoubleOrNull() ?: 0.0
        val i = currentStr.toDoubleOrNull() ?: 0.0
        if (i > 0) {
            _ohmResistance.value = String.format("%.2f", v / i)
            _ohmPower.value = String.format("%.2f", v * i)
        }
    }

    fun calculateOhmFromVR(voltageStr: String, resistanceStr: String) {
        _ohmVoltage.value = voltageStr
        _ohmResistance.value = resistanceStr
        val v = voltageStr.toDoubleOrNull() ?: 0.0
        val r = resistanceStr.toDoubleOrNull() ?: 0.0
        if (r > 0) {
            val i = v / r
            _ohmCurrent.value = String.format("%.3f", i)
            _ohmPower.value = String.format("%.2f", v * i)
        }
    }

    // 2. RC Filter Solver
    private val _rcResistance = MutableStateFlow("10.0") // kOhm
    val rcResistance = _rcResistance.asStateFlow()

    private val _rcCapacitance = MutableStateFlow("100.0") // nF
    val rcCapacitance = _rcCapacitance.asStateFlow()

    private val _rcTimeConstant = MutableStateFlow("1.0 ms")
    val rcTimeConstant = _rcTimeConstant.asStateFlow()

    private val _rcCutoffFreq = MutableStateFlow("159.15 Hz")
    val rcCutoffFreq = _rcCutoffFreq.asStateFlow()

    fun calculateRcFilter(rKohmStr: String, cNfStr: String) {
        _rcResistance.value = rKohmStr
        _rcCapacitance.value = cNfStr
        val r = (rKohmStr.toDoubleOrNull() ?: 0.0) * 1000.0 // Ohms
        val c = (cNfStr.toDoubleOrNull() ?: 0.0) * 1e-9 // Farads
        if (r > 0 && c > 0) {
            val tau = r * c // seconds
            val fc = 1.0 / (2.0 * PI * tau) // Hz
            _rcTimeConstant.value = if (tau < 0.001) String.format("%.2f µs", tau * 1e6) else String.format("%.2f ms", tau * 1e3)
            _rcCutoffFreq.value = if (fc >= 1000) String.format("%.2f kHz", fc / 1000.0) else String.format("%.2f Hz", fc)
        }
    }

    // 3. Op-Amp Gain Solver
    private val _opAmpRf = MutableStateFlow("100.0") // kOhm
    val opAmpRf = _opAmpRf.asStateFlow()

    private val _opAmpRin = MutableStateFlow("10.0") // kOhm
    val opAmpRin = _opAmpRin.asStateFlow()

    private val _opAmpInvertingGain = MutableStateFlow("-10.00")
    val opAmpInvertingGain = _opAmpInvertingGain.asStateFlow()

    private val _opAmpNonInvertingGain = MutableStateFlow("+11.00")
    val opAmpNonInvertingGain = _opAmpNonInvertingGain.asStateFlow()

    fun calculateOpAmp(rfStr: String, rinStr: String) {
        _opAmpRf.value = rfStr
        _opAmpRin.value = rinStr
        val rf = rfStr.toDoubleOrNull() ?: 0.0
        val rin = rinStr.toDoubleOrNull() ?: 0.0
        if (rin > 0) {
            val inv = -rf / rin
            val nonInv = 1.0 + (rf / rin)
            _opAmpInvertingGain.value = String.format("%.2f", inv)
            _opAmpNonInvertingGain.value = String.format("+%.2f", nonInv)
        }
    }

    // 4. Stepper Motor & Gear Ratio Solver
    private val _stepperAngle = MutableStateFlow("1.8") // degrees
    val stepperAngle = _stepperAngle.asStateFlow()

    private val _stepperFreq = MutableStateFlow("1000") // Hz
    val stepperFreq = _stepperFreq.asStateFlow()

    private val _gearRatio = MutableStateFlow("10.0") // 10:1
    val gearRatio = _gearRatio.asStateFlow()

    private val _stepperSpeedRpm = MutableStateFlow("300.0 RPM")
    val stepperSpeedRpm = _stepperSpeedRpm.asStateFlow()

    private val _outputSpeedRpm = MutableStateFlow("30.0 RPM")
    val outputSpeedRpm = _outputSpeedRpm.asStateFlow()

    fun calculateStepper(angleStr: String, freqStr: String, ratioStr: String) {
        _stepperAngle.value = angleStr
        _stepperFreq.value = freqStr
        _gearRatio.value = ratioStr
        val angle = angleStr.toDoubleOrNull() ?: 1.8
        val freq = freqStr.toDoubleOrNull() ?: 1000.0
        val ratio = ratioStr.toDoubleOrNull() ?: 1.0
        if (angle > 0 && ratio > 0) {
            val stepsPerRev = 360.0 / angle
            val motorRpm = (freq * 60.0) / stepsPerRev
            val outputRpm = motorRpm / ratio
            _stepperSpeedRpm.value = String.format("%.1f RPM", motorRpm)
            _outputSpeedRpm.value = String.format("%.1f RPM", outputRpm)
        }
    }

    // AI Doctor Operations State
    private val _aiState = MutableStateFlow<AiOperationState>(AiOperationState.Idle)
    val aiState = _aiState.asStateFlow()

    private val _lectureInputText = MutableStateFlow("")
    val lectureInputText = _lectureInputText.asStateFlow()

    private val _uploadedImageBitmap = MutableStateFlow<Bitmap?>(null)
    val uploadedImageBitmap = _uploadedImageBitmap.asStateFlow()

    private val _imageNotes = MutableStateFlow("")
    val imageNotes = _imageNotes.asStateFlow()

    fun setLectureInputText(text: String) {
        _lectureInputText.value = text
    }

    fun setUploadedImage(bitmap: Bitmap?) {
        _uploadedImageBitmap.value = bitmap
    }

    fun setImageNotes(notes: String) {
        _imageNotes.value = notes
    }

    fun resetAiState() {
        _aiState.value = AiOperationState.Idle
    }

    fun summarizeLecture(mode: String = "شامل") {
        val text = _lectureInputText.value.trim()
        if (text.isBlank()) {
            _aiState.value = AiOperationState.Error("يرجى إدخال نص المحاضرة أو الملخص أولاً")
            return
        }
        _aiState.value = AiOperationState.Loading
        viewModelScope.launch {
            try {
                val result = geminiService.summarizeLectureText(text, mode)
                _aiState.value = AiOperationState.Success(result, isImageResult = false)
                // Save to Room DB
                val title = if (text.length > 30) text.take(30) + "..." else text
                repository.saveSummary(
                    title = "ملخص: $title",
                    type = "TEXT",
                    snippet = text.take(100),
                    result = result
                )
            } catch (e: Exception) {
                _aiState.value = AiOperationState.Error("حدث خطأ أثناء التلخيص: ${e.localizedMessage}")
            }
        }
    }

    fun explainImage() {
        val bitmap = _uploadedImageBitmap.value
        if (bitmap == null) {
            _aiState.value = AiOperationState.Error("يرجى اختيار صورة للدرس أولاً")
            return
        }
        _aiState.value = AiOperationState.Loading
        viewModelScope.launch {
            try {
                val result = geminiService.explainLessonImage(bitmap, _imageNotes.value)
                _aiState.value = AiOperationState.Success(result, isImageResult = true)
                repository.saveSummary(
                    title = "شرح صورة: ${if (_imageNotes.value.isNotBlank()) _imageNotes.value.take(25) else "مخطط ميكاترونكس"}",
                    type = "IMAGE",
                    snippet = if (_imageNotes.value.isNotBlank()) _imageNotes.value else "صورة مسألة/دائرة كهربائية",
                    result = result
                )
            } catch (e: Exception) {
                _aiState.value = AiOperationState.Error("حدث خطأ أثناء معالجة الصورة: ${e.localizedMessage}")
            }
        }
    }

    fun deleteSummary(id: Long) {
        viewModelScope.launch {
            repository.deleteSummary(id)
        }
    }

    // Service: "ماذا درست اليوم؟" (Daily Study Service)
    private val _dailyStudyText = MutableStateFlow("")
    val dailyStudyText = _dailyStudyText.asStateFlow()

    private val _dailyStudyImageBitmap = MutableStateFlow<Bitmap?>(null)
    val dailyStudyImageBitmap = _dailyStudyImageBitmap.asStateFlow()

    private val _dailyStudyVideoUri = MutableStateFlow<Uri?>(null)
    val dailyStudyVideoUri = _dailyStudyVideoUri.asStateFlow()

    private val _dailyStudyVideoThumbnail = MutableStateFlow<Bitmap?>(null)
    val dailyStudyVideoThumbnail = _dailyStudyVideoThumbnail.asStateFlow()

    private val _dailyStudyVideoName = MutableStateFlow("")
    val dailyStudyVideoName = _dailyStudyVideoName.asStateFlow()

    private val _dailyStudySubject = MutableStateFlow("تحكم آلي وروبوتات")
    val dailyStudySubject = _dailyStudySubject.asStateFlow()

    fun setDailyStudyText(text: String) {
        _dailyStudyText.value = text
    }

    fun setDailyStudyImage(bitmap: Bitmap?) {
        _dailyStudyImageBitmap.value = bitmap
    }

    fun setDailyStudySubject(subject: String) {
        _dailyStudySubject.value = subject
    }

    fun setDailyStudyVideo(context: Context, uri: Uri?) {
        _dailyStudyVideoUri.value = uri
        if (uri == null) {
            _dailyStudyVideoThumbnail.value = null
            _dailyStudyVideoName.value = ""
            return
        }

        var fileName = "video_lecture.mp4"
        try {
            context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (nameIndex != -1 && cursor.moveToFirst()) {
                    fileName = cursor.getString(nameIndex)
                }
            }
        } catch (e: Exception) {
            fileName = "فيديو محاضرة.mp4"
        }
        _dailyStudyVideoName.value = fileName

        try {
            val retriever = MediaMetadataRetriever()
            retriever.setDataSource(context, uri)
            val frame = retriever.getFrameAtTime(1000000, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                ?: retriever.frameAtTime
            retriever.release()
            _dailyStudyVideoThumbnail.value = frame
        } catch (e: Exception) {
            _dailyStudyVideoThumbnail.value = null
        }
    }

    fun clearDailyStudyMedia() {
        _dailyStudyImageBitmap.value = null
        _dailyStudyVideoUri.value = null
        _dailyStudyVideoThumbnail.value = null
        _dailyStudyVideoName.value = ""
    }

    fun explainDailyStudy(context: Context) {
        val text = _dailyStudyText.value.trim()
        val image = _dailyStudyImageBitmap.value
        val videoThumb = _dailyStudyVideoThumbnail.value
        val videoName = _dailyStudyVideoName.value

        if (text.isBlank() && image == null && _dailyStudyVideoUri.value == null) {
            _aiState.value = AiOperationState.Error("يرجى إدخال نص الدرس، أو رفع صورة السبورة/المخطط، أو اختيار مقطع فيديو للمحاضرة أولاً")
            return
        }

        _aiState.value = AiOperationState.Loading
        viewModelScope.launch {
            try {
                val mediaNote = buildString {
                    if (image != null) append("صورة سبورة أو مخطط توضيحي. ")
                    if (videoName.isNotBlank()) append("مقطع فيديو مسجل بعنوان: $videoName. ")
                    if (_dailyStudySubject.value.isNotBlank()) append("المساق الأكاديمي: ${_dailyStudySubject.value}.")
                }

                val result = geminiService.explainDailyStudyLesson(
                    topicText = if (text.isNotBlank()) "[$_dailyStudySubject] $text" else "[$_dailyStudySubject] درس اليوم",
                    imageBitmap = image,
                    videoFrameBitmap = videoThumb,
                    mediaNote = mediaNote
                )

                _aiState.value = AiOperationState.Success(result, isImageResult = image != null || videoThumb != null)

                val titleSnippet = if (text.isNotBlank()) {
                    if (text.length > 30) text.take(30) + "..." else text
                } else if (videoName.isNotBlank()) {
                    videoName
                } else {
                    "مخطط درس اليوم"
                }

                repository.saveSummary(
                    title = "ماذا درست اليوم: $titleSnippet",
                    type = "DAILY_STUDY",
                    snippet = "مساق ${_dailyStudySubject.value} - ${if (text.isNotBlank()) text.take(80) else "وسائط مرفقة"}",
                    result = result
                )
            } catch (e: Exception) {
                _aiState.value = AiOperationState.Error("حدث خطأ أثناء تحليل وشرح الدرس: ${e.localizedMessage}")
            }
        }
    }

    // Subscription Management State
    private val _subscriptionMessage = MutableStateFlow<String?>(null)
    val subscriptionMessage = _subscriptionMessage.asStateFlow()

    fun activateSubscription(
        studentName: String,
        studentId: String,
        studentPhone: String,
        paymentMethod: String,
        transactionNumber: String
    ) {
        if (studentName.isBlank() || transactionNumber.isBlank()) {
            _subscriptionMessage.value = "يرجى كتابة اسم الطالب ورقم إشعار الحوالة لتأكيد الاشتراك"
            return
        }
        viewModelScope.launch {
            repository.activateSubscription(
                studentName = studentName.trim(),
                studentId = if (studentId.isBlank()) "EIU-MCE-2026" else studentId.trim(),
                studentPhone = studentPhone.trim(),
                paymentMethod = paymentMethod,
                transactionNumber = transactionNumber.trim()
            )
            _subscriptionMessage.value = "تهانينا يا بشمهندس! تم تفعيل اشتراكك الشهري بنجاح بقيمة 10 ريال يمني."
        }
    }

    fun verifySubscriptionStatus() {
        val current = studentProfile.value
        val now = System.currentTimeMillis()
        if (current == null || !current.isSubscribed) {
            _subscriptionMessage.value = "حالة الاشتراك: غير مفعّل بعد. يرجى إتمام التحويل بمبلغ 10 ريال إلى الرقم 6710654."
        } else if (current.subscriptionExpireDate in 1..<now) {
            _subscriptionMessage.value = "تنبيه: انتهت صلاحية اشتراكك الشهري. يرجى تجديد الاشتراك بمبلغ 10 ريال يمني."
        } else {
            val remainingDays = ((current.subscriptionExpireDate - now) / (1000 * 60 * 60 * 24)).coerceAtLeast(0)
            _subscriptionMessage.value = "فحص ناجح ✓: اشتراكك نشط ومفعّل بالكامل. متبقي $remainingDays يوماً في خطتك الحالية."
        }
    }

    fun renewSubscription(days: Int = 30) {
        viewModelScope.launch {
            val current = studentProfile.value
            repository.activateSubscription(
                studentName = current?.studentName ?: "مهندس ميكاترونكس",
                studentId = current?.studentId ?: "EIU-2026-MCE",
                studentPhone = current?.studentPhone ?: "",
                paymentMethod = current?.paymentMethod ?: "محفظة جيب",
                transactionNumber = "RENEW-${System.currentTimeMillis().toString().takeLast(6)}"
            )
            _subscriptionMessage.value = "تم تجديد الاشتراك بنجاح لشهر إضافي (30 يوماً)! جميع الدروس متاحة."
        }
    }

    fun resetSubscription() {
        viewModelScope.launch {
            repository.resetSubscription()
            _subscriptionMessage.value = "تمت إعادة ضبط حالة الاشتراك للتجربة (غير مفعّل)."
        }
    }

    fun clearSubscriptionMessage() {
        _subscriptionMessage.value = null
    }
}
