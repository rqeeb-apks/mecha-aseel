package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Science
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.AcademicYear
import com.example.data.model.Lesson
import com.example.data.model.MechatronicsCurriculum
import com.example.data.model.Subject
import com.example.ui.MechatronicsViewModel
import com.example.ui.components.SubscriptionBanner
import com.example.ui.theme.CircuitGreen
import com.example.ui.theme.TechCyanLight
import com.example.ui.theme.TechCyanPrimary
import com.example.ui.theme.TechGoldAccent
import com.example.ui.theme.TechNavyCard
import com.example.ui.theme.TechNavyDark
import com.example.ui.theme.TechNavyElevated
import com.example.ui.theme.TechNavySurface
import com.example.ui.theme.TextPrimaryDark
import com.example.ui.theme.TextSecondaryDark

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CoursesScreen(
    viewModel: MechatronicsViewModel,
    onNavigateToSubscription: () -> Unit,
    onSendToAiSummarizer: (String) -> Unit,
    onNavigateToDimensions: () -> Unit = {},
    onNavigateToDailyStudy: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val selectedYearId by viewModel.selectedYearId.collectAsState()
    val searchQuery by viewModel.searchQuery.collectAsState()
    val profile by viewModel.studentProfile.collectAsState()
    val bookmarks by viewModel.bookmarkedLessons.collectAsState()

    var activeLessonForDetails by remember { mutableStateOf<Pair<Lesson, Subject>?>(null) }
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    val currentYear = MechatronicsCurriculum.academicYears.firstOrNull { it.id == selectedYearId }
        ?: MechatronicsCurriculum.academicYears.first()

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(TechNavyDark),
        contentPadding = PaddingValues(bottom = 96.dp)
    ) {
        // Hero Header & University Branding
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp)
            ) {
                Image(
                    painter = painterResource(id = R.drawable.img_mechatronics_hero),
                    contentDescription = "بانر هندسة الميكاترونكس",
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(
                                    Color.Transparent,
                                    TechNavyDark.copy(alpha = 0.85f),
                                    TechNavyDark
                                )
                            )
                        )
                )
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.Bottom
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(TechCyanPrimary.copy(alpha = 0.2f))
                            .border(1.dp, TechCyanPrimary.copy(alpha = 0.4f), RoundedCornerShape(8.dp))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.School,
                            contentDescription = null,
                            tint = TechCyanLight,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "الجامعة الإماراتية الدولية - صنعاء (EIU)",
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                            color = TechCyanLight
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = "دكتور الميكاترونكس",
                        style = MaterialTheme.typography.headlineMedium.copy(
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 24.sp
                        ),
                        color = Color.White
                    )
                    Text(
                        text = "المرجع الشامل لجميع دروس وتجارب الميكاترونكس من سنة أولى إلى رابعة",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondaryDark
                    )
                }
            }
        }

        // Subscription Banner
        item {
            Box(modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
                SubscriptionBanner(
                    profile = profile,
                    onNavigateToSubscription = onNavigateToSubscription
                )
            }
        }

        // Daily Study Service Banner (ماذا درست اليوم؟)
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 4.dp)
                    .clickable { onNavigateToDailyStudy() }
                    .testTag("daily_study_banner"),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = TechNavySurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, CircuitGreen.copy(alpha = 0.5f))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        modifier = Modifier.weight(1f),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(CircuitGreen.copy(alpha = 0.15f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.School,
                                contentDescription = null,
                                tint = CircuitGreen,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "خدمة: ماذا درست اليوم؟",
                                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                    color = Color.White
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(CircuitGreen)
                                        .padding(horizontal = 5.dp, vertical = 1.dp)
                                ) {
                                    Text(
                                        text = "جديد 🎓",
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = TechNavyDark
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "ارفع فيديو أو صورة أو نص المحاضرة واطلب الشرح الفوري",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondaryDark
                            )
                        }
                    }

                    Icon(
                        imageVector = Icons.Default.AutoAwesome,
                        contentDescription = "الانتقال للخدمة",
                        tint = CircuitGreen,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }

        // Quick Reference Table Banner
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 4.dp)
                    .clickable { onNavigateToDimensions() }
                    .testTag("quick_reference_banner"),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = TechNavySurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, TechCyanPrimary.copy(alpha = 0.4f))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        modifier = Modifier.weight(1f),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(TechCyanPrimary.copy(alpha = 0.15f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Science,
                                contentDescription = null,
                                tint = TechCyanPrimary,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "المرجع السريع للتحويلات والأبعاد",
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimaryDark,
                                    fontSize = 13.sp
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Surface(
                                    color = TechGoldAccent.copy(alpha = 0.15f),
                                    shape = RoundedCornerShape(4.dp)
                                ) {
                                    Text(
                                        text = "⚡ جدول بحثي",
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = TechGoldAccent,
                                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                                    )
                                }
                            }
                            Text(
                                text = "20 كمية هندسية، صيغ أبعاد [M L T I]، وجدول تحويلات الوحدات",
                                color = TextSecondaryDark,
                                fontSize = 11.sp
                            )
                        }
                    }

                    Icon(
                        imageVector = Icons.Default.ExpandMore,
                        contentDescription = "فتح الجدول",
                        tint = TechCyanPrimary,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }

        // Search Bar
        item {
            Box(modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)) {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { viewModel.setSearchQuery(it) },
                    placeholder = { Text("ابحث في الدروس، القوانين، أو المواد...", color = TextSecondaryDark) },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = "بحث",
                            tint = TechCyanPrimary
                        )
                    },
                    trailingIcon = {
                        if (searchQuery.isNotBlank()) {
                            IconButton(onClick = { viewModel.setSearchQuery("") }) {
                                Icon(
                                    imageVector = Icons.Default.Close,
                                    contentDescription = "مسح",
                                    tint = TextSecondaryDark
                                )
                            }
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("course_search_bar"),
                    shape = RoundedCornerShape(14.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = TechNavySurface,
                        unfocusedContainerColor = TechNavySurface,
                        focusedBorderColor = TechCyanPrimary,
                        unfocusedBorderColor = TechNavyCard,
                        focusedTextColor = TextPrimaryDark,
                        unfocusedTextColor = TextPrimaryDark
                    ),
                    singleLine = true
                )
            }
        }

        // Academic Years Selector Tabs
        item {
            Column(modifier = Modifier.padding(top = 10.dp)) {
                Text(
                    text = "اختر السنة الدراسية الأكاديمية:",
                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold),
                    color = TechGoldAccent,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
                )

                LazyRow(
                    modifier = Modifier.fillMaxWidth(),
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(MechatronicsCurriculum.academicYears) { year ->
                        val isSelected = year.id == selectedYearId
                        FilterChip(
                            selected = isSelected,
                            onClick = { viewModel.selectYear(year.id) },
                            label = {
                                Text(
                                    text = year.title.split("(").first().trim(),
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                )
                            },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = TechCyanPrimary,
                                selectedLabelColor = TechNavyDark,
                                containerColor = TechNavyCard,
                                labelColor = TextPrimaryDark
                            ),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.testTag("year_chip_${year.id}")
                        )
                    }
                }
            }
        }

        // Year description header
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(TechNavySurface)
                    .border(1.dp, TechNavyCard, RoundedCornerShape(12.dp))
                    .padding(12.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(TechCyanPrimary.copy(alpha = 0.2f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "${currentYear.id}",
                            color = TechCyanLight,
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = currentYear.title,
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                            color = TextPrimaryDark
                        )
                        Text(
                            text = currentYear.description,
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondaryDark
                        )
                    }
                }
            }
        }

        // Filtered Subjects List
        val filteredSubjects = currentYear.subjects.mapNotNull { subject ->
            if (searchQuery.isBlank()) subject
            else {
                val matchesSubject = subject.name.contains(searchQuery, ignoreCase = true) ||
                        subject.englishName.contains(searchQuery, ignoreCase = true) ||
                        subject.description.contains(searchQuery, ignoreCase = true)
                val matchingLessons = subject.lessons.filter { lesson ->
                    lesson.arabicTitle.contains(searchQuery, ignoreCase = true) ||
                            lesson.title.contains(searchQuery, ignoreCase = true) ||
                            lesson.summary.contains(searchQuery, ignoreCase = true) ||
                            lesson.keyFormulas.any { it.contains(searchQuery, ignoreCase = true) }
                }
                if (matchesSubject || matchingLessons.isNotEmpty()) {
                    subject.copy(lessons = if (matchingLessons.isNotEmpty()) matchingLessons else subject.lessons)
                } else null
            }
        }

        if (filteredSubjects.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = null,
                            tint = TextSecondaryDark,
                            modifier = Modifier.size(48.dp)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "لا توجد نتائج بحث مطابقة لـ \"$searchQuery\"",
                            color = TextSecondaryDark,
                            fontSize = 14.sp
                        )
                    }
                }
            }
        } else {
            items(filteredSubjects) { subject ->
                SubjectAccordionCard(
                    subject = subject,
                    bookmarkedIds = bookmarks.map { it.lessonId }.toSet(),
                    onLessonClick = { lesson ->
                        activeLessonForDetails = Pair(lesson, subject)
                    },
                    onBookmarkToggle = { lesson ->
                        val isBookmarked = bookmarks.any { it.lessonId == lesson.id }
                        viewModel.toggleBookmark(lesson, subject, currentYear.id, isBookmarked)
                    },
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
                )
            }
        }
    }

    // Modal BottomSheet for In-Depth Lesson Details
    if (activeLessonForDetails != null) {
        val (lesson, subject) = activeLessonForDetails!!
        val isBookmarked = bookmarks.any { it.lessonId == lesson.id }

        ModalBottomSheet(
            onDismissRequest = { activeLessonForDetails = null },
            sheetState = sheetState,
            containerColor = TechNavySurface,
            contentColor = TextPrimaryDark,
            dragHandle = {
                Box(
                    modifier = Modifier
                        .padding(vertical = 10.dp)
                        .width(48.dp)
                        .height(4.dp)
                        .clip(CircleShape)
                        .background(TechNavyElevated)
                )
            }
        ) {
            LessonDetailSheetContent(
                lesson = lesson,
                subject = subject,
                isBookmarked = isBookmarked,
                onToggleBookmark = {
                    viewModel.toggleBookmark(lesson, subject, selectedYearId, isBookmarked)
                },
                onSendToAi = {
                    val contentToSend = "${lesson.arabicTitle} (${lesson.title}):\n${lesson.fullContent}\n\nالقوانين:\n${lesson.keyFormulas.joinToString("\n")}"
                    onSendToAiSummarizer(contentToSend)
                    activeLessonForDetails = null
                },
                onClose = { activeLessonForDetails = null }
            )
        }
    }
}

@Composable
fun SubjectAccordionCard(
    subject: Subject,
    bookmarkedIds: Set<String>,
    onLessonClick: (Lesson) -> Unit,
    onBookmarkToggle: (Lesson) -> Unit,
    modifier: Modifier = Modifier
) {
    var expanded by remember { mutableStateOf(true) }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .animateContentSize()
            .testTag("subject_card_${subject.id}"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = TechNavySurface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { expanded = !expanded }
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(TechCyanPrimary.copy(alpha = 0.15f))
                            .border(1.dp, TechCyanPrimary.copy(alpha = 0.3f), RoundedCornerShape(12.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Science,
                            contentDescription = null,
                            tint = TechCyanPrimary,
                            modifier = Modifier.size(24.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = subject.name,
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp
                                ),
                                color = TextPrimaryDark
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(TechNavyElevated)
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = subject.code,
                                    style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                                    color = TechGoldAccent
                                )
                            }
                        }
                        Text(
                            text = subject.englishName,
                            style = MaterialTheme.typography.bodySmall.copy(fontSize = 12.sp),
                            color = TextSecondaryDark
                        )
                        Text(
                            text = "${subject.lessons.size} دروس وشروحات متخصصة",
                            style = MaterialTheme.typography.labelSmall.copy(fontSize = 11.sp),
                            color = TechCyanLight
                        )
                    }
                }

                IconButton(onClick = { expanded = !expanded }) {
                    Icon(
                        imageVector = if (expanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                        contentDescription = if (expanded) "طي" else "توسيع",
                        tint = TextSecondaryDark
                    )
                }
            }

            AnimatedVisibility(visible = expanded) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 4.dp)
                ) {
                    HorizontalDivider(color = TechNavyCard, thickness = 1.dp)
                    Spacer(modifier = Modifier.height(8.dp))

                    subject.lessons.forEach { lesson ->
                        val isBookmarked = bookmarkedIds.contains(lesson.id)
                        LessonRowItem(
                            lesson = lesson,
                            isBookmarked = isBookmarked,
                            onClick = { onLessonClick(lesson) },
                            onBookmarkToggle = { onBookmarkToggle(lesson) }
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                }
            }
        }
    }
}

@Composable
fun LessonRowItem(
    lesson: Lesson,
    isBookmarked: Boolean,
    onClick: () -> Unit,
    onBookmarkToggle: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(TechNavyCard)
            .clickable { onClick() }
            .padding(12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                Box(
                    modifier = Modifier
                        .size(10.dp)
                        .clip(CircleShape)
                        .background(TechCyanPrimary)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        text = lesson.arabicTitle,
                        style = MaterialTheme.typography.bodyMedium.copy(
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 13.sp
                        ),
                        color = TextPrimaryDark
                    )
                    Text(
                        text = lesson.summary,
                        style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                        color = TextSecondaryDark,
                        maxLines = 1
                    )
                }
            }

            IconButton(
                onClick = onBookmarkToggle,
                modifier = Modifier.size(36.dp)
            ) {
                Icon(
                    imageVector = if (isBookmarked) Icons.Default.Bookmark else Icons.Default.BookmarkBorder,
                    contentDescription = if (isBookmarked) "إزالة الإشارة" else "حفظ الدرس",
                    tint = if (isBookmarked) TechGoldAccent else TextSecondaryDark,
                    modifier = Modifier.size(20.dp)
                )
            }
        }
    }
}

@Composable
fun LessonDetailSheetContent(
    lesson: Lesson,
    subject: Subject,
    isBookmarked: Boolean,
    onToggleBookmark: () -> Unit,
    onSendToAi: () -> Unit,
    onClose: () -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 8.dp),
        contentPadding = PaddingValues(bottom = 32.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(TechCyanPrimary.copy(alpha = 0.2f))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = "${subject.name} (${subject.code})",
                        color = TechCyanLight,
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold)
                    )
                }

                Row {
                    IconButton(onClick = onToggleBookmark) {
                        Icon(
                            imageVector = if (isBookmarked) Icons.Default.Bookmark else Icons.Default.BookmarkBorder,
                            contentDescription = "إشارة مرجعية",
                            tint = if (isBookmarked) TechGoldAccent else TextSecondaryDark
                        )
                    }
                    IconButton(onClick = onClose) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "إغلاق",
                            tint = TextSecondaryDark
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = lesson.arabicTitle,
                style = MaterialTheme.typography.titleLarge.copy(
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 20.sp
                ),
                color = TextPrimaryDark
            )
            Text(
                text = lesson.title,
                style = MaterialTheme.typography.bodyMedium,
                color = TechCyanLight
            )

            Spacer(modifier = Modifier.height(16.dp))

            // AI doctor action button
            Button(
                onClick = onSendToAi,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("send_to_ai_button"),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = TechCyanPrimary,
                    contentColor = TechNavyDark
                )
            ) {
                Icon(
                    imageVector = Icons.Default.AutoAwesome,
                    contentDescription = null,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "تلخيص هذا الدرس عبر دكتور الذكاء الاصطناعي",
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Full Content Section
            Text(
                text = "الشرح الأكاديمي والتفصيلي:",
                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                color = TechGoldAccent
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = lesson.fullContent,
                style = MaterialTheme.typography.bodyMedium.copy(lineHeight = 22.sp),
                color = TextPrimaryDark
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Key Formulas Section
            if (lesson.keyFormulas.isNotEmpty()) {
                Text(
                    text = "القوانين والمعادلات الرياضية الأساسية:",
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                    color = TechCyanPrimary
                )
                Spacer(modifier = Modifier.height(8.dp))
                lesson.keyFormulas.forEach { formula ->
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(TechNavyDark)
                            .border(1.dp, TechCyanPrimary.copy(alpha = 0.3f), RoundedCornerShape(8.dp))
                            .padding(horizontal = 14.dp, vertical = 10.dp)
                    ) {
                        Text(
                            text = formula,
                            style = MaterialTheme.typography.bodyMedium.copy(
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            ),
                            color = TechCyanLight
                        )
                    }
                }
                Spacer(modifier = Modifier.height(16.dp))
            }

            // Practical Solved Example
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0xFF142236))
                    .border(1.dp, Color(0xFF234166), RoundedCornerShape(12.dp))
                    .padding(14.dp)
            ) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.MenuBook,
                            contentDescription = null,
                            tint = TechGoldAccent,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "مسألة محلولة وتطبيق هندسي:",
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                            color = TechGoldAccent
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = lesson.practicalExample,
                        style = MaterialTheme.typography.bodySmall.copy(lineHeight = 20.sp),
                        color = TextPrimaryDark
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // EIU Sana'a Laboratory & Exam Tip
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0xFF0F2C23))
                    .border(1.dp, CircuitGreen.copy(alpha = 0.4f), RoundedCornerShape(12.dp))
                    .padding(14.dp)
            ) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Check,
                            contentDescription = null,
                            tint = CircuitGreen,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "نصيحة لمعامل واختبارات الجامعة الإماراتية بصنعاء:",
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                            color = CircuitGreen
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = lesson.eiuLabTip,
                        style = MaterialTheme.typography.bodySmall.copy(lineHeight = 20.sp),
                        color = TextPrimaryDark
                    )
                }
            }
        }
    }
}
