package com.example.ui

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.CompareArrows
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.screens.AiSummarizerScreen
import com.example.ui.screens.CoursesScreen
import com.example.ui.screens.MathCircuitsSolverScreen
import com.example.ui.screens.PhysicsDimensionsScreen
import com.example.ui.screens.SubscriptionScreen
import com.example.ui.theme.CircuitGreen
import com.example.ui.theme.TechCyanLight
import com.example.ui.theme.TechCyanPrimary
import com.example.ui.theme.TechGoldAccent
import com.example.ui.theme.TechNavyCard
import com.example.ui.theme.TechNavyDark
import com.example.ui.theme.TechNavySurface
import com.example.ui.theme.TextPrimaryDark
import com.example.ui.theme.TextSecondaryDark

enum class MainNavigationTab(
    val title: String,
    val icon: ImageVector,
    val testTag: String
) {
    COURSES("المقررات", Icons.Default.MenuBook, "nav_courses"),
    DIMENSIONS("الأبعاد والتحويلات", Icons.Default.CompareArrows, "nav_dimensions"),
    SOLVERS("معمل الدوائر", Icons.Default.Calculate, "nav_solvers"),
    AI_DOCTOR("دكتور AI", Icons.Default.AutoAwesome, "nav_ai_doctor"),
    SUBSCRIPTION("الاشتراك (10ر.ي)", Icons.Default.AccountBalanceWallet, "nav_subscription")
}

@Composable
fun MainAppScreen(
    viewModel: MechatronicsViewModel = viewModel()
) {
    var currentTab by remember { mutableStateOf(MainNavigationTab.COURSES) }
    val profile by viewModel.studentProfile.collectAsState()
    val isSubscribed = profile?.isSubscribed == true

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        bottomBar = {
            NavigationBar(
                containerColor = TechNavySurface,
                tonalElevation = 8.dp
            ) {
                MainNavigationTab.values().forEach { tab ->
                    val isSelected = currentTab == tab
                    NavigationBarItem(
                        selected = isSelected,
                        onClick = { currentTab = tab },
                        icon = {
                            if (tab == MainNavigationTab.SUBSCRIPTION && !isSubscribed) {
                                BadgedBox(
                                    badge = {
                                        Badge(
                                            containerColor = TechGoldAccent,
                                            contentColor = TechNavyDark
                                        ) {
                                            Text("10", fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                ) {
                                    Icon(
                                        imageVector = tab.icon,
                                        contentDescription = tab.title,
                                        modifier = Modifier.size(22.dp)
                                    )
                                }
                            } else {
                                Icon(
                                    imageVector = tab.icon,
                                    contentDescription = tab.title,
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                        },
                        label = {
                            Text(
                                text = tab.title,
                                fontSize = 10.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = TechNavyDark,
                            selectedTextColor = TechCyanPrimary,
                            indicatorColor = TechCyanPrimary,
                            unselectedIconColor = TextSecondaryDark,
                            unselectedTextColor = TextSecondaryDark
                        ),
                        modifier = Modifier.testTag(tab.testTag)
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (currentTab) {
                MainNavigationTab.COURSES -> {
                    CoursesScreen(
                        viewModel = viewModel,
                        onNavigateToSubscription = { currentTab = MainNavigationTab.SUBSCRIPTION },
                        onSendToAiSummarizer = { content ->
                            viewModel.setLectureInputText(content)
                            currentTab = MainNavigationTab.AI_DOCTOR
                        },
                        onNavigateToDimensions = { currentTab = MainNavigationTab.DIMENSIONS },
                        onNavigateToDailyStudy = { currentTab = MainNavigationTab.AI_DOCTOR }
                    )
                }

                MainNavigationTab.DIMENSIONS -> {
                    PhysicsDimensionsScreen(viewModel = viewModel)
                }

                MainNavigationTab.SOLVERS -> {
                    MathCircuitsSolverScreen(viewModel = viewModel)
                }

                MainNavigationTab.AI_DOCTOR -> {
                    AiSummarizerScreen(viewModel = viewModel)
                }

                MainNavigationTab.SUBSCRIPTION -> {
                    SubscriptionScreen(viewModel = viewModel)
                }
            }
        }
    }
}
