package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.MenuBook
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.PlayCircle
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.TextFields
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.AiOperationState
import com.example.ui.MechatronicsViewModel
import com.example.ui.theme.CircuitGreen
import com.example.ui.theme.LaserRed
import com.example.ui.theme.TechCyanLight
import com.example.ui.theme.TechCyanPrimary
import com.example.ui.theme.TechGoldAccent
import com.example.ui.theme.TechNavyCard
import com.example.ui.theme.TechNavyDark
import com.example.ui.theme.TechNavyElevated
import com.example.ui.theme.TechNavySurface
import com.example.ui.theme.TextPrimaryDark
import com.example.ui.theme.TextSecondaryDark
import java.io.InputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun AiSummarizerScreen(
    viewModel: MechatronicsViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var selectedAiMode by remember { mutableIntStateOf(0) }
    val modes = listOf("ماذا درست اليوم؟ 🎓", "تلخيص نصوص 📝", "شرح صورة أو دائرة 🔍")

    val aiState by viewModel.aiState.collectAsState()
    val lectureText by viewModel.lectureInputText.collectAsState()
    val uploadedBitmap by viewModel.uploadedImageBitmap.collectAsState()
    val imageNotes by viewModel.imageNotes.collectAsState()
    val savedSummaries by viewModel.savedSummaries.collectAsState()

    // Daily Study Flows
    val dailyStudyText by viewModel.dailyStudyText.collectAsState()
    val dailyStudyImageBitmap by viewModel.dailyStudyImageBitmap.collectAsState()
    val dailyStudyVideoUri by viewModel.dailyStudyVideoUri.collectAsState()
    val dailyStudyVideoThumbnail by viewModel.dailyStudyVideoThumbnail.collectAsState()
    val dailyStudyVideoName by viewModel.dailyStudyVideoName.collectAsState()
    val dailyStudySubject by viewModel.dailyStudySubject.collectAsState()

    // Photo picker launcher (Android Photo Picker - Zero-Permission)
    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            try {
                val inputStream: InputStream? = context.contentResolver.openInputStream(uri)
                val bitmap = BitmapFactory.decodeStream(inputStream)
                viewModel.setUploadedImage(bitmap)
            } catch (e: Exception) {
                Toast.makeText(context, "تعذر قراءة الصورة المحددة", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // Daily Study Image Picker
    val dailyImagePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            try {
                val inputStream: InputStream? = context.contentResolver.openInputStream(uri)
                val bitmap = BitmapFactory.decodeStream(inputStream)
                viewModel.setDailyStudyImage(bitmap)
            } catch (e: Exception) {
                Toast.makeText(context, "تعذر قراءة صورة الدرس", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // Daily Study Video Picker
    val videoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        viewModel.setDailyStudyVideo(context, uri)
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(TechNavyDark),
        contentPadding = PaddingValues(bottom = 96.dp)
    ) {
        // Top Header
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(TechNavySurface)
                    .padding(horizontal = 16.dp, vertical = 14.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(TechCyanPrimary.copy(alpha = 0.2f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Psychology,
                            contentDescription = null,
                            tint = TechCyanLight,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "دكتور الذكاء الاصطناعي للميكاترونكس",
                            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                            color = TextPrimaryDark
                        )
                        Text(
                            text = "خدمة ماذا درست اليوم، تلخيص المحاضرات وشرح المسائل والمخططات",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondaryDark
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                TabRow(
                    selectedTabIndex = selectedAiMode,
                    containerColor = TechNavyCard,
                    contentColor = TechCyanPrimary,
                    indicator = { tabPositions ->
                        TabRowDefaults.SecondaryIndicator(
                            Modifier.tabIndicatorOffset(tabPositions[selectedAiMode]),
                            color = TechCyanPrimary
                        )
                    },
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .border(1.dp, TechNavyElevated, RoundedCornerShape(12.dp))
                ) {
                    modes.forEachIndexed { index, title ->
                        Tab(
                            selected = selectedAiMode == index,
                            onClick = { selectedAiMode = index },
                            text = {
                                Text(
                                    text = title,
                                    fontWeight = if (selectedAiMode == index) FontWeight.Bold else FontWeight.Normal,
                                    fontSize = 12.sp
                                )
                            }
                        )
                    }
                }
            }
        }

        // Mode Content
        item {
            Box(modifier = Modifier.padding(16.dp)) {
                when (selectedAiMode) {
                    0 -> {
                        // Daily Study Service: ماذا درست اليوم؟
                        DailyStudyCard(
                            dailyStudyText = dailyStudyText,
                            onTextChange = { viewModel.setDailyStudyText(it) },
                            selectedSubject = dailyStudySubject,
                            onSubjectChange = { viewModel.setDailyStudySubject(it) },
                            uploadedImageBitmap = dailyStudyImageBitmap,
                            onPickImage = {
                                dailyImagePickerLauncher.launch(
                                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                )
                            },
                            onClearImage = { viewModel.setDailyStudyImage(null) },
                            videoUri = dailyStudyVideoUri,
                            videoThumbnail = dailyStudyVideoThumbnail,
                            videoName = dailyStudyVideoName,
                            onPickVideo = {
                                videoPickerLauncher.launch(
                                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)
                                )
                            },
                            onClearVideo = { viewModel.setDailyStudyVideo(context, null) },
                            onExplain = { viewModel.explainDailyStudy(context) },
                            isLoading = aiState is AiOperationState.Loading,
                            onSampleSelect = { sample -> viewModel.setDailyStudyText(sample) }
                        )
                    }
                    1 -> {
                        // Lecture Text Summarizer
                        TextSummarizerCard(
                            lectureText = lectureText,
                            onTextChange = { viewModel.setLectureInputText(it) },
                            onSummarize = { viewModel.summarizeLecture() },
                            isLoading = aiState is AiOperationState.Loading,
                            onSampleSelect = { sample -> viewModel.setLectureInputText(sample) }
                        )
                    }
                    else -> {
                        // Image Explainer
                        ImageExplainerCard(
                            uploadedBitmap = uploadedBitmap,
                            imageNotes = imageNotes,
                            onNotesChange = { viewModel.setImageNotes(it) },
                            onPickImage = {
                                photoPickerLauncher.launch(
                                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                )
                            },
                            onClearImage = { viewModel.setUploadedImage(null) },
                            onExplain = { viewModel.explainImage() },
                            isLoading = aiState is AiOperationState.Loading
                        )
                    }
                }
            }
        }

        // AI Result View
        item {
            Box(modifier = Modifier.padding(horizontal = 16.dp)) {
                when (val state = aiState) {
                    is AiOperationState.Loading -> {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.cardColors(containerColor = TechNavySurface)
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(28.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                CircularProgressIndicator(color = CircuitGreen)
                                Spacer(modifier = Modifier.height(14.dp))
                                Text(
                                    text = "يقوم دكتور الميكاترونكس بتحليل درس اليوم وإعداد الشرح المبسط...",
                                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                                    color = TechCyanLight
                                )
                            }
                        }
                    }

                    is AiOperationState.Success -> {
                        AiResultCard(
                            resultText = state.content,
                            onCopy = {
                                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                val clip = ClipData.newPlainText("شرح دكتور الميكاترونكس", state.content)
                                clipboard.setPrimaryClip(clip)
                                Toast.makeText(context, "تم نسخ الشرح بنجاح", Toast.LENGTH_SHORT).show()
                            },
                            onShare = {
                                try {
                                    val sendIntent = Intent().apply {
                                        action = Intent.ACTION_SEND
                                        putExtra(Intent.EXTRA_TEXT, "📚 شرح درس اليوم من تطبيق دكتور الميكاترونكس (جامعة EIU):\n\n${state.content}")
                                        type = "text/plain"
                                    }
                                    val shareIntent = Intent.createChooser(sendIntent, "مشاركة شرح الدرس")
                                    context.startActivity(shareIntent)
                                } catch (e: Exception) {
                                    Toast.makeText(context, "تعذر فتح المشاركة", Toast.LENGTH_SHORT).show()
                                }
                            },
                            onClose = { viewModel.resetAiState() }
                        )
                    }

                    is AiOperationState.Error -> {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF2C1318))
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text(
                                    text = "تنبيه:",
                                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                    color = LaserRed
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = state.message,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = TextPrimaryDark
                                )
                            }
                        }
                    }

                    is AiOperationState.Idle -> {}
                }
            }
        }

        // Saved Summaries History Header
        if (savedSummaries.isNotEmpty()) {
            item {
                Spacer(modifier = Modifier.height(20.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.History,
                        contentDescription = null,
                        tint = TechGoldAccent,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "سجل الملخصات والشروحات المحفوظة (${savedSummaries.size}):",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = TextPrimaryDark
                    )
                }
                Spacer(modifier = Modifier.height(8.dp))
            }

            items(savedSummaries) { summary ->
                Box(modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)) {
                    SavedSummaryItem(
                        summary = summary,
                        onDelete = { viewModel.deleteSummary(summary.id) },
                        onCopy = {
                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            val clip = ClipData.newPlainText("ملخص محفوظ", summary.summaryResult)
                            clipboard.setPrimaryClip(clip)
                            Toast.makeText(context, "تم نسخ الملخص", Toast.LENGTH_SHORT).show()
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun TextSummarizerCard(
    lectureText: String,
    onTextChange: (String) -> Unit,
    onSummarize: () -> Unit,
    isLoading: Boolean,
    onSampleSelect: (String) -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("text_summarizer_card"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = TechNavySurface)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = "إدخال نص المحاضرة أو الملخص:",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = TechCyanPrimary
            )
            Text(
                text = "الصق ملخص المحاضرة أو أجزاء من سلايدات الدكاترة بالجامعة الإماراتية",
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondaryDark
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Sample quick buttons
            Text(
                text = "أو اختر موضوعاً جاهزاً للتجربة السريعة:",
                style = MaterialTheme.typography.labelSmall,
                color = TechGoldAccent
            )
            Spacer(modifier = Modifier.height(6.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                item {
                    SampleChip(
                        title = "متحكم PID",
                        onClick = {
                            onSampleSelect(
                                "متحكم PID في هندسة الميكاترونكس يتكون من ثلاثة حدود رئيسية: التناسبي Kp والتكاملي Ki والاشتقاقي Kd. يستخدم للتحكم في سرعة محركات DC وموضع أذرع الروبوت. المشكلة الشائعة هي حدوث تجاوز في الهدف Overshoot عند زيادة Kp، لذا نضيف مشتقة لمنع التذبذب."
                            )
                        }
                    )
                }
                item {
                    SampleChip(
                        title = "مشفرات الإنكودر",
                        onClick = {
                            onSampleSelect(
                                "الإنكودر البصري التزايدي Quadrature Optical Encoder يولد نبضات من القناتين A و B بفرق طور 90 درجة لتحديد زاوية واتجاه دوران محركات السيرفو بدقة."
                            )
                        }
                    )
                }
                item {
                    SampleChip(
                        title = "دوائر H-Bridge",
                        onClick = {
                            onSampleSelect(
                                "جسر H-Bridge لتوجيه المحركات يتكون من أربعة مفاتيح ترانزستور MOSFET ودايودات حماية Flyback لعكس اتجاه دوران محرك التيار المستمر DC Motor وتطبيق نبضات PWM."
                            )
                        }
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            OutlinedTextField(
                value = lectureText,
                onValueChange = onTextChange,
                placeholder = { Text("اكتب أو الصق نص الدرس أو الملخص هنا...", color = TextSecondaryDark) },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(140.dp)
                    .testTag("lecture_text_input"),
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = TechNavyDark,
                    unfocusedContainerColor = TechNavyDark,
                    focusedBorderColor = TechCyanPrimary,
                    unfocusedBorderColor = TechNavyCard,
                    focusedTextColor = TextPrimaryDark,
                    unfocusedTextColor = TextPrimaryDark
                )
            )

            Spacer(modifier = Modifier.height(14.dp))

            Button(
                onClick = onSummarize,
                enabled = !isLoading && lectureText.isNotBlank(),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("summarize_button"),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = TechCyanPrimary,
                    contentColor = TechNavyDark
                )
            ) {
                Icon(
                    imageVector = Icons.Default.AutoAwesome,
                    contentDescription = null,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (isLoading) "جاري المعالجة..." else "تلخيص واستخراج القوانين الأساسية",
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
fun ImageExplainerCard(
    uploadedBitmap: android.graphics.Bitmap?,
    imageNotes: String,
    onNotesChange: (String) -> Unit,
    onPickImage: () -> Unit,
    onClearImage: () -> Unit,
    onExplain: () -> Unit,
    isLoading: Boolean
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("image_explainer_card"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = TechNavySurface)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = "رفع صورة للدرس أو الدائرة الكهربائية:",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = TechCyanPrimary
            )
            Text(
                text = "التقط أو ارفع صورة لمخطط دائرة، مسألة رياضيات، أو صفحة من كتاب لشرحها",
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondaryDark
            )

            Spacer(modifier = Modifier.height(14.dp))

            if (uploadedBitmap != null) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(200.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(TechNavyDark)
                        .border(1.dp, TechCyanPrimary, RoundedCornerShape(12.dp))
                ) {
                    Image(
                        bitmap = uploadedBitmap.asImageBitmap(),
                        contentDescription = "صورة الدرس المرفوعة",
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Fit
                    )

                    IconButton(
                        onClick = onClearImage,
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .padding(8.dp)
                            .background(TechNavyDark.copy(alpha = 0.7f), CircleShape)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "حذف الصورة",
                            tint = Color.White
                        )
                    }
                }
            } else {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(150.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(TechNavyDark)
                        .border(1.dp, TechNavyCard, RoundedCornerShape(12.dp))
                        .clickable { onPickImage() },
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Default.AddPhotoAlternate,
                            contentDescription = null,
                            tint = TechCyanPrimary,
                            modifier = Modifier.size(44.dp)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "اضغط هنا لاختيار أو تصوير مسألة/دائرة",
                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                            color = TechCyanLight
                        )
                        Text(
                            text = "يدعم صور المخططات والسبورة والمعادلات",
                            style = MaterialTheme.typography.labelSmall,
                            color = TextSecondaryDark
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            OutlinedTextField(
                value = imageNotes,
                onValueChange = onNotesChange,
                placeholder = { Text("أضف سؤالك أو استفسارك حول الصورة (اختياري)...", color = TextSecondaryDark) },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("image_notes_input"),
                shape = RoundedCornerShape(10.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = TechNavyDark,
                    unfocusedContainerColor = TechNavyDark,
                    focusedTextColor = TextPrimaryDark,
                    unfocusedTextColor = TextPrimaryDark
                ),
                singleLine = true
            )

            Spacer(modifier = Modifier.height(14.dp))

            Button(
                onClick = onExplain,
                enabled = !isLoading && uploadedBitmap != null,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("explain_image_button"),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = TechCyanPrimary,
                    contentColor = TechNavyDark
                )
            ) {
                Icon(
                    imageVector = Icons.Default.AutoAwesome,
                    contentDescription = null,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (isLoading) "جاري التحليل والشرح..." else "شرح مبسط وسهل للصورة",
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
fun AiResultCard(
    resultText: String,
    onCopy: () -> Unit,
    onShare: () -> Unit,
    onClose: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("ai_result_card"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = TechNavySurface),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, CircuitGreen.copy(alpha = 0.5f))
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(12.dp)
                            .clip(CircleShape)
                            .background(CircuitGreen)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "إجابة وشرح دكتور الميكاترونكس:",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = CircuitGreen
                    )
                }

                Row {
                    IconButton(onClick = onShare) {
                        Icon(
                            imageVector = Icons.Default.Share,
                            contentDescription = "مشاركة",
                            tint = TechCyanLight
                        )
                    }
                    IconButton(onClick = onCopy) {
                        Icon(
                            imageVector = Icons.Default.ContentCopy,
                            contentDescription = "نسخ",
                            tint = TechGoldAccent
                        )
                    }
                    IconButton(onClick = onClose) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "إغلاق",
                            tint = TextSecondaryDark
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))
            HorizontalDivider(color = TechNavyCard)
            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = resultText,
                style = MaterialTheme.typography.bodyMedium.copy(lineHeight = 24.sp),
                color = TextPrimaryDark
            )
        }
    }
}

@Composable
fun DailyStudyCard(
    dailyStudyText: String,
    onTextChange: (String) -> Unit,
    selectedSubject: String,
    onSubjectChange: (String) -> Unit,
    uploadedImageBitmap: android.graphics.Bitmap?,
    onPickImage: () -> Unit,
    onClearImage: () -> Unit,
    videoUri: Uri?,
    videoThumbnail: android.graphics.Bitmap?,
    videoName: String,
    onPickVideo: () -> Unit,
    onClearVideo: () -> Unit,
    onExplain: () -> Unit,
    isLoading: Boolean,
    onSampleSelect: (String) -> Unit
) {
    val subjects = listOf(
        "تحكم آلي وروبوتات",
        "دوائر إلكترونية وتناظرية",
        "معالجات دقيقة ومتحكمات",
        "هيدروليك ونيوماتيك",
        "حساسات وأجهزة قياس",
        "ميكانيكا وتصميم آلات"
    )

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("daily_study_card"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = TechNavySurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, TechCyanPrimary.copy(alpha = 0.3f))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Header Info
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(CircuitGreen.copy(alpha = 0.2f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.School,
                        contentDescription = null,
                        tint = CircuitGreen,
                        modifier = Modifier.size(20.dp)
                    )
                }
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        text = "خدمة: ماذا درست اليوم؟ (EIU)",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = Color.White
                    )
                    Text(
                        text = "ارفع فيديو أو صورة أو نص المحاضرة واضغط «اشرح لي الدرس»",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondaryDark
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Subject Selector
            Text(
                text = "اختر المساق الدراسي لمزيد من الدقة الأكاديمية:",
                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                color = TechCyanLight
            )
            Spacer(modifier = Modifier.height(6.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(subjects) { subject ->
                    val isSelected = selectedSubject == subject
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (isSelected) TechCyanPrimary else TechNavyCard)
                            .border(
                                1.dp,
                                if (isSelected) TechCyanLight else TechNavyElevated,
                                RoundedCornerShape(8.dp)
                            )
                            .clickable { onSubjectChange(subject) }
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = subject,
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal),
                            color = if (isSelected) TechNavyDark else TextPrimaryDark
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Media Attachments Section
            Text(
                text = "المرفقات (فيديو أو صورة من القاعة أو السلايدات):",
                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                color = TechCyanLight
            )
            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Video Picker Button
                Card(
                    modifier = Modifier
                        .weight(1f)
                        .clickable { onPickVideo() }
                        .testTag("pick_video_button"),
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (videoUri != null) TechCyanPrimary.copy(alpha = 0.15f) else TechNavyDark
                    ),
                    border = androidx.compose.foundation.BorderStroke(
                        1.dp,
                        if (videoUri != null) TechCyanPrimary else TechNavyCard
                    )
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Videocam,
                            contentDescription = null,
                            tint = if (videoUri != null) TechCyanPrimary else TechCyanLight,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (videoUri != null) "تم اختيار فيديو" else "رفع فيديو",
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                            color = if (videoUri != null) TechCyanLight else TextPrimaryDark
                        )
                    }
                }

                // Image Picker Button
                Card(
                    modifier = Modifier
                        .weight(1f)
                        .clickable { onPickImage() }
                        .testTag("pick_daily_image_button"),
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (uploadedImageBitmap != null) TechCyanPrimary.copy(alpha = 0.15f) else TechNavyDark
                    ),
                    border = androidx.compose.foundation.BorderStroke(
                        1.dp,
                        if (uploadedImageBitmap != null) TechCyanPrimary else TechNavyCard
                    )
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.AddPhotoAlternate,
                            contentDescription = null,
                            tint = if (uploadedImageBitmap != null) TechCyanPrimary else TechCyanLight,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (uploadedImageBitmap != null) "تم اختيار صورة" else "رفع صورة",
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                            color = if (uploadedImageBitmap != null) TechCyanLight else TextPrimaryDark
                        )
                    }
                }
            }

            // Video Preview
            if (videoUri != null) {
                Spacer(modifier = Modifier.height(10.dp))
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = TechNavyDark),
                    border = androidx.compose.foundation.BorderStroke(1.dp, TechCyanPrimary.copy(alpha = 0.5f))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            if (videoThumbnail != null) {
                                Image(
                                    bitmap = videoThumbnail.asImageBitmap(),
                                    contentDescription = "معاينة الفيديو",
                                    modifier = Modifier
                                        .size(48.dp)
                                        .clip(RoundedCornerShape(6.dp)),
                                    contentScale = ContentScale.Crop
                                )
                            } else {
                                Box(
                                    modifier = Modifier
                                        .size(48.dp)
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(TechNavyCard),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.PlayCircle,
                                        contentDescription = null,
                                        tint = TechCyanPrimary,
                                        modifier = Modifier.size(26.dp)
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = videoName.ifBlank { "مقطع فيديو مسجل" },
                                    style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold),
                                    color = TextPrimaryDark,
                                    maxLines = 1
                                )
                                Text(
                                    text = "جاهز للتحليل واستخراج القوانين والشرح",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = CircuitGreen
                                )
                            }
                        }

                        IconButton(onClick = onClearVideo) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "إزالة الفيديو",
                                tint = LaserRed
                            )
                        }
                    }
                }
            }

            // Image Preview
            if (uploadedImageBitmap != null) {
                Spacer(modifier = Modifier.height(10.dp))
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = TechNavyDark),
                    border = androidx.compose.foundation.BorderStroke(1.dp, TechGoldAccent.copy(alpha = 0.5f))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            Image(
                                bitmap = uploadedImageBitmap.asImageBitmap(),
                                contentDescription = "معاينة الصورة",
                                modifier = Modifier
                                    .size(48.dp)
                                    .clip(RoundedCornerShape(6.dp)),
                                contentScale = ContentScale.Crop
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "صورة السبورة أو المخطط المرفق",
                                    style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold),
                                    color = TextPrimaryDark
                                )
                                Text(
                                    text = "سيتم التعرف على المعادلات والدوائر",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = TechGoldAccent
                                )
                            }
                        }

                        IconButton(onClick = onClearImage) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "إزالة الصورة",
                                tint = LaserRed
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Text Input Section
            Text(
                text = "اكتب تفاصيل أو ملاحظات درس اليوم (أو اختر من المقترحات):",
                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                color = TechCyanLight
            )
            Spacer(modifier = Modifier.height(6.dp))

            // Quick Topic Chips
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                item {
                    SampleChip(
                        title = "معايرة تحكم PID",
                        onClick = {
                            onSampleSelect("درس اليوم عن متحكم PID Controller: كيفية ضبط معاملات Kp و Ki و Kd، وعلاج مشكلة التجاوز Overshoot والتذبذب في محركات السيرفو.")
                        }
                    )
                }
                item {
                    SampleChip(
                        title = "دوائر مكبر العمليات Op-Amp",
                        onClick = {
                            onSampleSelect("شرح الدكتور اليوم دوائر Operational Amplifier العاكسة وغير العاكسة، وكيفية حساب الكسب Gain وتصميم فلتر نشط Active Filter للحساسات.")
                        }
                    )
                }
                item {
                    SampleChip(
                        title = "محركات السيرفو والـ Stepper",
                        onClick = {
                            onSampleSelect("مقارنة بين محركات الخطوة Stepper Motors ومحركات السيرفو Servo Motors، والتحكم بالنبضات PWM وزوايا التوجيه عبر الإنكودر.")
                        }
                    )
                }
                item {
                    SampleChip(
                        title = "حركيات الروبوت Kinematics",
                        onClick = {
                            onSampleSelect("معادلات الحركة المباشرة والمعكوسة Forward & Inverse Kinematics لذراع روبوتي 3 درجات حرية 3-DOF ومصفوفة الدوران.")
                        }
                    )
                }
                item {
                    SampleChip(
                        title = "أنظمة الهيدروليك والصمامات",
                        onClick = {
                            onSampleSelect("درس اليوم في الهيدروليك الصناعي: صمامات التحكم الاتجاهي 4/3 Directional Valves وحساب القوة والسرعة للأسطوانة الهيدروليكية.")
                        }
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            OutlinedTextField(
                value = dailyStudyText,
                onValueChange = onTextChange,
                placeholder = {
                    Text(
                        text = "اكتب هنا ما درسته اليوم في الجامعة الإماراتية (نص المحاضرة، المعادلات، أو أسئلة محددة تود تبسيطها)...",
                        color = TextSecondaryDark,
                        fontSize = 13.sp
                    )
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(130.dp)
                    .testTag("daily_study_text_input"),
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = TechNavyDark,
                    unfocusedContainerColor = TechNavyDark,
                    focusedBorderColor = CircuitGreen,
                    unfocusedBorderColor = TechNavyCard,
                    focusedTextColor = TextPrimaryDark,
                    unfocusedTextColor = TextPrimaryDark
                )
            )

            Spacer(modifier = Modifier.height(16.dp))

            // THE MAIN ACTION BUTTON: اشرح لي الدرس
            Button(
                onClick = onExplain,
                enabled = !isLoading && (dailyStudyText.isNotBlank() || uploadedImageBitmap != null || videoUri != null),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp)
                    .testTag("explain_lesson_button"),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = CircuitGreen,
                    contentColor = TechNavyDark,
                    disabledContainerColor = TechNavyCard,
                    disabledContentColor = TextSecondaryDark
                )
            ) {
                Icon(
                    imageVector = Icons.Default.School,
                    contentDescription = "اشرح لي الدرس",
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = if (isLoading) "دكتور الميكاترونكس يحلل الدرس..." else "اشرح لي الدرس 🎓",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.ExtraBold)
                )
            }
        }
    }
}

@Composable
fun SavedSummaryItem(
    summary: com.example.data.db.SavedSummaryEntity,
    onDelete: () -> Unit,
    onCopy: () -> Unit
) {
    val dateStr = remember(summary.timestamp) {
        val sdf = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault())
        sdf.format(Date(summary.timestamp))
    }

    val badgeColor = when (summary.type) {
        "DAILY_STUDY" -> CircuitGreen
        "IMAGE" -> TechGoldAccent
        else -> TechCyanLight
    }

    val badgeText = when (summary.type) {
        "DAILY_STUDY" -> "ماذا درست اليوم 🎓"
        "IMAGE" -> "صورة/دائرة 🔍"
        else -> "تلخيص نص 📝"
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = TechNavySurface)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(badgeColor.copy(alpha = 0.2f))
                            .padding(horizontal = 8.dp, vertical = 3.dp)
                    ) {
                        Text(
                            text = badgeText,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = badgeColor
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = summary.title,
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                        color = TextPrimaryDark,
                        maxLines = 1
                    )
                }

                Row {
                    IconButton(onClick = onCopy, modifier = Modifier.size(32.dp)) {
                        Icon(
                            imageVector = Icons.Default.ContentCopy,
                            contentDescription = "نسخ",
                            tint = TextSecondaryDark,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                    IconButton(onClick = onDelete, modifier = Modifier.size(32.dp)) {
                        Icon(
                            imageVector = Icons.Default.Delete,
                            contentDescription = "حذف",
                            tint = LaserRed,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = summary.summaryResult,
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondaryDark,
                maxLines = 3
            )

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = dateStr,
                style = MaterialTheme.typography.labelSmall,
                color = Color(0xFF718093)
            )
        }
    }
}

@Composable
fun SampleChip(title: String, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(TechNavyCard)
            .border(1.dp, TechNavyElevated, RoundedCornerShape(8.dp))
            .clickable { onClick() }
            .padding(horizontal = 10.dp, vertical = 6.dp)
    ) {
        Text(
            text = title,
            style = MaterialTheme.typography.labelSmall,
            color = TechCyanLight
        )
    }
}
