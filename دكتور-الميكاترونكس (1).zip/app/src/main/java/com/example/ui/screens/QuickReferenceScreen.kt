package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.TableChart
import androidx.compose.material.icons.filled.ViewAgenda
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.DimensionCategory
import com.example.data.model.EngineeringPrefixItem
import com.example.data.model.MechatronicsReferenceItem
import com.example.data.model.SIBaseUnitItem
import com.example.ui.MechatronicsViewModel
import com.example.ui.theme.CircuitGreen
import com.example.ui.theme.TechCyanLight
import com.example.ui.theme.TechCyanPrimary
import com.example.ui.theme.TechGoldAccent
import com.example.ui.theme.TechNavyCard
import com.example.ui.theme.TechNavyDark
import com.example.ui.theme.TechNavyElevated
import com.example.ui.theme.TechNavySurface
import com.example.ui.theme.TextPrimaryDark
import com.example.ui.theme.TextSecondaryDark

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun QuickReferenceScreen(
    viewModel: MechatronicsViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current

    val allItems = viewModel.referenceTable
    val siBaseUnits = viewModel.siBaseUnits
    val prefixes = viewModel.engineeringPrefixes

    val searchQuery by viewModel.referenceSearch.collectAsState()
    val selectedCategory by viewModel.selectedRefCategory.collectAsState()
    val isTableView by viewModel.isTableView.collectAsState()
    val activeDetailItem by viewModel.activeDetailItem.collectAsState()

    var showBaseUnitsCard by remember { mutableStateOf(false) }
    var showPrefixesCard by remember { mutableStateOf(false) }
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    val filteredItems = remember(allItems, searchQuery, selectedCategory) {
        allItems.filter { item ->
            val matchesCategory = (selectedCategory == DimensionCategory.ALL || item.category == selectedCategory)
            val matchesSearch = if (searchQuery.isBlank()) true else {
                item.nameAr.contains(searchQuery, ignoreCase = true) ||
                        item.nameEn.contains(searchQuery, ignoreCase = true) ||
                        item.symbol.contains(searchQuery, ignoreCase = true) ||
                        item.dimensionFormula.contains(searchQuery, ignoreCase = true) ||
                        item.siUnit.contains(searchQuery, ignoreCase = true) ||
                        item.siBreakdown.contains(searchQuery, ignoreCase = true) ||
                        item.definingLaw.contains(searchQuery, ignoreCase = true) ||
                        item.commonConversions.any { it.contains(searchQuery, ignoreCase = true) }
            }
            matchesCategory && matchesSearch
        }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(TechNavyDark),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp)
    ) {
        // Quick Stats / Info Header
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(TechNavySurface)
                    .border(1.dp, TechNavyCard, RoundedCornerShape(14.dp))
                    .padding(14.dp)
            ) {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(TechCyanPrimary.copy(alpha = 0.15f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Speed,
                                    contentDescription = null,
                                    tint = TechCyanPrimary,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "الجدول المرجعي السريع للهندسة",
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimaryDark,
                                    fontSize = 15.sp
                                )
                                Text(
                                    text = "أبعاد [M L T I Θ] والتحويلات المعتمدة لطلاب الميكاترونكس",
                                    color = TextSecondaryDark,
                                    fontSize = 11.sp
                                )
                            }
                        }

                        // Toggle Table vs Cards
                        IconButton(
                            onClick = { viewModel.toggleViewMode() },
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(TechNavyCard)
                                .size(36.dp)
                                .testTag("toggle_view_mode_button")
                        ) {
                            Icon(
                                imageVector = if (isTableView) Icons.Default.ViewAgenda else Icons.Default.TableChart,
                                contentDescription = if (isTableView) "عرض كبطاقات" else "عرض كجدول مصفوفي",
                                tint = TechCyanPrimary,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Quick Badges
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        QuickInfoBadge(text = "${allItems.size} كمية أساسية ومشتقة", color = TechCyanPrimary)
                        QuickInfoBadge(text = "60+ معامل تحويل مباشر", color = TechGoldAccent)
                        QuickInfoBadge(text = "النظام الدولي SI", color = CircuitGreen)
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))
        }

        // Expandable Base Dimensions & Metric Prefixes Bars
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = { showBaseUnitsCard = !showBaseUnitsCard },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (showBaseUnitsCard) TechCyanPrimary.copy(alpha = 0.2f) else TechNavySurface,
                        contentColor = if (showBaseUnitsCard) TechCyanPrimary else TextPrimaryDark
                    ),
                    shape = RoundedCornerShape(10.dp),
                    border = borderFromState(showBaseUnitsCard),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(
                        imageVector = Icons.Default.Layers,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("الوحدات الـ 7 الأساسية", fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                    Spacer(modifier = Modifier.width(4.dp))
                    Icon(
                        imageVector = if (showBaseUnitsCard) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                        contentDescription = null,
                        modifier = Modifier.size(14.dp)
                    )
                }

                Button(
                    onClick = { showPrefixesCard = !showPrefixesCard },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (showPrefixesCard) TechGoldAccent.copy(alpha = 0.2f) else TechNavySurface,
                        contentColor = if (showPrefixesCard) TechGoldAccent else TextPrimaryDark
                    ),
                    shape = RoundedCornerShape(10.dp),
                    border = borderFromState(showPrefixesCard),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(
                        imageVector = Icons.Default.Info,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("البادئات القياسية (k, M, μ)", fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                    Spacer(modifier = Modifier.width(4.dp))
                    Icon(
                        imageVector = if (showPrefixesCard) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                        contentDescription = null,
                        modifier = Modifier.size(14.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))
        }

        // SI Base Units Collapsible Sheet
        item {
            AnimatedVisibility(visible = showBaseUnitsCard) {
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = TechNavySurface),
                    border = androidx.compose.foundation.BorderStroke(1.dp, TechCyanPrimary.copy(alpha = 0.4f)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 12.dp)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "الكميات الأساسية السبع في النظام الدولي (SI Base Dimensions):",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = TechCyanPrimary
                            )
                            IconButton(onClick = { showBaseUnitsCard = false }, modifier = Modifier.size(24.dp)) {
                                Icon(Icons.Default.Close, contentDescription = "إغلاق", tint = TextSecondaryDark, modifier = Modifier.size(16.dp))
                            }
                        }
                        Spacer(modifier = Modifier.height(8.dp))

                        LazyRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            contentPadding = PaddingValues(vertical = 4.dp)
                        ) {
                            items(siBaseUnits) { unit ->
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(TechNavyCard)
                                        .border(1.dp, TechNavyElevated, RoundedCornerShape(8.dp))
                                        .padding(horizontal = 10.dp, vertical = 8.dp)
                                ) {
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Text(
                                            text = unit.dimensionSymbol,
                                            fontFamily = FontFamily.Monospace,
                                            fontWeight = FontWeight.Bold,
                                            color = TechGoldAccent,
                                            fontSize = 13.sp
                                        )
                                        Text(
                                            text = "${unit.quantityAr} (${unit.unitSymbol})",
                                            color = TextPrimaryDark,
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Medium
                                        )
                                        Text(
                                            text = unit.unitNameAr,
                                            color = TextSecondaryDark,
                                            fontSize = 9.sp
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Engineering Prefixes Collapsible Sheet
        item {
            AnimatedVisibility(visible = showPrefixesCard) {
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = TechNavySurface),
                    border = androidx.compose.foundation.BorderStroke(1.dp, TechGoldAccent.copy(alpha = 0.4f)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 12.dp)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "البادئات الهندسية القياسية (Metric Prefixes):",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = TechGoldAccent
                            )
                            IconButton(onClick = { showPrefixesCard = false }, modifier = Modifier.size(24.dp)) {
                                Icon(Icons.Default.Close, contentDescription = "إغلاق", tint = TextSecondaryDark, modifier = Modifier.size(16.dp))
                            }
                        }
                        Spacer(modifier = Modifier.height(8.dp))

                        LazyRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            contentPadding = PaddingValues(vertical = 4.dp)
                        ) {
                            items(prefixes) { prefix ->
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(TechNavyCard)
                                        .border(1.dp, TechNavyElevated, RoundedCornerShape(8.dp))
                                        .padding(horizontal = 10.dp, vertical = 6.dp)
                                ) {
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Text(
                                            text = prefix.symbol,
                                            fontFamily = FontFamily.Monospace,
                                            fontWeight = FontWeight.Bold,
                                            color = TechCyanPrimary,
                                            fontSize = 14.sp
                                        )
                                        Text(
                                            text = "${prefix.prefixAr} (${prefix.prefixName})",
                                            color = TextPrimaryDark,
                                            fontSize = 10.sp
                                        )
                                        Text(
                                            text = prefix.multiplierText,
                                            color = TechGoldAccent,
                                            fontSize = 9.sp,
                                            fontFamily = FontFamily.Monospace
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Search Field with Live Counter
        item {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { viewModel.setReferenceSearch(it) },
                placeholder = {
                    Text(
                        text = "ابحث بالاسم، الرمز (F, τ, B, P...)، البُعد [M L T] أو الوحدة...",
                        color = TextSecondaryDark,
                        fontSize = 12.sp
                    )
                },
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Default.Search,
                        contentDescription = null,
                        tint = TechCyanPrimary
                    )
                },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { viewModel.setReferenceSearch("") }) {
                            Icon(Icons.Default.Close, contentDescription = "مسح البحث", tint = TextSecondaryDark)
                        }
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("quick_reference_search_input"),
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = TechNavySurface,
                    unfocusedContainerColor = TechNavySurface,
                    focusedBorderColor = TechCyanPrimary,
                    unfocusedBorderColor = TechNavyCard,
                    focusedTextColor = TextPrimaryDark,
                    unfocusedTextColor = TextPrimaryDark
                ),
                singleLine = true
            )

            Spacer(modifier = Modifier.height(10.dp))
        }

        // Category Filter Chips
        item {
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(DimensionCategory.values()) { cat ->
                    val isSelected = selectedCategory == cat
                    FilterChip(
                        selected = isSelected,
                        onClick = { viewModel.setReferenceCategory(cat) },
                        label = {
                            Text(
                                text = cat.titleAr,
                                fontSize = 11.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                            )
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = TechCyanPrimary.copy(alpha = 0.2f),
                            selectedLabelColor = TechCyanPrimary,
                            containerColor = TechNavySurface,
                            labelColor = TextSecondaryDark
                        ),
                        border = FilterChipDefaults.filterChipBorder(
                            enabled = true,
                            selected = isSelected,
                            borderColor = if (isSelected) TechCyanPrimary else TechNavyCard
                        ),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.testTag("filter_chip_${cat.name}")
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))
        }

        // Search results count
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "عرض ${filteredItems.size} من أصل ${allItems.size} مدخل مرجعي",
                    color = TextSecondaryDark,
                    fontSize = 11.sp
                )
                Text(
                    text = if (isTableView) "اضغط على أي صف لتفاصيل التحويل والنسخ" else "اضغط على البطاقة للخيارات",
                    color = TechCyanLight,
                    fontSize = 10.sp
                )
            }
            Spacer(modifier = Modifier.height(8.dp))
        }

        // Content Display: Matrix Table or Cards
        if (isTableView) {
            // Interactive Engineering Matrix Table
            item {
                EngineeringMatrixTable(
                    items = filteredItems,
                    onItemClick = { viewModel.selectDetailItem(it) },
                    onCopyDimension = { item ->
                        clipboardManager.setText(AnnotatedString(item.dimensionFormula))
                        Toast.makeText(context, "تم نسخ صيغة البُعد: ${item.dimensionFormula}", Toast.LENGTH_SHORT).show()
                    },
                    onCopyConversion = { item ->
                        val text = item.commonConversions.joinToString("\n")
                        clipboardManager.setText(AnnotatedString(text))
                        Toast.makeText(context, "تم نسخ تحويلات: ${item.nameAr}", Toast.LENGTH_SHORT).show()
                    }
                )
            }
        } else {
            // Cards Grid/List View
            items(filteredItems) { item ->
                ReferenceItemCard(
                    item = item,
                    onClick = { viewModel.selectDetailItem(item) },
                    onCopyDimension = {
                        clipboardManager.setText(AnnotatedString(item.dimensionFormula))
                        Toast.makeText(context, "تم نسخ صيغة البُعد: ${item.dimensionFormula}", Toast.LENGTH_SHORT).show()
                    },
                    onCopyConversion = {
                        val text = item.commonConversions.joinToString("\n")
                        clipboardManager.setText(AnnotatedString(text))
                        Toast.makeText(context, "تم نسخ تحويلات: ${item.nameAr}", Toast.LENGTH_SHORT).show()
                    }
                )
                Spacer(modifier = Modifier.height(10.dp))
            }
        }
    }

    // Modal Bottom Sheet for Item Details
    if (activeDetailItem != null) {
        val item = activeDetailItem!!
        ModalBottomSheet(
            onDismissRequest = { viewModel.selectDetailItem(null) },
            sheetState = sheetState,
            containerColor = TechNavyDark,
            contentColor = TextPrimaryDark,
            dragHandle = {
                Box(
                    modifier = Modifier
                        .padding(vertical = 10.dp)
                        .width(40.dp)
                        .height(4.dp)
                        .clip(RoundedCornerShape(2.dp))
                        .background(TechNavyElevated)
                )
            }
        ) {
            ReferenceDetailSheetContent(
                item = item,
                onDismiss = { viewModel.selectDetailItem(null) },
                onCopy = { text, label ->
                    clipboardManager.setText(AnnotatedString(text))
                    Toast.makeText(context, "تم نسخ $label: $text", Toast.LENGTH_SHORT).show()
                }
            )
        }
    }
}

@Composable
fun EngineeringMatrixTable(
    items: List<MechatronicsReferenceItem>,
    onItemClick: (MechatronicsReferenceItem) -> Unit,
    onCopyDimension: (MechatronicsReferenceItem) -> Unit,
    onCopyConversion: (MechatronicsReferenceItem) -> Unit
) {
    val scrollState = rememberScrollState()

    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = TechNavySurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, TechNavyCard),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(scrollState)
        ) {
            // Table Header Row
            Row(
                modifier = Modifier
                    .background(TechNavyCard)
                    .padding(horizontal = 12.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "الكمية والرمز",
                    fontWeight = FontWeight.Bold,
                    color = TechCyanPrimary,
                    fontSize = 12.sp,
                    modifier = Modifier.width(130.dp)
                )
                Text(
                    text = "صيغة الأبعاد [M L T]",
                    fontWeight = FontWeight.Bold,
                    color = TechCyanPrimary,
                    fontSize = 12.sp,
                    modifier = Modifier.width(130.dp)
                )
                Text(
                    text = "وحدة SI الأساسية",
                    fontWeight = FontWeight.Bold,
                    color = TechCyanPrimary,
                    fontSize = 12.sp,
                    modifier = Modifier.width(140.dp)
                )
                Text(
                    text = "أبرز التحويلات المباشرة",
                    fontWeight = FontWeight.Bold,
                    color = TechCyanPrimary,
                    fontSize = 12.sp,
                    modifier = Modifier.width(220.dp)
                )
                Text(
                    text = "القانون الرئيسي",
                    fontWeight = FontWeight.Bold,
                    color = TechCyanPrimary,
                    fontSize = 12.sp,
                    modifier = Modifier.width(140.dp)
                )
                Text(
                    text = "إجراء",
                    fontWeight = FontWeight.Bold,
                    color = TechCyanPrimary,
                    fontSize = 12.sp,
                    modifier = Modifier.width(60.dp)
                )
            }

            HorizontalDivider(color = TechNavyElevated, thickness = 1.dp)

            // Table Data Rows
            items.forEachIndexed { index, item ->
                val rowBg = if (index % 2 == 0) TechNavySurface else TechNavySurface.copy(alpha = 0.85f)
                Row(
                    modifier = Modifier
                        .background(rowBg)
                        .clickable { onItemClick(item) }
                        .padding(horizontal = 12.dp, vertical = 10.dp)
                        .testTag("table_row_${item.id}"),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Quantity Name & Symbol
                    Column(modifier = Modifier.width(130.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = item.nameAr,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimaryDark,
                                fontSize = 12.sp
                            )
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = item.symbol,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                color = TechGoldAccent,
                                fontSize = 12.sp
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = item.nameEn,
                                color = TextSecondaryDark,
                                fontSize = 9.sp,
                                maxLines = 1
                            )
                        }
                    }

                    // Dimension Formula
                    Box(
                        modifier = Modifier
                            .width(130.dp)
                            .padding(end = 8.dp)
                    ) {
                        Surface(
                            color = TechCyanPrimary.copy(alpha = 0.12f),
                            shape = RoundedCornerShape(6.dp),
                            border = androidx.compose.foundation.BorderStroke(0.5.dp, TechCyanPrimary.copy(alpha = 0.3f))
                        ) {
                            Text(
                                text = item.dimensionFormula,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                color = TechCyanLight,
                                fontSize = 11.sp,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp)
                            )
                        }
                    }

                    // SI Unit & Breakdown
                    Column(modifier = Modifier.width(140.dp).padding(end = 8.dp)) {
                        Text(
                            text = item.siUnit,
                            fontWeight = FontWeight.SemiBold,
                            color = TextPrimaryDark,
                            fontSize = 11.sp
                        )
                        Text(
                            text = item.siBreakdown,
                            fontFamily = FontFamily.Monospace,
                            color = TextSecondaryDark,
                            fontSize = 9.sp
                        )
                    }

                    // Direct Conversions
                    Column(modifier = Modifier.width(220.dp).padding(end = 8.dp)) {
                        item.commonConversions.take(2).forEach { conv ->
                            Text(
                                text = "• $conv",
                                color = TextPrimaryDark,
                                fontSize = 10.sp,
                                maxLines = 1,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                        if (item.commonConversions.size > 2) {
                            Text(
                                text = "+${item.commonConversions.size - 2} تحويلات إضافية (اضغط للتفاصيل)",
                                color = TechCyanPrimary,
                                fontSize = 9.sp
                            )
                        }
                    }

                    // Defining Law
                    Text(
                        text = item.definingLaw,
                        fontFamily = FontFamily.Monospace,
                        color = CircuitGreen,
                        fontSize = 10.sp,
                        modifier = Modifier.width(140.dp).padding(end = 8.dp)
                    )

                    // Action Copy
                    IconButton(
                        onClick = { onCopyDimension(item) },
                        modifier = Modifier.size(28.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.ContentCopy,
                            contentDescription = "نسخ البُعد",
                            tint = TechCyanPrimary,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
                HorizontalDivider(color = TechNavyElevated.copy(alpha = 0.5f), thickness = 0.5.dp)
            }
        }
    }
}

@Composable
fun ReferenceItemCard(
    item: MechatronicsReferenceItem,
    onClick: () -> Unit,
    onCopyDimension: () -> Unit,
    onCopyConversion: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .testTag("ref_card_${item.id}"),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = TechNavySurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, TechNavyCard)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp)
        ) {
            // Header: Name, Symbol, and Formula Pill
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = item.nameAr,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimaryDark,
                            fontSize = 15.sp
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(TechNavyCard)
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = item.symbol,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                color = TechGoldAccent,
                                fontSize = 12.sp
                            )
                        }
                    }
                    Text(
                        text = "${item.nameEn} • ${item.category.titleAr}",
                        color = TextSecondaryDark,
                        fontSize = 11.sp
                    )
                }

                Surface(
                    color = TechCyanPrimary.copy(alpha = 0.15f),
                    shape = RoundedCornerShape(8.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, TechCyanPrimary.copy(alpha = 0.3f)),
                    modifier = Modifier.clickable { onCopyDimension() }
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = item.dimensionFormula,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            color = TechCyanLight,
                            fontSize = 12.sp
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Icon(
                            imageVector = Icons.Default.ContentCopy,
                            contentDescription = "نسخ البُعد",
                            tint = TechCyanPrimary,
                            modifier = Modifier.size(12.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // SI Unit & Breakdown Box
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(TechNavyCard)
                    .padding(8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "الوحدة الدولية (SI):",
                            fontSize = 10.sp,
                            color = TextSecondaryDark
                        )
                        Text(
                            text = item.siUnit,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimaryDark,
                            fontSize = 12.sp
                        )
                    }

                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = "المكافئ بالوحدات الأساسية:",
                            fontSize = 10.sp,
                            color = TextSecondaryDark
                        )
                        Text(
                            text = item.siBreakdown,
                            fontFamily = FontFamily.Monospace,
                            color = TechGoldAccent,
                            fontSize = 11.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Key Conversions
            Text(
                text = "أهم التحويلات السريعة:",
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold,
                color = TechCyanPrimary
            )
            Spacer(modifier = Modifier.height(4.dp))

            item.commonConversions.forEach { conv ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(4.dp)
                            .clip(CircleShape)
                            .background(TechCyanPrimary)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = conv,
                        color = TextPrimaryDark,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Law & Lab Tip
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "القانون: ${item.definingLaw}",
                    fontFamily = FontFamily.Monospace,
                    color = CircuitGreen,
                    fontSize = 10.sp
                )
                Text(
                    text = "اضغط للمزيد من التفاصيل والاشتقاق ←",
                    color = TechCyanLight,
                    fontSize = 10.sp
                )
            }
        }
    }
}

@Composable
fun ReferenceDetailSheetContent(
    item: MechatronicsReferenceItem,
    onDismiss: () -> Unit,
    onCopy: (String, String) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 8.dp)
    ) {
        // Title & Close
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = item.nameAr,
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                    color = TextPrimaryDark
                )
                Text(
                    text = "${item.nameEn} • الرمز: ${item.symbol} • ${item.category.titleAr}",
                    color = TechCyanPrimary,
                    fontSize = 12.sp
                )
            }

            IconButton(onClick = onDismiss) {
                Icon(Icons.Default.Close, contentDescription = "إغلاق", tint = TextSecondaryDark)
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Dimension Highlight Card
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(TechNavySurface)
                .border(1.dp, TechCyanPrimary.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                .padding(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "صيغة الأبعاد الهندسية:",
                        fontSize = 11.sp,
                        color = TextSecondaryDark
                    )
                    Text(
                        text = item.dimensionFormula,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        color = TechCyanLight,
                        fontSize = 20.sp
                    )
                }

                Button(
                    onClick = { onCopy(item.dimensionFormula, "صيغة البُعد") },
                    colors = ButtonDefaults.buttonColors(containerColor = TechNavyCard, contentColor = TechCyanPrimary),
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("نسخ البُعد", fontSize = 11.sp)
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Full SI Unit details
        Card(
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = TechNavySurface),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = "الوحدة الدولية والاشتقاق الفيزيائي:",
                    fontWeight = FontWeight.Bold,
                    color = TextPrimaryDark,
                    fontSize = 13.sp
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "• وحدة القياس: ${item.siUnit}",
                    color = TextPrimaryDark,
                    fontSize = 12.sp
                )
                Text(
                    text = "• التفكيك للوحدات الأساسية: ${item.siBreakdown}",
                    fontFamily = FontFamily.Monospace,
                    color = TechGoldAccent,
                    fontSize = 12.sp
                )
                Text(
                    text = "• القانون النموذجي: ${item.definingLaw}",
                    fontFamily = FontFamily.Monospace,
                    color = CircuitGreen,
                    fontSize = 12.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Complete Conversion Table
        Card(
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = TechNavySurface),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "جدول معاملات التحويل المعتمدة:",
                        fontWeight = FontWeight.Bold,
                        color = TechCyanPrimary,
                        fontSize = 13.sp
                    )

                    Button(
                        onClick = { onCopy(item.commonConversions.joinToString("\n"), "التحويلات") },
                        colors = ButtonDefaults.buttonColors(containerColor = TechNavyCard, contentColor = TechCyanPrimary),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(12.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("نسخ الكل", fontSize = 10.sp)
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                item.commonConversions.forEach { conv ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = conv,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Medium,
                            color = TextPrimaryDark,
                            fontSize = 12.sp
                        )
                        IconButton(
                            onClick = { onCopy(conv, "التحويل") },
                            modifier = Modifier.size(24.dp)
                        ) {
                            Icon(Icons.Default.ContentCopy, contentDescription = null, tint = TextSecondaryDark, modifier = Modifier.size(14.dp))
                        }
                    }
                    HorizontalDivider(color = TechNavyCard, thickness = 0.5.dp)
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Application in Mechatronics & EIU Labs
        Card(
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = TechNavySurface),
            border = androidx.compose.foundation.BorderStroke(1.dp, TechGoldAccent.copy(alpha = 0.3f)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Info, contentDescription = null, tint = TechGoldAccent, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "التطبيق في معامل ومشاريع الميكاترونكس (EIU):",
                        fontWeight = FontWeight.Bold,
                        color = TechGoldAccent,
                        fontSize = 12.sp
                    )
                }
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = item.mechatronicsApplication,
                    color = TextPrimaryDark,
                    fontSize = 11.sp,
                    lineHeight = 18.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(20.dp))
    }
}

@Composable
fun QuickInfoBadge(text: String, color: Color) {
    Surface(
        color = color.copy(alpha = 0.12f),
        shape = RoundedCornerShape(6.dp),
        border = androidx.compose.foundation.BorderStroke(0.5.dp, color.copy(alpha = 0.4f))
    ) {
        Text(
            text = text,
            fontSize = 10.sp,
            color = color,
            fontWeight = FontWeight.Medium,
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
        )
    }
}

@Composable
fun borderFromState(active: Boolean): androidx.compose.foundation.BorderStroke {
    return androidx.compose.foundation.BorderStroke(
        width = 1.dp,
        color = if (active) TechCyanPrimary else TechNavyCard
    )
}
