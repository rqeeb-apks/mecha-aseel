package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Message
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.ElectricBolt
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.LocalOffer
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.MechatronicsViewModel
import com.example.ui.theme.CircuitGreen
import com.example.ui.theme.TechCyanLight
import com.example.ui.theme.TechCyanPrimary
import com.example.ui.theme.TechGoldAccent
import com.example.ui.theme.TechNavyCard
import com.example.ui.theme.TechNavyDark
import com.example.ui.theme.TechNavyElevated
import com.example.ui.theme.TechNavySurface
import com.example.ui.theme.TextPrimaryDark
import com.example.ui.theme.TextSecondaryDark
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun SubscriptionScreen(
    viewModel: MechatronicsViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val profile by viewModel.studentProfile.collectAsState()
    val subMessage by viewModel.subscriptionMessage.collectAsState()

    // Official updated payment number requested by user
    val targetPhoneNumber = "6710654"
    val isSubscribed = profile?.isSubscribed == true
    val now = System.currentTimeMillis()
    val isExpired = isSubscribed && profile != null && profile!!.subscriptionExpireDate in 1..<now
    val isCurrentlyActive = isSubscribed && !isExpired

    val remainingDays = remember(profile?.subscriptionExpireDate, now) {
        if (profile?.subscriptionExpireDate != null && profile!!.subscriptionExpireDate > now) {
            ((profile!!.subscriptionExpireDate - now) / (1000 * 60 * 60 * 24)).coerceAtLeast(0)
        } else {
            0
        }
    }

    var studentNameInput by remember(profile) { mutableStateOf(profile?.studentName ?: "") }
    var studentIdInput by remember(profile) { mutableStateOf(profile?.studentId ?: "EIU-2026-MCE") }
    var studentPhoneInput by remember(profile) { mutableStateOf(profile?.studentPhone ?: "") }
    var paymentMethod by remember { mutableStateOf("محفظة جيب") }
    var transactionInput by remember(profile) { mutableStateOf(profile?.transactionNumber ?: "") }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(TechNavyDark),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp)
    ) {
        // Top Header
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 12.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(42.dp)
                            .clip(CircleShape)
                            .background(TechGoldAccent.copy(alpha = 0.2f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.LocalOffer,
                            contentDescription = null,
                            tint = TechGoldAccent,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "نظام إدارة الاشتراك الشهري",
                                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                                color = TextPrimaryDark
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Surface(
                                color = CircuitGreen.copy(alpha = 0.15f),
                                shape = RoundedCornerShape(4.dp)
                            ) {
                                Text(
                                    text = "10 ريال يمني",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = CircuitGreen,
                                    modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp)
                                )
                            }
                        }
                        Text(
                            text = "لطلاب هندسة الميكاترونكس - الجامعة الإماراتية الدولية بصنعاء (EIU)",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondaryDark
                        )
                    }
                }
            }
        }

        // Active Subscription Status & Verification Card
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("subscription_status_card"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = when {
                        isCurrentlyActive -> Color(0xFF0C2B20)
                        isExpired -> Color(0xFF331D12)
                        else -> TechNavySurface
                    }
                ),
                border = androidx.compose.foundation.BorderStroke(
                    width = 1.dp,
                    color = when {
                        isCurrentlyActive -> CircuitGreen
                        isExpired -> TechGoldAccent
                        else -> TechNavyElevated
                    }
                ),
                elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    // Status Badge & Title
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = when {
                                    isCurrentlyActive -> Icons.Default.CheckCircle
                                    isExpired -> Icons.Default.Schedule
                                    else -> Icons.Default.ElectricBolt
                                },
                                contentDescription = null,
                                tint = when {
                                    isCurrentlyActive -> CircuitGreen
                                    isExpired -> TechGoldAccent
                                    else -> TechCyanPrimary
                                },
                                modifier = Modifier.size(30.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = when {
                                        isCurrentlyActive -> "حالة الاشتراك: نشط ومفعّل بالكامل"
                                        isExpired -> "حالة الاشتراك: منتهي الصلاحية"
                                        else -> "الاشتراك غير مفعّل بعد"
                                    },
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                    color = when {
                                        isCurrentlyActive -> CircuitGreen
                                        isExpired -> TechGoldAccent
                                        else -> TextPrimaryDark
                                    }
                                )
                                Text(
                                    text = when {
                                        isCurrentlyActive -> "جميع دروس وسنوات الميكاترونكس متاحة"
                                        isExpired -> "يرجى تجديد الاشتراك بـ 10 ريال لمتابعة الدروس"
                                        else -> "رسوم الاشتراك: 10 ريال يمني فقط شهرياً"
                                    },
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextSecondaryDark
                                )
                            }
                        }

                        // State Pill
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(
                                    when {
                                        isCurrentlyActive -> CircuitGreen
                                        isExpired -> TechGoldAccent
                                        else -> TechCyanPrimary.copy(alpha = 0.2f)
                                    }
                                )
                                .padding(horizontal = 10.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = when {
                                    isCurrentlyActive -> "نشط ✓"
                                    isExpired -> "منتهي ⚠️"
                                    else -> "غير مشترك"
                                },
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = if (isCurrentlyActive || isExpired) TechNavyDark else TechCyanLight
                                )
                            )
                        }
                    }

                    // Subscriber details (if registered)
                    if (profile != null && isSubscribed) {
                        Spacer(modifier = Modifier.height(14.dp))
                        HorizontalDivider(
                            color = if (isCurrentlyActive) Color(0xFF1B4E3E) else TechNavyElevated,
                            thickness = 1.dp
                        )
                        Spacer(modifier = Modifier.height(12.dp))

                        val sdf = SimpleDateFormat("dd MMMM yyyy", Locale.getDefault())
                        val startDateStr = if (profile!!.subscriptionDate > 0) sdf.format(Date(profile!!.subscriptionDate)) else "غير محدد"
                        val expireDateStr = if (profile!!.subscriptionExpireDate > 0) sdf.format(Date(profile!!.subscriptionExpireDate)) else "غير محدد"

                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "الطالب المشترك:",
                                    fontSize = 12.sp,
                                    color = TextSecondaryDark
                                )
                                Text(
                                    text = profile!!.studentName,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimaryDark
                                )
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "الرقم الأكاديمي:",
                                    fontSize = 12.sp,
                                    color = TextSecondaryDark
                                )
                                Text(
                                    text = profile!!.studentId,
                                    fontSize = 12.sp,
                                    fontFamily = FontFamily.Monospace,
                                    color = TechCyanLight
                                )
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "وسيلة السداد المعتمدة:",
                                    fontSize = 12.sp,
                                    color = TextSecondaryDark
                                )
                                Text(
                                    text = "${profile!!.paymentMethod} (${profile!!.transactionNumber.ifBlank { "مباشر" }})",
                                    fontSize = 12.sp,
                                    color = TextPrimaryDark
                                )
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "فترة الصلاحية:",
                                    fontSize = 12.sp,
                                    color = TextSecondaryDark
                                )
                                Text(
                                    text = "$startDateStr ← $expireDateStr",
                                    fontSize = 11.sp,
                                    color = CircuitGreen
                                )
                            }

                            if (isCurrentlyActive) {
                                Spacer(modifier = Modifier.height(4.dp))
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(Color(0xFF143B2C))
                                        .padding(8.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = "⏳ متبقي على التجديد: $remainingDays يوماً في خطتك الحالية",
                                        color = CircuitGreen,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Verification & Management Actions Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // Immediate Status Check / Refresh button
                        Button(
                            onClick = { viewModel.verifySubscriptionStatus() },
                            modifier = Modifier
                                .weight(1f)
                                .height(38.dp)
                                .testTag("verify_subscription_button"),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = TechNavyCard,
                                contentColor = TechCyanPrimary
                            ),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 8.dp)
                        ) {
                            Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("تحقق من الحالة الفورية", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }

                        if (isCurrentlyActive) {
                            // Renewal button
                            Button(
                                onClick = { viewModel.renewSubscription() },
                                modifier = Modifier
                                    .weight(1f)
                                    .height(38.dp)
                                    .testTag("renew_subscription_button"),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = CircuitGreen,
                                    contentColor = TechNavyDark
                                ),
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(horizontal = 8.dp)
                            ) {
                                Icon(Icons.Default.CalendarToday, contentDescription = null, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("تجديد شهر إضافي", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        } else {
                            // Reset test status button
                            OutlinedButton(
                                onClick = { viewModel.resetSubscription() },
                                modifier = Modifier
                                    .weight(1f)
                                    .height(38.dp)
                                    .testTag("reset_subscription_button"),
                                shape = RoundedCornerShape(8.dp),
                                border = androidx.compose.foundation.BorderStroke(1.dp, TechNavyCard),
                                contentPadding = PaddingValues(horizontal = 8.dp)
                            ) {
                                Text("إعادة تعيين الحالة", fontSize = 11.sp, color = TextSecondaryDark)
                            }
                        }
                    }

                    // Status Message Display
                    AnimatedVisibility(visible = subMessage != null) {
                        if (subMessage != null) {
                            Spacer(modifier = Modifier.height(10.dp))
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(TechNavyDark)
                                    .border(1.dp, TechCyanPrimary.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                                    .padding(10.dp)
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text(
                                        text = subMessage!!,
                                        style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold),
                                        color = TechCyanLight,
                                        modifier = Modifier.weight(1f)
                                    )
                                    IconButton(
                                        onClick = { viewModel.clearSubscriptionMessage() },
                                        modifier = Modifier.size(20.dp)
                                    ) {
                                        Text("✕", color = TextSecondaryDark, fontSize = 11.sp)
                                    }
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
        }

        // Detailed Payment Instructions (Jaib & Jawali with 6710654)
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("payment_instructions_card"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = TechNavySurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, TechNavyCard)
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "تفاصيل الدفع والتحويل (10 ريال يمني):",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = TechCyanPrimary
                            )
                            Text(
                                text = "يتم التحويل عبر إحدى المحافظ الإلكترونية المعتمدة بالرقم المعتمد:",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondaryDark
                            )
                        }

                        Surface(
                            color = TechGoldAccent.copy(alpha = 0.15f),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(
                                text = "10 YER",
                                color = TechGoldAccent,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Prominent Highlight Box with Target Number 6710654
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .background(TechNavyDark)
                            .border(1.5.dp, CircuitGreen.copy(alpha = 0.8f), RoundedCornerShape(14.dp))
                            .padding(14.dp)
                    ) {
                        Column {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column {
                                    Text(
                                        text = "رقم حساب التحويل (محفظة جيب أو جوالي):",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = CircuitGreen
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = targetPhoneNumber,
                                        style = MaterialTheme.typography.headlineMedium.copy(
                                            fontFamily = FontFamily.Monospace,
                                            fontWeight = FontWeight.ExtraBold,
                                            letterSpacing = 2.sp
                                        ),
                                        color = Color.White
                                    )
                                }

                                Row {
                                    // Copy Button
                                    IconButton(
                                        onClick = {
                                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                            val clip = ClipData.newPlainText("رقم التحويل", targetPhoneNumber)
                                            clipboard.setPrimaryClip(clip)
                                            Toast.makeText(context, "تم نسخ الرقم: $targetPhoneNumber", Toast.LENGTH_SHORT).show()
                                        },
                                        modifier = Modifier
                                            .clip(CircleShape)
                                            .background(TechNavyCard)
                                            .size(42.dp)
                                            .testTag("copy_phone_button")
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.ContentCopy,
                                            contentDescription = "نسخ الرقم",
                                            tint = TechCyanPrimary,
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }

                                    Spacer(modifier = Modifier.width(8.dp))

                                    // Direct Dial Button
                                    IconButton(
                                        onClick = {
                                            val intent = Intent(Intent.ACTION_DIAL).apply {
                                                data = Uri.parse("tel:$targetPhoneNumber")
                                            }
                                            context.startActivity(intent)
                                        },
                                        modifier = Modifier
                                            .clip(CircleShape)
                                            .background(TechNavyCard)
                                            .size(42.dp)
                                            .testTag("dial_phone_button")
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Call,
                                            contentDescription = "اتصال",
                                            tint = CircuitGreen,
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }

                                    Spacer(modifier = Modifier.width(8.dp))

                                    // SMS / WhatsApp Confirmation Button
                                    IconButton(
                                        onClick = {
                                            val smsIntent = Intent(Intent.ACTION_VIEW).apply {
                                                data = Uri.parse("sms:$targetPhoneNumber")
                                                putExtra("sms_body", "السلام عليكم، تم تحويل 10 ريال اشتراك تطبيق دكتور الميكاترونكس عبر ${paymentMethod} بالرقم $targetPhoneNumber.")
                                            }
                                            try {
                                                context.startActivity(smsIntent)
                                            } catch (e: Exception) {
                                                Toast.makeText(context, "تعذر فتح تطبيق الرسائل", Toast.LENGTH_SHORT).show()
                                            }
                                        },
                                        modifier = Modifier
                                            .clip(CircleShape)
                                            .background(TechNavyCard)
                                            .size(42.dp)
                                            .testTag("sms_phone_button")
                                    ) {
                                        Icon(
                                            imageVector = Icons.AutoMirrored.Filled.Message,
                                            contentDescription = "إرسال رسالة",
                                            tint = TechGoldAccent,
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(8.dp))
                            HorizontalDivider(color = TechNavyElevated, thickness = 0.5.dp)
                            Spacer(modifier = Modifier.height(8.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "المبلغ المطلوب: 10 ريال يمني فقط",
                                    color = TechGoldAccent,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "الاشتراك يغطي كافة فصول وسنوات الميكاترونكس",
                                    color = TextSecondaryDark,
                                    fontSize = 10.sp
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Side-by-side Wallets Step-by-Step Instructions
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        // 1. Jaib Wallet Card (محفظة جيب)
                        Card(
                            modifier = Modifier
                                .weight(1f)
                                .clickable { paymentMethod = "محفظة جيب" },
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = TechNavyDark),
                            border = androidx.compose.foundation.BorderStroke(
                                1.dp,
                                if (paymentMethod == "محفظة جيب") TechCyanPrimary else TechNavyCard
                            )
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Default.AccountBalanceWallet,
                                        contentDescription = null,
                                        tint = TechCyanPrimary,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "محفظة جيب",
                                        fontWeight = FontWeight.Bold,
                                        color = TextPrimaryDark,
                                        fontSize = 13.sp
                                    )
                                }
                                Text(
                                    text = "بنك الكريمي للتمويل الأصغر",
                                    color = TechCyanLight,
                                    fontSize = 9.sp
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = "1. افتح تطبيق جيب\n2. اختر (تحويل إلى مشترك)\n3. أدخل الرقم: $targetPhoneNumber\n4. حدد المبلغ: 10 ريال\n5. انسخ رقم إشعار الحوالة",
                                    color = TextSecondaryDark,
                                    fontSize = 10.sp,
                                    lineHeight = 16.sp
                                )
                            }
                        }

                        // 2. Jawali Wallet Card (محفظة جوالي)
                        Card(
                            modifier = Modifier
                                .weight(1f)
                                .clickable { paymentMethod = "محفظة جوالي" },
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = TechNavyDark),
                            border = androidx.compose.foundation.BorderStroke(
                                1.dp,
                                if (paymentMethod == "محفظة جوالي") TechGoldAccent else TechNavyCard
                            )
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Default.PhoneAndroid,
                                        contentDescription = null,
                                        tint = TechGoldAccent,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "محفظة جوالي",
                                        fontWeight = FontWeight.Bold,
                                        color = TextPrimaryDark,
                                        fontSize = 13.sp
                                    )
                                }
                                Text(
                                    text = "يمن موبايل / الشامل",
                                    color = TechGoldAccent,
                                    fontSize = 9.sp
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = "1. افتح تطبيق جوالي\n2. اختر (تحويل نقدي / سداد)\n3. أدخل الرقم: $targetPhoneNumber\n4. حدد المبلغ: 10 ريال\n5. احفظ رقم العملية وقم بتأكيده",
                                    color = TextSecondaryDark,
                                    fontSize = 10.sp,
                                    lineHeight = 16.sp
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
        }

        // Student Confirmation & Activation Form
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("confirmation_form_card"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = TechNavySurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, TechNavyCard)
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text(
                        text = "نموذج تأكيد وتفعيل الاشتراك الفوري:",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = TechCyanPrimary
                    )
                    Text(
                        text = "أدخل بيانات التحويل لتفعيل حسابك تلقائياً في قاعدة البيانات المحلية:",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondaryDark
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    // Student Name
                    OutlinedTextField(
                        value = studentNameInput,
                        onValueChange = { studentNameInput = it },
                        label = { Text("اسم الطالب الرباعي") },
                        placeholder = { Text("مثال: علي صالح اليماني") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("student_name_input"),
                        shape = RoundedCornerShape(10.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = TechNavyDark,
                            unfocusedContainerColor = TechNavyDark,
                            focusedBorderColor = TechCyanPrimary,
                            unfocusedBorderColor = TechNavyCard,
                            focusedTextColor = TextPrimaryDark,
                            unfocusedTextColor = TextPrimaryDark
                        ),
                        singleLine = true
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // University ID
                    OutlinedTextField(
                        value = studentIdInput,
                        onValueChange = { studentIdInput = it },
                        label = { Text("الرقم الجامعي (الجامعة الإماراتية EIU)") },
                        placeholder = { Text("EIU-2026-MCE-104") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("student_id_input"),
                        shape = RoundedCornerShape(10.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = TechNavyDark,
                            unfocusedContainerColor = TechNavyDark,
                            focusedBorderColor = TechCyanPrimary,
                            unfocusedBorderColor = TechNavyCard,
                            focusedTextColor = TextPrimaryDark,
                            unfocusedTextColor = TextPrimaryDark
                        ),
                        singleLine = true
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // Phone Number
                    OutlinedTextField(
                        value = studentPhoneInput,
                        onValueChange = { studentPhoneInput = it },
                        label = { Text("رقم هاتف الطالب / واتساب") },
                        placeholder = { Text("مثال: 77xxxxxxx") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("student_phone_input"),
                        shape = RoundedCornerShape(10.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = TechNavyDark,
                            unfocusedContainerColor = TechNavyDark,
                            focusedBorderColor = TechCyanPrimary,
                            unfocusedBorderColor = TechNavyCard,
                            focusedTextColor = TextPrimaryDark,
                            unfocusedTextColor = TextPrimaryDark
                        ),
                        singleLine = true
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // Payment Method Radio Group
                    Text(
                        text = "المحفظة التي تم التحويل منها إلى الرقم $targetPhoneNumber:",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextSecondaryDark
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.clickable { paymentMethod = "محفظة جيب" }
                        ) {
                            RadioButton(
                                selected = paymentMethod == "محفظة جيب",
                                onClick = { paymentMethod = "محفظة جيب" },
                                colors = RadioButtonDefaults.colors(selectedColor = TechCyanPrimary)
                            )
                            Text(text = "محفظة جيب", color = TextPrimaryDark, fontSize = 13.sp)
                        }

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.clickable { paymentMethod = "محفظة جوالي" }
                        ) {
                            RadioButton(
                                selected = paymentMethod == "محفظة جوالي",
                                onClick = { paymentMethod = "محفظة جوالي" },
                                colors = RadioButtonDefaults.colors(selectedColor = TechGoldAccent)
                            )
                            Text(text = "محفظة جوالي", color = TextPrimaryDark, fontSize = 13.sp)
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Transaction Notice / Ref Number
                    OutlinedTextField(
                        value = transactionInput,
                        onValueChange = { transactionInput = it },
                        label = { Text("رقم إشعار الحوالة أو مرجع العملية") },
                        placeholder = { Text("مثال: TXN-8924156 أو رقم السند") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("transaction_number_input"),
                        shape = RoundedCornerShape(10.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = TechNavyDark,
                            unfocusedContainerColor = TechNavyDark,
                            focusedBorderColor = TechCyanPrimary,
                            unfocusedBorderColor = TechNavyCard,
                            focusedTextColor = TextPrimaryDark,
                            unfocusedTextColor = TextPrimaryDark
                        ),
                        singleLine = true
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    // Activation Submit Button
                    Button(
                        onClick = {
                            viewModel.activateSubscription(
                                studentName = studentNameInput,
                                studentId = studentIdInput,
                                studentPhone = studentPhoneInput,
                                paymentMethod = paymentMethod,
                                transactionNumber = transactionInput
                            )
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .testTag("activate_subscription_button"),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = CircuitGreen,
                            contentColor = TechNavyDark
                        )
                    ) {
                        Icon(
                            imageVector = Icons.Default.Verified,
                            contentDescription = null,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "تأكيد وتفعيل الاشتراك الفوري (10 ريال)",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
        }

        // Features & Perks Included in Subscription
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = TechNavySurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, TechNavyCard)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Star,
                            contentDescription = null,
                            tint = TechGoldAccent,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "ما الذي يتيحه لك اشتراك الـ 10 ريال يمني؟",
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                            color = TechGoldAccent
                        )
                    }
                    Spacer(modifier = Modifier.height(10.dp))

                    listOf(
                        "وصول غير محدود لشرح جميع مساقات الميكاترونكس (سنة أولى إلى رابعة) في الجامعة الإماراتية EIU",
                        "المساعد الذكي \"دكتور الميكاترونكس\" لتلخيص المحاضرات الطويلة وتفكيك صور الدوائر والمسائل",
                        "المرجع السريع والجدول البحثي للتحويلات الفيزيائية والأبعاد الأساسية [M L T I Θ]",
                        "معمل ومحلل الدوائر الكهربائية (قوانين أوم، مرشحات RC، ومكبرات العمليات Op-Amp)",
                        "حاسبات المحركات المستمرة DC Motors، التروس ونسب النقل، والمكابس الهيدروليكية",
                        "إشارات مرجعية وحفظ ملخصات المحاضرات واستعادتها دون اتصال بالإنترنت",
                        "نماذج وتجارب معامل كلية الهندسة وتكنولوجيا المعلومات بصنعاء"
                    ).forEach { feature ->
                        Row(
                            modifier = Modifier.padding(vertical = 4.dp),
                            verticalAlignment = Alignment.Top
                        ) {
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = null,
                                tint = CircuitGreen,
                                modifier = Modifier
                                    .padding(top = 2.dp)
                                    .size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = feature,
                                style = MaterialTheme.typography.bodySmall.copy(lineHeight = 18.sp),
                                color = TextPrimaryDark
                            )
                        }
                    }
                }
            }
            Spacer(modifier = Modifier.height(96.dp))
        }
    }
}
