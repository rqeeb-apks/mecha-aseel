package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Mechatronics Tech Palette
val TechNavyDark = Color(0xFF090E17)
val TechNavySurface = Color(0xFF111A29)
val TechNavyCard = Color(0xFF19253B)
val TechNavyElevated = Color(0xFF223250)

val TechCyanPrimary = Color(0xFF00D2D3)
val TechCyanLight = Color(0xFF54E3E4)
val TechTeal = Color(0xFF01A3A4)

val TechGoldAccent = Color(0xFFFF9F43)
val TechGoldLight = Color(0xFFFECA57)

val CircuitGreen = Color(0xFF10AC84)
val LaserRed = Color(0xFFEE5253)

val TextPrimaryDark = Color(0xFFF1F2F6)
val TextSecondaryDark = Color(0xFFA4B0BE)

val LightBackground = Color(0xFFF4F7FB)
val LightSurface = Color(0xFFFFFFFF)
val LightCard = Color(0xFFE9EFF7)
val LightPrimary = Color(0xFF0077B6)
val LightSecondary = Color(0xFF0096C7)

