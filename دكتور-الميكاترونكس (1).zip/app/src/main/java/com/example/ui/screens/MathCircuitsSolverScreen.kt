package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.PrecisionManufacturing
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.WaterDrop
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.MechatronicsViewModel
import com.example.ui.theme.CircuitGreen
import com.example.ui.theme.TechCyanLight
import com.example.ui.theme.TechCyanPrimary
import com.example.ui.theme.TechGoldAccent
import com.example.ui.theme.TechNavyCard
import com.example.ui.theme.TechNavyDark
import com.example.ui.theme.TechNavyElevated
import com.example.ui.theme.TechNavySurface
import com.example.ui.theme.TextPrimaryDark
import com.example.ui.theme.TextSecondaryDark
import kotlin.math.PI

enum class SolverType(val title: String, val icon: ImageVector) {
    OHM("قانون أوم والدوائر", Icons.Default.Bolt),
    RC_FILTER("مرشحات RC وثابت الزمن", Icons.Default.Calculate),
    OP_AMP("مكبر العمليات Op-Amp", Icons.Default.Calculate),
    STEPPER_GEAR("المحركات والتروس", Icons.Default.Speed),
    HYDRAULICS("المكابس الهيدروليكية", Icons.Default.WaterDrop)
}

@Composable
fun MathCircuitsSolverScreen(
    viewModel: MechatronicsViewModel,
    modifier: Modifier = Modifier
) {
    var activeSolver by remember { mutableStateOf(SolverType.OHM) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(TechNavyDark)
    ) {
        // Header
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(TechNavySurface)
                .padding(horizontal = 16.dp, vertical = 14.dp)
        ) {
            Text(
                text = "معمل حل المسائل والدوائر الهندسية",
                style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold),
                color = TextPrimaryDark
            )
            Text(
                text = "حاسبات رياضية وتحليل الدوائر الكهربائية والميكانيكية والهيدروليكية",
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondaryDark
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Solver selector chips
            LazyRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(SolverType.values().size) { index ->
                    val type = SolverType.values()[index]
                    val isSelected = activeSolver == type
                    FilterChip(
                        selected = isSelected,
                        onClick = { activeSolver = type },
                        label = { Text(type.title) },
                        leadingIcon = {
                            Icon(
                                imageVector = type.icon,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp),
                                tint = if (isSelected) TechNavyDark else TechCyanPrimary
                            )
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = TechCyanPrimary,
                            selectedLabelColor = TechNavyDark,
                            containerColor = TechNavyCard,
                            labelColor = TextPrimaryDark
                        ),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.testTag("solver_chip_${type.name}")
                    )
                }
            }
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp)
        ) {
            item {
                when (activeSolver) {
                    SolverType.OHM -> OhmCircuitSolver(viewModel = viewModel)
                    SolverType.RC_FILTER -> RcFilterSolver(viewModel = viewModel)
                    SolverType.OP_AMP -> OpAmpGainSolver(viewModel = viewModel)
                    SolverType.STEPPER_GEAR -> StepperGearSolver(viewModel = viewModel)
                    SolverType.HYDRAULICS -> HydraulicPistonSolver()
                }
            }
        }
    }
}

@Composable
fun OhmCircuitSolver(viewModel: MechatronicsViewModel) {
    val voltage by viewModel.ohmVoltage.collectAsState()
    val current by viewModel.ohmCurrent.collectAsState()
    val resistance by viewModel.ohmResistance.collectAsState()
    val power by viewModel.ohmPower.collectAsState()

    var inputV by remember { mutableStateOf(voltage) }
    var inputI by remember { mutableStateOf(current) }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = TechNavySurface)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = "قانون أوم وحساب القدرة الكهربائية المبددة",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = TechCyanPrimary
            )
            Text(
                text = "حساب المقاومة R وتيار الحمل I والقدرة P في دوائر الميكاترونكس والحساسات",
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondaryDark
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Inputs
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = inputV,
                    onValueChange = {
                        inputV = it
                        viewModel.calculateOhmFromVI(inputV, inputI)
                    },
                    label = { Text("الجهد V (فولت)") },
                    modifier = Modifier.weight(1f),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    shape = RoundedCornerShape(10.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = TechNavyDark,
                        unfocusedContainerColor = TechNavyDark,
                        focusedTextColor = TextPrimaryDark,
                        unfocusedTextColor = TextPrimaryDark
                    )
                )

                OutlinedTextField(
                    value = inputI,
                    onValueChange = {
                        inputI = it
                        viewModel.calculateOhmFromVI(inputV, inputI)
                    },
                    label = { Text("التيار I (أمبير)") },
                    modifier = Modifier.weight(1f),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    shape = RoundedCornerShape(10.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = TechNavyDark,
                        unfocusedContainerColor = TechNavyDark,
                        focusedTextColor = TextPrimaryDark,
                        unfocusedTextColor = TextPrimaryDark
                    )
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Calculated Output Cards
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(12.dp))
                        .background(TechNavyDark)
                        .border(1.dp, TechCyanPrimary.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                        .padding(14.dp)
                ) {
                    Column {
                        Text(text = "المقاومة المكافئة R", style = MaterialTheme.typography.labelSmall, color = TechCyanLight)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "$resistance Ω",
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            ),
                            color = TextPrimaryDark
                        )
                        Text(text = "R = V / I", style = MaterialTheme.typography.labelSmall, color = TextSecondaryDark)
                    }
                }

                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(12.dp))
                        .background(TechNavyDark)
                        .border(1.dp, TechGoldAccent.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                        .padding(14.dp)
                ) {
                    Column {
                        Text(text = "القدرة المبددة P", style = MaterialTheme.typography.labelSmall, color = TechGoldAccent)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "$power W",
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            ),
                            color = TextPrimaryDark
                        )
                        Text(text = "P = V × I", style = MaterialTheme.typography.labelSmall, color = TextSecondaryDark)
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Explanation & Tip
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(Color(0xFF142436))
                    .padding(12.dp)
            ) {
                Text(
                    text = "💡 نصيحة دكتور الميكاترونكس: اختر دائماً قدرة المقاومة الفيزيائية (Wattage Rating) بضعف القدرة المحسوبة على الأقل (مثلاً لمقاومة تبدد 0.3W استخدم مقاومة 0.5W أو 1W) حتى لا ترتفع حرارتها في لوحة التجارب.",
                    style = MaterialTheme.typography.bodySmall.copy(lineHeight = 18.sp),
                    color = TextPrimaryDark
                )
            }
        }
    }
}

@Composable
fun RcFilterSolver(viewModel: MechatronicsViewModel) {
    val resistance by viewModel.rcResistance.collectAsState()
    val capacitance by viewModel.rcCapacitance.collectAsState()
    val timeConstant by viewModel.rcTimeConstant.collectAsState()
    val cutoffFreq by viewModel.rcCutoffFreq.collectAsState()

    var inputR by remember { mutableStateOf(resistance) }
    var inputC by remember { mutableStateOf(capacitance) }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = TechNavySurface)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = "مرشحات RC التماثلية وثابت الزمن τ",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = TechCyanPrimary
            )
            Text(
                text = "تصفية الضوضاء لحساسات الميكاترونكس وتحديد تردد القطع Cutoff Frequency",
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondaryDark
            )

            Spacer(modifier = Modifier.height(16.dp))

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = inputR,
                    onValueChange = {
                        inputR = it
                        viewModel.calculateRcFilter(inputR, inputC)
                    },
                    label = { Text("المقاومة R (kΩ)") },
                    modifier = Modifier.weight(1f),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    shape = RoundedCornerShape(10.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = TechNavyDark,
                        unfocusedContainerColor = TechNavyDark,
                        focusedTextColor = TextPrimaryDark,
                        unfocusedTextColor = TextPrimaryDark
                    )
                )

                OutlinedTextField(
                    value = inputC,
                    onValueChange = {
                        inputC = it
                        viewModel.calculateRcFilter(inputR, inputC)
                    },
                    label = { Text("السعة C (nF)") },
                    modifier = Modifier.weight(1f),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    shape = RoundedCornerShape(10.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = TechNavyDark,
                        unfocusedContainerColor = TechNavyDark,
                        focusedTextColor = TextPrimaryDark,
                        unfocusedTextColor = TextPrimaryDark
                    )
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(12.dp))
                        .background(TechNavyDark)
                        .border(1.dp, CircuitGreen.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                        .padding(14.dp)
                ) {
                    Column {
                        Text(text = "ثابت الزمن τ", style = MaterialTheme.typography.labelSmall, color = CircuitGreen)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = timeConstant,
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            ),
                            color = TextPrimaryDark
                        )
                        Text(text = "τ = R × C", style = MaterialTheme.typography.labelSmall, color = TextSecondaryDark)
                    }
                }

                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(12.dp))
                        .background(TechNavyDark)
                        .border(1.dp, TechCyanPrimary.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                        .padding(14.dp)
                ) {
                    Column {
                        Text(text = "تردد القطع fc (-3dB)", style = MaterialTheme.typography.labelSmall, color = TechCyanLight)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = cutoffFreq,
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            ),
                            color = TextPrimaryDark
                        )
                        Text(text = "fc = 1 / (2πRC)", style = MaterialTheme.typography.labelSmall, color = TextSecondaryDark)
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))
            Text(
                text = "يصل جهد المكثف إلى 63.2% من القيمة النهائية بعد زمن 1τ وإلى 99.3% بعد زمن 5τ.",
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondaryDark
            )
        }
    }
}

@Composable
fun OpAmpGainSolver(viewModel: MechatronicsViewModel) {
    val rf by viewModel.opAmpRf.collectAsState()
    val rin by viewModel.opAmpRin.collectAsState()
    val invGain by viewModel.opAmpInvertingGain.collectAsState()
    val nonInvGain by viewModel.opAmpNonInvertingGain.collectAsState()

    var inputRf by remember { mutableStateOf(rf) }
    var inputRin by remember { mutableStateOf(rin) }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = TechNavySurface)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = "مكبر العمليات (Operational Amplifier Gain)",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = TechCyanPrimary
            )
            Text(
                text = "مواءمة وتكبير إشارات حساسات الميكاترونكس التماثلية (Gain Av)",
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondaryDark
            )

            Spacer(modifier = Modifier.height(16.dp))

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = inputRf,
                    onValueChange = {
                        inputRf = it
                        viewModel.calculateOpAmp(inputRf, inputRin)
                    },
                    label = { Text("مقاومة التغذية Rf (kΩ)") },
                    modifier = Modifier.weight(1f),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    shape = RoundedCornerShape(10.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = TechNavyDark,
                        unfocusedContainerColor = TechNavyDark,
                        focusedTextColor = TextPrimaryDark,
                        unfocusedTextColor = TextPrimaryDark
                    )
                )

                OutlinedTextField(
                    value = inputRin,
                    onValueChange = {
                        inputRin = it
                        viewModel.calculateOpAmp(inputRf, inputRin)
                    },
                    label = { Text("مقاومة الدخل Rin (kΩ)") },
                    modifier = Modifier.weight(1f),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    shape = RoundedCornerShape(10.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = TechNavyDark,
                        unfocusedContainerColor = TechNavyDark,
                        focusedTextColor = TextPrimaryDark,
                        unfocusedTextColor = TextPrimaryDark
                    )
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(12.dp))
                        .background(TechNavyDark)
                        .border(1.dp, TechGoldAccent.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                        .padding(14.dp)
                ) {
                    Column {
                        Text(text = "المكبر العاكس (Inverting)", style = MaterialTheme.typography.labelSmall, color = TechGoldAccent)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = invGain,
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            ),
                            color = TextPrimaryDark
                        )
                        Text(text = "Av = - Rf / Rin", style = MaterialTheme.typography.labelSmall, color = TextSecondaryDark)
                    }
                }

                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(12.dp))
                        .background(TechNavyDark)
                        .border(1.dp, TechCyanPrimary.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                        .padding(14.dp)
                ) {
                    Column {
                        Text(text = "غير العاكس (Non-Inverting)", style = MaterialTheme.typography.labelSmall, color = TechCyanLight)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = nonInvGain,
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            ),
                            color = TextPrimaryDark
                        )
                        Text(text = "Av = 1 + (Rf / Rin)", style = MaterialTheme.typography.labelSmall, color = TextSecondaryDark)
                    }
                }
            }
        }
    }
}

@Composable
fun StepperGearSolver(viewModel: MechatronicsViewModel) {
    val angle by viewModel.stepperAngle.collectAsState()
    val freq by viewModel.stepperFreq.collectAsState()
    val ratio by viewModel.gearRatio.collectAsState()
    val motorRpm by viewModel.stepperSpeedRpm.collectAsState()
    val outputRpm by viewModel.outputSpeedRpm.collectAsState()

    var inputAngle by remember { mutableStateOf(angle) }
    var inputFreq by remember { mutableStateOf(freq) }
    var inputRatio by remember { mutableStateOf(ratio) }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = TechNavySurface)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = "محركات الخطوة (Stepper) ونسب التروس Gear Ratio",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = TechCyanPrimary
            )
            Text(
                text = "حساب سرعة دوران عمود المحرك وسرعة المستجيب النهائي للروبوت",
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondaryDark
            )

            Spacer(modifier = Modifier.height(16.dp))

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = inputAngle,
                    onValueChange = {
                        inputAngle = it
                        viewModel.calculateStepper(inputAngle, inputFreq, inputRatio)
                    },
                    label = { Text("زاوية الخطوة (°)") },
                    modifier = Modifier.weight(1f),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    shape = RoundedCornerShape(10.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = TechNavyDark,
                        unfocusedContainerColor = TechNavyDark,
                        focusedTextColor = TextPrimaryDark,
                        unfocusedTextColor = TextPrimaryDark
                    )
                )

                OutlinedTextField(
                    value = inputFreq,
                    onValueChange = {
                        inputFreq = it
                        viewModel.calculateStepper(inputAngle, inputFreq, inputRatio)
                    },
                    label = { Text("التردد (Hz)") },
                    modifier = Modifier.weight(1f),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    shape = RoundedCornerShape(10.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = TechNavyDark,
                        unfocusedContainerColor = TechNavyDark,
                        focusedTextColor = TextPrimaryDark,
                        unfocusedTextColor = TextPrimaryDark
                    )
                )

                OutlinedTextField(
                    value = inputRatio,
                    onValueChange = {
                        inputRatio = it
                        viewModel.calculateStepper(inputAngle, inputFreq, inputRatio)
                    },
                    label = { Text("نسبة التروس (i)") },
                    modifier = Modifier.weight(1f),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    shape = RoundedCornerShape(10.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = TechNavyDark,
                        unfocusedContainerColor = TechNavyDark,
                        focusedTextColor = TextPrimaryDark,
                        unfocusedTextColor = TextPrimaryDark
                    )
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(12.dp))
                        .background(TechNavyDark)
                        .border(1.dp, TechCyanPrimary.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                        .padding(14.dp)
                ) {
                    Column {
                        Text(text = "سرعة المحرك Motor RPM", style = MaterialTheme.typography.labelSmall, color = TechCyanLight)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = motorRpm,
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            ),
                            color = TextPrimaryDark
                        )
                    }
                }

                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(12.dp))
                        .background(TechNavyDark)
                        .border(1.dp, CircuitGreen.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                        .padding(14.dp)
                ) {
                    Column {
                        Text(text = "سرعة خرج صندوق التروس", style = MaterialTheme.typography.labelSmall, color = CircuitGreen)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = outputRpm,
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            ),
                            color = TextPrimaryDark
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun HydraulicPistonSolver() {
    var pressureBar by remember { mutableStateOf("100.0") } // Bar
    var pistonDiameterMm by remember { mutableStateOf("50.0") } // mm

    val pBar = pressureBar.toDoubleOrNull() ?: 0.0
    val dMm = pistonDiameterMm.toDoubleOrNull() ?: 0.0

    // Calculations
    val dMeter = dMm / 1000.0
    val areaM2 = (PI * dMeter * dMeter) / 4.0
    val pPascal = pBar * 100000.0
    val forceNewton = pPascal * areaM2
    val forceKn = forceNewton / 1000.0
    val forceKgf = forceNewton / 9.80665

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = TechNavySurface)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = "قوة المكبس الهيدروليكي (Hydraulic Cylinder Force)",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = TechCyanPrimary
            )
            Text(
                text = "حساب قوة الدفع F والمساحة الفعالة A لأسطوانات الهيدروليك الصناعية",
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondaryDark
            )

            Spacer(modifier = Modifier.height(16.dp))

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = pressureBar,
                    onValueChange = { pressureBar = it },
                    label = { Text("ضغط الزيت (Bar)") },
                    modifier = Modifier.weight(1f),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    shape = RoundedCornerShape(10.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = TechNavyDark,
                        unfocusedContainerColor = TechNavyDark,
                        focusedTextColor = TextPrimaryDark,
                        unfocusedTextColor = TextPrimaryDark
                    )
                )

                OutlinedTextField(
                    value = pistonDiameterMm,
                    onValueChange = { pistonDiameterMm = it },
                    label = { Text("قطر المكبس D (mm)") },
                    modifier = Modifier.weight(1f),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    shape = RoundedCornerShape(10.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = TechNavyDark,
                        unfocusedContainerColor = TechNavyDark,
                        focusedTextColor = TextPrimaryDark,
                        unfocusedTextColor = TextPrimaryDark
                    )
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(12.dp))
                        .background(TechNavyDark)
                        .border(1.dp, TechGoldAccent.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                        .padding(14.dp)
                ) {
                    Column {
                        Text(text = "قوة الدفع (kN)", style = MaterialTheme.typography.labelSmall, color = TechGoldAccent)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = String.format("%.2f kN", forceKn),
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            ),
                            color = TextPrimaryDark
                        )
                        Text(text = "F = P × A", style = MaterialTheme.typography.labelSmall, color = TextSecondaryDark)
                    }
                }

                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(12.dp))
                        .background(TechNavyDark)
                        .border(1.dp, CircuitGreen.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                        .padding(14.dp)
                ) {
                    Column {
                        Text(text = "القوة بالكيلوجرام قوة", style = MaterialTheme.typography.labelSmall, color = CircuitGreen)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = String.format("%.0f kgf", forceKgf),
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            ),
                            color = TextPrimaryDark
                        )
                        Text(text = "≈ رفع ${String.format("%.1f", forceKgf / 1000.0)} طن", style = MaterialTheme.typography.labelSmall, color = TextSecondaryDark)
                    }
                }
            }
        }
    }
}
