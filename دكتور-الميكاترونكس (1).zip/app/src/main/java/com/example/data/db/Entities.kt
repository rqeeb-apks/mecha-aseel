package com.example.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "student_profile")
data class StudentProfileEntity(
    @PrimaryKey val id: Int = 1,
    val studentName: String = "مهندس ميكاترونكس",
    val studentId: String = "EIU-2026-MCE",
    val academicYear: Int = 2,
    val isSubscribed: Boolean = false,
    val subscriptionDate: Long = 0L,
    val subscriptionExpireDate: Long = 0L,
    val paymentMethod: String = "محفظة جيب",
    val transactionNumber: String = "",
    val studentPhone: String = ""
)

@Entity(tableName = "saved_summaries")
data class SavedSummaryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val title: String,
    val type: String, // "TEXT" or "IMAGE"
    val originalSnippet: String,
    val summaryResult: String,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "bookmarked_lessons")
data class BookmarkedLessonEntity(
    @PrimaryKey val lessonId: String,
    val subjectId: String,
    val yearId: Int,
    val title: String,
    val arabicTitle: String,
    val savedAt: Long = System.currentTimeMillis()
)
