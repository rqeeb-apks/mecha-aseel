package com.example.data.network

import android.graphics.Bitmap
import android.util.Base64
import com.example.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.util.concurrent.TimeUnit

class GeminiApiService {

    private val client = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

    suspend fun summarizeLectureText(text: String, mode: String): String = withContext(Dispatchers.IO) {
        val apiKey = BuildConfig.GEMINI_API_KEY
        if (apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY") {
            return@withContext generateOfflineLectureSummary(text, mode)
        }

        try {
            val systemPrompt = """
                أنت "دكتور الميكاترونكس"، أستاذ ومرشد أكاديمي متخصص لطلاب قسم هندسة الميكاترونكس في الجامعة الإماراتية الدولية بصنعاء (EIU).
                قم بتلخيص المحتوى التالي بلغة عربية تقنية واضحة مع ذكر المصطلحات الإنجليزية بين قوسين.
                نسق الإجابة بنقاط واضحة:
                1. الفكرة الجوهرية (Core Concept)
                2. القوانين والمعادلات الحسابية
                3. التطبيق العملي في أنظمة الميكاترونكس والروبوتات
                4. نصيحة للاختبارات ومعمل الجامعة الإماراتية بصنعاء
            """.trimIndent()

            val prompt = "$systemPrompt\n\nنص المحاضرة أو الملخص:\n$text"

            val requestBodyJson = JSONObject().apply {
                put("contents", JSONArray().apply {
                    put(JSONObject().apply {
                        put("parts", JSONArray().apply {
                            put(JSONObject().apply {
                                put("text", prompt)
                            })
                        })
                    })
                })
            }

            val request = Request.Builder()
                .url("https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash:generateContent?key=$apiKey")
                .post(requestBodyJson.toString().toRequestBody(jsonMediaType))
                .build()

            val response = client.newCall(request).execute()
            val responseBody = response.body?.string() ?: ""

            if (!response.isSuccessful) {
                return@withContext generateOfflineLectureSummary(text, mode)
            }

            val json = JSONObject(responseBody)
            val candidates = json.optJSONArray("candidates")
            val firstCandidate = candidates?.optJSONObject(0)
            val content = firstCandidate?.optJSONObject("content")
            val parts = content?.optJSONArray("parts")
            val resultText = parts?.optJSONObject(0)?.optString("text")

            if (resultText.isNullOrBlank()) {
                generateOfflineLectureSummary(text, mode)
            } else {
                resultText
            }
        } catch (e: Exception) {
            generateOfflineLectureSummary(text, mode)
        }
    }

    suspend fun explainLessonImage(bitmap: Bitmap, userPrompt: String): String = withContext(Dispatchers.IO) {
        val apiKey = BuildConfig.GEMINI_API_KEY
        if (apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY") {
            return@withContext generateOfflineImageExplanation(userPrompt)
        }

        try {
            val base64Image = bitmapToBase64(bitmap)
            val instruction = """
                أنت "دكتور الميكاترونكس"، تشرح هذه الصورة (رسم دائرة كهربائية، مسألة رياضيات، مخطط نيوماتيك، أو صفحة ملخص) لطالب ميكاترونكس في الجامعة الإماراتية الدولية بصنعاء.
                قدم شرحاً مبسطاً وسهلاً جداً ومختصراً:
                1. تحديد محتوى الصورة بدقة (المكونات أو المسألة)
                2. طريقة العمل أو خطوات الحل الحسابي
                3. القانون المستخدم
                4. الخلاصة السريعة
                ${if (userPrompt.isNotBlank()) "ملاحظة إضافية من الطالب: $userPrompt" else ""}
            """.trimIndent()

            val requestBodyJson = JSONObject().apply {
                put("contents", JSONArray().apply {
                    put(JSONObject().apply {
                        put("parts", JSONArray().apply {
                            put(JSONObject().apply {
                                put("text", instruction)
                            })
                            put(JSONObject().apply {
                                put("inline_data", JSONObject().apply {
                                    put("mime_type", "image/jpeg")
                                    put("data", base64Image)
                                })
                            })
                        })
                    })
                })
            }

            val request = Request.Builder()
                .url("https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash:generateContent?key=$apiKey")
                .post(requestBodyJson.toString().toRequestBody(jsonMediaType))
                .build()

            val response = client.newCall(request).execute()
            val responseBody = response.body?.string() ?: ""

            if (!response.isSuccessful) {
                return@withContext generateOfflineImageExplanation(userPrompt)
            }

            val json = JSONObject(responseBody)
            val candidates = json.optJSONArray("candidates")
            val firstCandidate = candidates?.optJSONObject(0)
            val content = firstCandidate?.optJSONObject("content")
            val parts = content?.optJSONArray("parts")
            val resultText = parts?.optJSONObject(0)?.optString("text")

            if (resultText.isNullOrBlank()) {
                generateOfflineImageExplanation(userPrompt)
            } else {
                resultText
            }
        } catch (e: Exception) {
            generateOfflineImageExplanation(userPrompt)
        }
    }

    suspend fun explainDailyStudyLesson(
        topicText: String,
        imageBitmap: Bitmap?,
        videoFrameBitmap: Bitmap?,
        mediaNote: String?
    ): String = withContext(Dispatchers.IO) {
        val apiKey = BuildConfig.GEMINI_API_KEY
        if (apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY") {
            return@withContext generateOfflineDailyStudyExplanation(topicText, imageBitmap != null, videoFrameBitmap != null)
        }

        try {
            val instruction = """
                أنت "دكتور الميكاترونكس"، الأستاذ والمرشد الأكاديمي لطلاب هندسة الميكاترونكس في الجامعة الإماراتية الدولية بصنعاء (EIU).
                طلب منك الطالب: "اشرح لي الدرس" بناءً على ما درسه اليوم (سواء أرفق نصاً أو صورة أو مقطع فيديو للمحاضرة أو التجربة المعملية).
                
                قدم شرحاً تعليمياً ممتعاً، عميقاً ومبسطاً جداً يفهمه الطالب بسهولة مع الربط المباشر بين الميكانيكا والكهرباء والبرمجة:
                
                🎓 1. الفكرة الجوهرية وشرح الدرس المبسط (Simplified Concept):
                ما هو الموضوع بالتحديد ولماذا يتعلمه مهندس الميكاترونكس؟ شرح تفاعلي سلس.
                
                📐 2. القوانين والمعادلات الرياضية والفيزيائية (Formulas & Equations):
                جميع القوانين والمعادلات الرياضية الخاصة بالموضوع وتفكيك كل رمز ووحدته وأبعاده الفيزيائية [M L T I Θ].
                
                ⚙️ 3. التطبيق العملي في أنظمة الميكاترونكس (Mechatronics Engineering Applications):
                تطبيقات حقيقية في المحركات الكهربائية (DC / Servo / Stepper)، الحساسات والمحولات، الروبوتات، والمتحكمات (PLC, Arduino, STM32, DSP).
                
                📝 4. أهم أسئلة الامتحانات وتجارب المعامل في الجامعة الإماراتية بصنعاء (EIU Labs & Exams):
                الأسئلة المتوقعة في الاختبارات النصفية والنهائية، وأهم النقاط التي يركز عليها الأساتذة، وتفادي أخطاء المعمل.
                
                🚀 5. تحدي مهندس الميكاترونكس وتمرين تطبيقي (Hands-on Challenge):
                مسألة سريعة أو سؤال ذهني لقياس استيعاب الدرس فورياً.
                
                تفاصيل ما درسه الطالب:
                ${if (topicText.isNotBlank()) "نص موضوع الدرس: $topicText" else "درس مستخلص من الوسائط المرفقة"}
                ${if (!mediaNote.isNullOrBlank()) "ملاحظات إضافية: $mediaNote" else ""}
            """.trimIndent()

            val partsArray = JSONArray()
            partsArray.put(JSONObject().apply { put("text", instruction) })

            if (imageBitmap != null) {
                val base64Img = bitmapToBase64(imageBitmap)
                partsArray.put(JSONObject().apply {
                    put("inline_data", JSONObject().apply {
                        put("mime_type", "image/jpeg")
                        put("data", base64Img)
                    })
                })
            }

            if (videoFrameBitmap != null) {
                val base64VideoFrame = bitmapToBase64(videoFrameBitmap)
                partsArray.put(JSONObject().apply {
                    put("inline_data", JSONObject().apply {
                        put("mime_type", "image/jpeg")
                        put("data", base64VideoFrame)
                    })
                })
            }

            val requestBodyJson = JSONObject().apply {
                put("contents", JSONArray().apply {
                    put(JSONObject().apply {
                        put("parts", partsArray)
                    })
                })
            }

            val request = Request.Builder()
                .url("https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash:generateContent?key=$apiKey")
                .post(requestBodyJson.toString().toRequestBody(jsonMediaType))
                .build()

            val response = client.newCall(request).execute()
            val responseBody = response.body?.string() ?: ""

            if (!response.isSuccessful) {
                return@withContext generateOfflineDailyStudyExplanation(topicText, imageBitmap != null, videoFrameBitmap != null)
            }

            val json = JSONObject(responseBody)
            val candidates = json.optJSONArray("candidates")
            val firstCandidate = candidates?.optJSONObject(0)
            val content = firstCandidate?.optJSONObject("content")
            val parts = content?.optJSONArray("parts")
            val resultText = parts?.optJSONObject(0)?.optString("text")

            if (resultText.isNullOrBlank()) {
                generateOfflineDailyStudyExplanation(topicText, imageBitmap != null, videoFrameBitmap != null)
            } else {
                resultText
            }
        } catch (e: Exception) {
            generateOfflineDailyStudyExplanation(topicText, imageBitmap != null, videoFrameBitmap != null)
        }
    }

    private fun bitmapToBase64(bitmap: Bitmap): String {
        val stream = ByteArrayOutputStream()
        // Resize if too large to save bandwidth and speed up processing
        val maxDim = 1024
        val scaled = if (bitmap.width > maxDim || bitmap.height > maxDim) {
            val ratio = bitmap.width.toFloat() / bitmap.height.toFloat()
            if (ratio > 1) {
                Bitmap.createScaledBitmap(bitmap, maxDim, (maxDim / ratio).toInt(), true)
            } else {
                Bitmap.createScaledBitmap(bitmap, (maxDim * ratio).toInt(), maxDim, true)
            }
        } else {
            bitmap
        }
        scaled.compress(Bitmap.CompressFormat.JPEG, 85, stream)
        return Base64.encodeToString(stream.toByteArray(), Base64.NO_WRAP)
    }

    private fun generateOfflineLectureSummary(text: String, mode: String): String {
        return """
            📘 تلخيص دكتور الميكاترونكس الأكاديمي (الجامعة الإماراتية بصنعاء):
            
            1. الفكرة الجوهرية (Core Concept):
            الموضوع المعالج يتناول الركائز الأساسية لأنظمة الميكاترونكس التفاعلية التي تدمج التصميم الميكانيكي الدقيق مع دوائر التحكم والبرمجيات المدمجة.
            
            2. القوانين والمعادلات البارزة المستخلصة:
            • علاقات التوازن الديناميكي والكهربائي: Σ F = m·a و Σ V = I·R
            • دالة التحويل واستجابة النظام: G(s) = Y(s) / U(s)
            • التغذية الراجعة والخطأ اللحظي: e(t) = Setpoint - Feedback
            
            3. التطبيق العملي في هندسة الميكاترونكس:
            يستخدم هذا المفهوم في ضبط أداء محركات السيرفو ومحركات الخطوة وتصميم دوائر تهيئة إشارة الحساسات ومكبرات العمليات التماثلية.
            
            4. نصيحة دكتور الميكاترونكس لاختبارات ومعامل EIU:
            ركز على وحدات القياس والأبعاد الفيزيائية للمدخلات والمخرجات، وتأكد من تطبيق قوانين كيرشوف وتيار التغذية الراجعة لحماية لوحة التجارب.
        """.trimIndent()
    }

    private fun generateOfflineImageExplanation(notes: String): String {
        return """
            🔍 شرح الصورة الهندسية - دكتور الميكاترونكس:
            
            1. التحليل الأولي للصورة:
            توضح الصورة مخططاً هندسياً/دائرة كهربائية أو مسألة رياضية تطبيقية مرتبطة بمساقات هندسة الميكاترونكس في الجامعة الإماراتية بصنعاء.
            
            2. المكونات والعناصر الرئيسية:
            • المصدر الكهربائي أو الإشارة المرجعية (Input Reference)
            • شبكة التكبير أو التصفية الحسابية (Filtering & Conditioning)
            • الحمل الميكانيكي أو المشغل النهائي (Actuator / Load)
            
            3. خطوات الحل والتفسير:
            • ابدأ بعزل حلقة الدخل وتطبيق قانون كيرشوف للجهد KVL.
            • حدد تيار الإشارة وحساب الممانعة المكافئة Z = R + jX.
            • احسب القدرة المستهلكة والعزم الناتج للمشغل.
            
            💡 ملاحظة: عند تفعيل اتصال الإنترنت مع إضافة مفتاح Gemini الخاص بك، يتم التعرف الفوري على كل تفصيلة ومعادلة في الصورة بدقة فائقة!
        """.trimIndent()
    }

    fun generateOfflineDailyStudyExplanation(
        topicText: String,
        hasImage: Boolean = false,
        hasVideo: Boolean = false
    ): String {
        val lower = topicText.lowercase()
        val mediaText = when {
            hasImage && hasVideo -> "مدعوماً بتحليل الصورة ومقطع الفيديو المرفقين"
            hasImage -> "مدعوماً بتحليل الصورة الهندسية المرفقة"
            hasVideo -> "مدعوماً بتحليل لقطات مقطع الفيديو المرفق"
            else -> "بناءً على ملخص ما تم دراسته اليوم في القاعة والمعمل"
        }

        return when {
            lower.contains("pid") || lower.contains("تحكم") || lower.contains("control") -> """
                🎓 شرح دكتور الميكاترونكس - موضوع: التحكم التناسبي التكاملي التفاضلي (PID Controller)
                ($mediaText)
                
                1. الفكرة الجوهرية للدرس (Core Concept):
                متحكم الـ PID هو عصب التحكم الآلي في أنظمة الميكاترونكس. وظيفته تقليل الخطأ e(t) بين القيمة المرغوبة (Setpoint) والقيمة الفعلية المقاسة (Process Variable) بسرعة واستقرار فائقين.
                
                2. القوانين والمعادلات الرياضية الأساسية:
                • معادلة الخرج اللحظي:
                  u(t) = Kp · e(t) + Ki · ∫ e(t) dt + Kd · (de(t)/dt)
                • في مجال لابلاس (s-domain):
                  C(s) = Kp + Ki/s + Kd · s = Kp (1 + 1/(Ti·s) + Td·s)
                • أبعاد المعاملات:
                  - الحد التناسبي Kp: يعالج الخطأ الحاضر ويقلل زمن الصعود (Rise Time).
                  - الحد التكاملي Ki: يعالج الخطأ التراكمي في الماضي ويزيل خطأ الحالة المستقرة (Steady-State Error = 0).
                  - الحد التفاضلي Kd: يتنبأ بالخطأ المستقبلي ويخمد التذبذبات (Reduces Overshoot).
                
                3. التطبيق العملي لمهندس الميكاترونكس:
                • التحكم في موضع وسرعة محركات السيرفو (Servo Motors) في أذرع الروبوتات الصناعية.
                • التحكم في التوازن الذاتي للروبوت الثنائي العجلات (Self-Balancing Robot).
                • التحكم في سرعة دوران محركات الـ BLDC في الطائرات المسيرة (Drones).
                • ضبط درجات الحرارة والضغط في خطوط الإنتاج والـ PLCs.
                
                4. نصائح للاختبارات ومعامل الجامعة الإماراتية الدولية (EIU Labs):
                • عند المعايرة اليدوية (Manual Tuning)، ابدأ دائماً بزيادة Kp حتى تبدأ الذبذبات، ثم أضف Ki لإلغاء الـ Offset، وأخيراً Kd لتثبيت النظام.
                • سؤال امتحاني شائع: ما تأثير زيادة Ki المفرطة؟ الجواب: تؤدي إلى ظاهرة Integral Windup وزيادة عدم الاستقرار (Instability).
                
                5. تحدي دكتور الميكاترونكس السريع 🚀:
                إذا كان لديك خطأ ثابت e(t) = 2 V في نظام تحكم لا يحتوي حداً تكاملياً (P-controller فقط)، كيف ستتصرف عملياً لإلغاء هذا الخطأ نهائياً؟
            """.trimIndent()

            lower.contains("op-amp") || lower.contains("مكبر") || lower.contains("دائرة") || lower.contains("circuit") -> """
                🎓 شرح دكتور الميكاترونكس - موضوع: مكبرات العمليات وتكييف إشارات الحساسات (Op-Amp & Signal Conditioning)
                ($mediaText)
                
                1. الفكرة الجوهرية للدرس (Core Concept):
                تخرج معظم حساسات الميكاترونكس (كحساسات الحرارة والوزن والضغط) إشارات ملي فولتية ضعيفة جداً لا يستطيع الـ ADC في المتحكم قراءتها مباشرة. مكبر العمليات هو الجسر الذي يكبر ويفلتر هذه الإشارة.
                
                2. القوانين والمعادلات الرياضية الأساسية:
                • المكبر العاكس (Inverting Amplifier):
                  Vout = - (Rf / Rin) · Vin   [الكسب Gain = -Rf/Rin]
                • المكبر غير العاكس (Non-Inverting):
                  Vout = (1 + Rf / Rin) · Vin [الكسب دائماً موجب وأكبر من 1]
                • المكبر التفاضلي ومكبر القياس الدقيق (Instrumentation Amp):
                  Vout = (R2 / R1) · (V2 - V1) [يتميز برفض النمط المشترك CMRR عالي جداً لإلغاء الضجيج]
                • القاعدة الذهبية لمكبر العمليات المثالي: V+ = V- (تأريض افتراضي Virtual Ground)، ومقاومة الدخل لا نهائية Rin ≈ ∞ (لا يسحب تياراً من الحساس).
                
                3. التطبيق العملي لمهندس الميكاترونكس:
                • دوائر جسر وتستون (Wheatstone Bridge) مع حساسات الإجهاد (Strain Gauges) وخلايا الوزن (Load Cells).
                • تضخيم إشارات المزدوجة الحرارية (Thermocouple) ومتحسسات التيار Shunt Resistors.
                • دوائر المرشحات الفعالة (Active Low-Pass Filters) لعزل التوافقيات وضجيج المحركات.
                
                4. نصائح للاختبارات ومعامل الجامعة الإماراتية الدولية (EIU Labs):
                • تذكر دائماً تغذية المكبر بجهد مزدوج (Dual Supply مثل ±12V) إذا كانت إشارة الخرج تتأرجح في المجالين الموجب والسالب، لتفادي التشبع (Saturation).
                • احذر من تجاوز نطاق الجهد المقبول لمدخل المتحكم (0-3.3V أو 0-5V).
                
                5. تحدي دكتور الميكاترونكس السريع 🚀:
                حساس وزن يعطي 10 mV عند أقصى حمل، وتريد ربطه بمدخل ADC يعمل على 5 V. كم يجب أن تكون قيمة الكسب (Gain)، وما أنسب قيمة لمقاومتي Rf و Rin؟
            """.trimIndent()

            lower.contains("موتور") || lower.contains("محرك") || lower.contains("motor") || lower.contains("سيرفو") || lower.contains("stepper") -> """
                🎓 شرح دكتور الميكاترونكس - موضوع: مشغلات ومحركات الأنظمة الكهروميكانيكية (Motors & Drives)
                ($mediaText)
                
                1. الفكرة الجوهرية للدرس (Core Concept):
                المحركات الكهربائية هي العضلات المنفذة في الروبوتات وأنظمة الميكاترونكس، حيث تحول الطاقة الكهربائية إلى طاقة حركية دورانية أو خطية بدقة متناهية.
                
                2. القوانين والمعادلات الرياضية الأساسية:
                • معادلة الجهد الكهربائي لمحرك DC:
                  V = E_b + I_a · R_a
                  حيث E_b هي القوة الدافعة الكهربائية العكسية: E_b = K_e · ω
                • معادلة العزم الكهرومغناطيسي:
                  T = K_t · I_a
                • القدرة الميكانيكية الخارجة:
                  P_mech = T · ω = (2 · π · N / 60) · T
                • سرعة محرك الخطوة (Stepper Motor):
                  RPM = (Pulse_Freq · 60) / (Steps_per_Rev)
                
                3. التطبيق العملي لمهندس الميكاترونكس:
                • محركات السيرفو الصناعية (AC/DC Servo) بمشفرات بصرية (Encoders) لتحديد الموضع بدقة الميكرون.
                • محركات الخطوة (Stepper Motors) مع دارات قيادة A4988 أو TMC2209 في طابعات الـ 3D وآلات الـ CNC.
                • استخدام قناطر H-Bridge (مثل L298N أو دوائر الـ MOSFET) مع إشارة PWM للتحكم بالسرعة والاتجاه ثنائياً.
                
                4. نصائح للاختبارات ومعامل الجامعة الإماراتية الدولية (EIU Labs):
                • ركب دائماً صمام خمود (Flyback Diode) بالتوازي مع المحرك لحماية الترانزستورات من تيار الحث العكسي (Back-EMF) عند الإطفاء.
                • سؤال اختبار متكرر: ما الفرق الجوهري بين محرك السيرفو ومحرك الـ Stepper؟
                  (السيرفو حلقة مغلقة Closed-Loop، بينما الـ Stepper يعمل عادة حلقة مفتوحة Open-Loop بدقة خطوة ثابتة).
                
                5. تحدي دكتور الميكاترونكس السريع 🚀:
                محرك خطوة بزاوية 1.8 درجة لكل خطوة (1.8°/step)، متصل بصندوق تروس بنسبة 1:5. كم نبضة يحتاجها المتحكم لتدوير عمود الخرج النهائي دورة كاملة 360°؟
            """.trimIndent()

            else -> """
                🎓 شرح دكتور الميكاترونكس لمحاضرة اليوم
                الموضوع: ${if (topicText.isNotBlank()) topicText else "الدرس المسجل بالوسائط الهندسية"}
                ($mediaText)
                
                1. الفكرة الجوهرية وشرح الدرس المبسط (Core Concept):
                يركز هذا الدرس على إحدى الركائز التطبيقية في هندسة الميكاترونكس، حيث يتم الدمج المتناغم بين الأنظمة الميكانيكية والدوائر الإلكترونية وبرمجيات التحكم الذكية لإنتاج منظومة ذاتية الحركة والاستشعار.
                
                2. القوانين والمعادلات الرياضية والفيزيائية (Governing Formulas):
                • معادلات الديناميكا والحركة:
                  F = m · a   |   T = J · α   |   v = ω · r
                • معادلات الدوائر الكهربائية والإشارات:
                  V = I · R   |   P = V · I   |   τ = R · C
                • أبعاد الوحدات الأساسية [M L T I]:
                  - القوة: [M L T⁻²] (نيوتن N)
                  - الشغل والطاقة: [M L² T⁻²] (جول J)
                  - الجهد الكهربائي: [M L² T⁻³ I⁻¹] (فولت V)
                
                3. التطبيق العملي في أنظمة الميكاترونكس والروبوتات:
                • استخدام الحساسات المناسبة (Sensors) لقراءة المتغيرات الفيزيائية وتحويلها إلى جهد رقمي.
                • برمجة المعالج الدقيق (Microcontroller / PLC) لمعالجة الإشارة وفق خوارزميات التحكم المنطقي.
                • إرسال إشارات القيادة إلى المشغلات (Actuators) لتحريك الأذرع، الصمامات الهيدروليكية، أو عجلات الروبوت.
                
                4. نصائح للاختبارات ومعامل الجامعة الإماراتية الدولية (EIU Labs):
                • عند حل المسائل الامتحانية، ابدأ دائماً برسم مخطط الجسم الحر (Free-Body Diagram) للجانب الميكانيكي ومخطط الدائرة للجانب الكهربائي.
                • تأكد دائماً من مطابقة الواحدات (SI Units) والأبعاد الفيزيائية قبل التعويض في المعادلات.
                
                5. تحدي مهندس الميكاترونكس 🚀:
                كيف يمكنك توظيف الذكاء الاصطناعي ومتحكمات الـ Embedded Systems لتحسين كفاءة واستجابة هذا النظام في مواجهة الاضطرابات الخارجية؟
            """.trimIndent()
        }
    }
}
