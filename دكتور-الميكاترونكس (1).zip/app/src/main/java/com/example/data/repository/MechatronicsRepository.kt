package com.example.data.repository

import com.example.data.db.BookmarkedLessonEntity
import com.example.data.db.MechatronicsDao
import com.example.data.db.SavedSummaryEntity
import com.example.data.db.StudentProfileEntity
import kotlinx.coroutines.flow.Flow

class MechatronicsRepository(private val dao: MechatronicsDao) {

    val studentProfile: Flow<StudentProfileEntity?> = dao.getStudentProfile()
    val summaries: Flow<List<SavedSummaryEntity>> = dao.getAllSummaries()
    val bookmarks: Flow<List<BookmarkedLessonEntity>> = dao.getAllBookmarks()

    suspend fun saveProfile(profile: StudentProfileEntity) {
        dao.saveStudentProfile(profile)
    }

    suspend fun activateSubscription(
        studentName: String,
        studentId: String,
        studentPhone: String,
        paymentMethod: String,
        transactionNumber: String
    ) {
        val now = System.currentTimeMillis()
        val oneMonthMillis = 30L * 24 * 60 * 60 * 1000
        val profile = StudentProfileEntity(
            id = 1,
            studentName = studentName,
            studentId = studentId,
            studentPhone = studentPhone,
            paymentMethod = paymentMethod,
            transactionNumber = transactionNumber,
            isSubscribed = true,
            subscriptionDate = now,
            subscriptionExpireDate = now + oneMonthMillis
        )
        dao.saveStudentProfile(profile)
    }

    suspend fun resetSubscription() {
        val profile = StudentProfileEntity(
            id = 1,
            studentName = "مهندس ميكاترونكس",
            studentId = "EIU-2026-MCE",
            studentPhone = "",
            paymentMethod = "محفظة جيب",
            transactionNumber = "",
            isSubscribed = false,
            subscriptionDate = 0L,
            subscriptionExpireDate = 0L
        )
        dao.saveStudentProfile(profile)
    }

    suspend fun extendSubscription(days: Int = 30) {
        val now = System.currentTimeMillis()
        val addMillis = days.toLong() * 24 * 60 * 60 * 1000
        val profile = StudentProfileEntity(
            id = 1,
            studentName = "مهندس ميكاترونكس",
            studentId = "EIU-2026-MCE",
            studentPhone = "",
            paymentMethod = "محفظة جيب",
            transactionNumber = "TXN-RENEWED",
            isSubscribed = true,
            subscriptionDate = now,
            subscriptionExpireDate = now + addMillis
        )
        dao.saveStudentProfile(profile)
    }

    suspend fun saveSummary(title: String, type: String, snippet: String, result: String): Long {
        return dao.insertSummary(
            SavedSummaryEntity(
                title = title,
                type = type,
                originalSnippet = snippet,
                summaryResult = result
            )
        )
    }

    suspend fun deleteSummary(id: Long) {
        dao.deleteSummary(id)
    }

    suspend fun toggleBookmark(lessonId: String, subjectId: String, yearId: Int, title: String, arabicTitle: String, currentlyBookmarked: Boolean) {
        if (currentlyBookmarked) {
            dao.removeBookmark(lessonId)
        } else {
            dao.insertBookmark(
                BookmarkedLessonEntity(
                    lessonId = lessonId,
                    subjectId = subjectId,
                    yearId = yearId,
                    title = title,
                    arabicTitle = arabicTitle
                )
            )
        }
    }

    fun isBookmarked(lessonId: String): Flow<Boolean> = dao.isBookmarked(lessonId)
}
