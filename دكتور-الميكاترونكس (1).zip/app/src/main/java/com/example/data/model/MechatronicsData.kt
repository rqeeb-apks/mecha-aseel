package com.example.data.model

data class AcademicYear(
    val id: Int,
    val title: String,
    val englishTitle: String,
    val description: String,
    val subjects: List<Subject>
)

data class Subject(
    val id: String,
    val name: String,
    val englishName: String,
    val code: String,
    val iconName: String,
    val description: String,
    val lessons: List<Lesson>
)

data class Lesson(
    val id: String,
    val title: String,
    val arabicTitle: String,
    val summary: String,
    val fullContent: String,
    val keyFormulas: List<String>,
    val practicalExample: String,
    val eiuLabTip: String
)

data class PhysicalDimension(
    val nameAr: String,
    val nameEn: String,
    val symbol: String,
    val dimensionFormula: String,
    val siUnit: String,
    val derivation: String,
    val mechatronicsApplication: String
)

enum class DimensionCategory(val titleAr: String, val titleEn: String) {
    ALL("الكل", "All"),
    MECHANICS("الميكانيكا والحركة", "Mechanics"),
    ELECTRICAL("الكهرباء والدوائر", "Electrical"),
    MAGNETISM("الكهرومغناطيسية", "Electromagnetism"),
    FLUIDS("الموائع والهيدروليك", "Fluids & Hydraulics"),
    THERMAL("الحرارة والطاقة", "Thermal & Energy")
}

data class MechatronicsReferenceItem(
    val id: String,
    val nameAr: String,
    val nameEn: String,
    val symbol: String,
    val category: DimensionCategory,
    val dimensionFormula: String,
    val siUnit: String,
    val siBreakdown: String,
    val commonConversions: List<String>,
    val definingLaw: String,
    val mechatronicsApplication: String
)

data class SIBaseUnitItem(
    val quantityAr: String,
    val quantityEn: String,
    val dimensionSymbol: String,
    val unitNameAr: String,
    val unitSymbol: String,
    val standardDefinition: String
)

data class EngineeringPrefixItem(
    val prefixName: String,
    val prefixAr: String,
    val symbol: String,
    val multiplierText: String,
    val factor: Double
)

data class UnitCategory(
    val id: String,
    val nameAr: String,
    val nameEn: String,
    val baseUnit: String,
    val units: List<ConversionUnit>
)

data class ConversionUnit(
    val name: String,
    val symbol: String,
    val factorToBase: Double // Multiply value by this to get base unit
)

object MechatronicsCurriculum {
    val universityName = "الجامعة الإماراتية الدولية - صنعاء"
    val facultyName = "كلية الهندسة وتكنولوجيا المعلومات - قسم هندسة الميكاترونكس"
    val subscriptionFee = "10 ريال يمني شهرياً"
    val paymentNumber = "6710654"

    val academicYears: List<AcademicYear> = listOf(
        AcademicYear(
            id = 1,
            title = "السنة الأولى (الإعدادي الهندسي)",
            englishTitle = "First Year (Engineering Fundamentals)",
            description = "الأسس الرياضية والفيزيائية والكهربائية المشتركة لمهندس الميكاترونكس",
            subjects = listOf(
                Subject(
                    id = "math1",
                    name = "الرياضيات الهندسية 1 و 2",
                    englishName = "Engineering Mathematics I & II",
                    code = "ENG101",
                    iconName = "Calculate",
                    description = "التفاضل والتكامل، المتجهات، المصفوفات، والأعداد المركبة وتطبيقاتها في الميكاترونكس",
                    lessons = listOf(
                        Lesson(
                            id = "m1_1",
                            title = "Vectors & Dot/Cross Products",
                            arabicTitle = "المتجهات وحساب العزوم وحواصل الضرب",
                            summary = "تمثيل القوى والعزوم في الفضاء ثلاثي الأبعاد وهو أساس الروبوتات والتحليل الميكانيكي.",
                            fullContent = """
                                المتجهات هي الركيزة الأساسية في دراسة علم حركيات الروبوتات والميكانيكا الهندسية.
                                
                                • الضرب القياسي (Dot Product):
                                A · B = |A| |B| cos(θ) = AxBx + AyBy + AzBz
                                يُستخدم لتحديد الزاوية بين قوتين أو حساب الشغل المبذول W = F · d.
                                
                                • الضرب الاتجاهي (Cross Product):
                                A × B = |A| |B| sin(θ) n̂
                                يُستخدم لحساب عزم القوة (Torque) حول نقطة: τ = r × F
                                
                                • متجهات الوحدة (Unit Vectors):
                                i, j, k تمثل المحاور الكارتيزية X, Y, Z.
                            """.trimIndent(),
                            keyFormulas = listOf("W = F · d = |F||d| cos(θ)", "τ = r × F", "|A| = √(Ax² + Ay² + Az²)"),
                            practicalExample = "ذراع روبوت في معمل الجامعة الإماراتية: تؤثر قوة F = [10, -5, 20] N عند إحداثيات r = [0.2, 0.4, 0] m. عزم الدوران = r × F = [8, -4, -5] N·m.",
                            eiuLabTip = "في معمل الروبوتات، تأكد دائماً من قاعدة اليد اليمنى لحساب اتجاه دوران محركات السيرفو."
                        ),
                        Lesson(
                            id = "m1_2",
                            title = "Calculus & Rate of Change",
                            arabicTitle = "التفاضل والتكامل وعلاقة الإزاحة والسرعة والتسارع",
                            summary = "دراسة تغير الإشارات، وتحليل مسار المحركات في أنظمة الميكاترونكس.",
                            fullContent = """
                                العلاقة التكاملية والتفاضلية في الحركة الميكانيكية:
                                • الإزاحة x(t)
                                • السرعة v(t) = dx/dt
                                • التسارع a(t) = dv/dt = d²x/dt²
                                
                                وفي الدوائر الكهربائية:
                                • تيار المكثف: i(t) = C · (dv/dt)
                                • جهد المحث: v(t) = L · (di/dt)
                            """.trimIndent(),
                            keyFormulas = listOf("v = dx/dt", "a = dv/dt", "i_C = C(dv/dt)", "v_L = L(di/dt)"),
                            practicalExample = "إذا كان مسار المحرك x(t) = 3t² + 2t، فإن السرعة عند t=2s هي v = 6(2) + 2 = 14 m/s والتسارع ثابت 6 m/s².",
                            eiuLabTip = "تطبيق عملي: تفاضل الإشارة في خوارزمية PID يمثل الجزء الاشتقاقي D لمنع تجاوز الهدف (Overshoot)."
                        )
                    )
                ),
                Subject(
                    id = "circuits1",
                    name = "أسس الهندسة الكهربائية والدوائر DC",
                    englishName = "Electrical Circuits & DC Analysis",
                    code = "MCE102",
                    iconName = "Bolt",
                    description = "قوانين كيرشوف، نظريات ثيفنن ونورتون، تحليل العقد والمش، وقوانين أوم وتوليد القدرة",
                    lessons = listOf(
                        Lesson(
                            id = "c1_1",
                            title = "Ohm's & Kirchhoff's Laws",
                            arabicTitle = "قوانين أوم وكيرشوف (KCL & KVL)",
                            summary = "القواعد الأساسية لتحليل أي دائرة إلكترونية أو ميكاترونية وتوزيع التيارات والجهود.",
                            fullContent = """
                                قانون أوم:
                                الجهد الكهربائي بين طرفي موصل يتناسب طردياً مع شدة التيار المار فيه عند ثبوت درجة الحرارة:
                                V = I × R
                                
                                قانون كيرشوف للتيار (KCL):
                                مجموع التيارات الداخلة إلى أي عقدة كهربائية (Node) يساوي مجموع التيارات الخارجة منها:
                                Σ I_in = Σ I_out
                                
                                قانون كيرشوف للجهد (KVL):
                                المجموع الجبري لفروق الجهد الكهربائي حول أي مسار مغلق (Loop) يساوي صفراً:
                                Σ V = 0
                            """.trimIndent(),
                            keyFormulas = listOf("V = I · R", "P = V · I = I²R = V²/R", "Σ I_node = 0", "Σ V_loop = 0"),
                            practicalExample = "تغذية حساس ميكاتروني 5V يسحب تيار 50mA عبر مقاومة لحمايته: R = V/I = 5 / 0.05 = 100 Ω. والقدرة المبددة P = 0.25 W.",
                            eiuLabTip = "في معمل الدوائر، تأكد من وضع طرفي الأفوميتر على التوالي لقياس التيار، وعلى التوازي لقياس الجهد حتى لا يتلف المصهر (Fuse)."
                        ),
                        Lesson(
                            id = "c1_2",
                            title = "Thevenin & Norton Equivalent Circuits",
                            arabicTitle = "نظريات ثيفنن ونورتون لتبسيط الدوائر",
                            summary = "تبسيط الدوائر الكهربائية المعقدة إلى مصدر جهد ومقاومة توالي واحدة لتسهيل حساب الحمل.",
                            fullContent = """
                                تتيح نظرية ثيفنن استبدال أي شبكة خطية ثنائية الأطراف بدائرة مكافئة تتكون من:
                                1. مصدر جهد Vth (جهد الدائرة المفتوحة بين طرفي الحمل).
                                2. مقاومة ثيفنن Rth (المقاومة المكافئة عند إخماد جميع المصادر المستقلة).
                                
                                الاستفادة في الميكاترونكس:
                                تحديد أقصى قدرة يمكن نقلها إلى محرك أو مشغل كهروميكانيكي (Maximum Power Transfer):
                                R_load = R_th
                            """.trimIndent(),
                            keyFormulas = listOf("V_th = V_open_circuit", "R_th = V_oc / I_sc", "P_max = V_th² / (4 R_th)"),
                            practicalExample = "عند توصيل بطارية الروبوت ذات المقاومة الداخلية 0.5Ω مع المحرك، يتم سحب أقصى قدرة عندما تكون مقاومة ملفات المحرك مساوية 0.5Ω.",
                            eiuLabTip = "استخدم مقاومة متغيرة Potentiometer في التجربة للتحقق من قمة منحنى القدرة العظمى."
                        )
                    )
                ),
                Subject(
                    id = "prog1",
                    name = "برمجة C/C++ للمهندسين",
                    englishName = "C/C++ Programming for Engineers",
                    code = "MCE103",
                    iconName = "Code",
                    description = "لغة سي التأسيسية لكتابة برامج الأنظمة المدمجة ومتحكمات الأردوينو والميكروكنترولر",
                    lessons = listOf(
                        Lesson(
                            id = "p1_1",
                            title = "C Syntax & Microcontroller Registers",
                            arabicTitle = "أساسيات لغة C والعمليات الثنائية (Bitwise Ops)",
                            summary = "التحكم في البتات والمنافذ الرقمية والمدخلات والمخرجات في الأنظمة المدمجة.",
                            fullContent = """
                                في هندسة الميكاترونكس، نستخدم العمليات الثنائية للتحكم المباشر في سجلات المعالج (Registers):
                                • ضبط بت إلى 1 (Set Bit): PORTB |= (1 << 3);
                                • تصفير بت إلى 0 (Clear Bit): PORTB &= ~(1 << 3);
                                • عكس بت (Toggle Bit): PORTB ^= (1 << 3);
                                • فحص حالة بت: if (PINB & (1 << 2)) { ... }
                            """.trimIndent(),
                            keyFormulas = listOf("PORTB |= (1 << n)", "PORTB &= ~(1 << n)", "PORTB ^= (1 << n)"),
                            practicalExample = "تشغيل صمام هيدروليكي موصول بالبت رقم 4: PORTD |= (1 << 4);",
                            eiuLabTip = "في مشاريع الجامعة الإماراتية، يفضل دائماً استخدام العمليات المباشرة على البتات بدلاً من الدوال الجاهزة لأنها أسرع بعشرات المرات."
                        )
                    )
                )
            )
        ),
        AcademicYear(
            id = 2,
            title = "السنة الثانية (الأنظمة التماثلية والميكانيكية)",
            englishTitle = "Second Year (Analog & Mechanical Systems)",
            description = "تعميق الإلكترونيات، الرياضيات المتقدمة، وميكانيكا المواد والموائع",
            subjects = listOf(
                Subject(
                    id = "math2",
                    name = "المعادلات التفاضلية وتحويلات لابلاس",
                    englishName = "Differential Equations & Laplace Transforms",
                    code = "MCE201",
                    iconName = "Functions",
                    description = "نمذجة الأنظمة الديناميكية وتحويلها من المجال الزمني إلى المجال الترددي S-Domain",
                    lessons = listOf(
                        Lesson(
                            id = "m2_1",
                            title = "Laplace Transform in Mechatronics",
                            arabicTitle = "تحويل لابلاس ونمذجة الأنظمة الديناميكية",
                            summary = "تحويل المعادلات التفاضلية الصعبة إلى معادلات جبرية بسيطة تمهيداً لبناء دوال التحويل.",
                            fullContent = """
                                يُعرف تحويل لابلاس بالصيغة:
                                L{f(t)} = F(s) = ∫₀^∞ f(t) e^(-st) dt
                                
                                تحويلات شائعة:
                                • المشتقة الأولى: L{dy/dt} = s Y(s) - y(0)
                                • المشتقة الثانية: L{d²y/dt²} = s² Y(s) - s y(0) - y'(0)
                                • دالة الخطوة Unit Step: 1/s
                                • الدالة الأسية e^(at): 1 / (s - a)
                                
                                دالة التحويل (Transfer Function):
                                G(s) = Output(s) / Input(s)
                            """.trimIndent(),
                            keyFormulas = listOf("L{f'(t)} = sF(s) - f(0)", "G(s) = Y(s) / X(s)", "s = σ + jω"),
                            practicalExample = "دائرة RC مع جهد دخل Vi وخرج عبر المكثف Vo: المعادلة R C (dVo/dt) + Vo = Vi، تتحول إلى (sRC + 1) Vo(s) = Vi(s)، وبالتالي G(s) = 1 / (sRC + 1).",
                            eiuLabTip = "في برنامج MATLAB / Simulink في معمل الحاسوب، استخدم أمر tf([1], [R*C 1]) لتمثيل الدالة مباشرة."
                        )
                    )
                ),
                Subject(
                    id = "electronics",
                    name = "الإلكترونيات ومكبرات العمليات (Op-Amps)",
                    englishName = "Analog Electronics & Operational Amplifiers",
                    code = "MCE202",
                    iconName = "Memory",
                    description = "الدايود، الترانزستور BJT و MOSFET، ومكبرات العمليات ودوائر تكبير ومعالجة إشارات الحساسات",
                    lessons = listOf(
                        Lesson(
                            id = "e2_1",
                            title = "Operational Amplifiers (Op-Amps)",
                            arabicTitle = "مكبر العمليات ومواءمة إشارات الحساسات",
                            summary = "المكبر المثالي وخصائصه، وتطبيقات العاكس وغير العاكس والتفاضلي لتهيئة إشارة الحساسات.",
                            fullContent = """
                                خصائص مكبر العمليات المثالي (Ideal Op-Amp):
                                1. مقاومة دخل لانهائية Rin = ∞ (لا يسحب تيار في الأطراف: I+ = I- = 0).
                                2. كسب جهد لانهائي في الحلقة المفتوحة Aol = ∞ (الجهد V+ = V-).
                                3. مقاومة خرج معدومة Rout = 0.
                                
                                التكوينات الرئيسية:
                                • المكبر العاكس (Inverting Amplifier):
                                Vout = - (Rf / Rin) × Vin
                                
                                • المكبر غير العاكس (Non-Inverting Amplifier):
                                Vout = (1 + Rf / R1) × Vin
                                
                                • تابع الجهد (Buffer / Voltage Follower):
                                Vout = Vin (يمنع تأثير الحمل Loading Effect على الحساسات ذات المقاومة العالية).
                            """.trimIndent(),
                            keyFormulas = listOf("Av = - Rf / Rin", "Av = 1 + (Rf / R1)", "V_diff = (Rf/R1)(V2 - V1)"),
                            practicalExample = "حساس حرارة Thermocouple يخرج 10mV. نريد تكبيره إلى 1V لقراءته بالـ ADC: نحتاج كسب Av = 100. باستخدام مكبر غير عاكس: 100 = 1 + Rf/R1 -> Rf = 99 kΩ و R1 = 1 kΩ.",
                            eiuLabTip = "تأكد من استخدام مكبر LM358 أو LM741 مع جهد تغذية ثنائي مناسب، أو استخدام مكبر أحادي التغذية Rail-to-Rail للحساسات الحديثة."
                        ),
                        Lesson(
                            id = "e2_2",
                            title = "Transistors as Switches & Motor Drivers",
                            arabicTitle = "الترانزستور كمفتاح وقائد للأحمال والمحركات",
                            summary = "استخدام BJT و MOSFET لتشغيل الريليهات ومحركات الـ DC من مخارج الميكروكنترولر 5V / 3.3V.",
                            fullContent = """
                                لا تستطيع مخارج الميكروكنترولر تزويد تيار كافٍ لتشغيل المحركات (حدها الأقصى 20-40mA).
                                لذلك نستخدم MOSFET كمفتاح إلكتروني:
                                • في منطقة القطع (Cutoff): Vgs < Vth، المفتاح مفتوح (I_D = 0).
                                • في منطقة التشبع/المقاومة الخطية: Vgs > Vth، المفتاح مغلق وتيار الحمل يمر بكفاءة عالية.
                                
                                دايود الحماية (Flyback / Freewheeling Diode):
                                يوضع بالتوازي وعكس قطبية ملف المحرك أو الريلاي لامتصاص الجهد الحثي العالي العكسي V = -L (di/dt) عند الإطفاء وحماية الترانزستور من الاحتراق.
                            """.trimIndent(),
                            keyFormulas = listOf("I_D = K(V_gs - V_th)²", "V_spike = - L (di/dt)", "P_loss = I_D² × R_DS(on)"),
                            practicalExample = "تشغيل صمام هيدروليكي 12V 1A بواسطة الأردوينو: نستخدم N-Channel MOSFET (مثل IRFZ44N) ومقاومة بوابة 220Ω ودايود 1N4007 لحماية الدائرة.",
                            eiuLabTip = "احرص دائماً على وجود دايود الحماية Flyback Diode فوق أي حمل حثي (موتور أو ريلاي) في مشاريع التخرج."
                        )
                    )
                ),
                Subject(
                    id = "mechanics",
                    name = "ميكانيكا المواد والآلات",
                    englishName = "Mechanics of Materials & Machine Dynamics",
                    code = "MCE203",
                    iconName = "Build",
                    description = "الإجهاد والانفعال، عزم القصور الذاتي، ونقل الحركة بالتروس والسيور",
                    lessons = listOf(
                        Lesson(
                            id = "mech_1",
                            title = "Stress, Strain & Gear Ratios",
                            arabicTitle = "الإجهاد والانفعال ونسب تخفيض التروس",
                            summary = "حسابات التحمل الميكانيكي ومضاعفة العزم والسرعة في مفاصل الروبوت.",
                            fullContent = """
                                الإجهاد الميكانيكي (Stress σ):
                                σ = F / A (يقاس بالباسكال N/m² أو MPa)
                                
                                قانون هوك:
                                σ = E × ε (حيث E معامل المرونة و ε الانفعال النسبي)
                                
                                نسبة التخفيض في التروس (Gear Ratio i):
                                i = N2 / N1 = ω1 / ω2 = τ2 / τ1
                                حيث N عدد الأسنان، ω السرعة الزاوية، و τ عزم الدوران.
                                عند تخفيض السرعة بنسبة 10:1، يتضاعف العزم 10 مرات!
                            """.trimIndent(),
                            keyFormulas = listOf("σ = F / A", "i = N_out / N_in", "τ_out = i × τ_in × η"),
                            practicalExample = "محرك سيرفو عزم دورانه 0.5 N·m وسرعته 1000 RPM متصل بصندوق تروس نسبته 10:1 بكفاءة 90%: العزم الناتج = 10 × 0.5 × 0.9 = 4.5 N·m والسرعة 100 RPM.",
                            eiuLabTip = "في تصميم الأذرع الميكانيكية، احسب دائماً معامل الأمان (Factor of Safety FOS) ليكون بين 1.5 إلى 2.5."
                        )
                    )
                )
            )
        ),
        AcademicYear(
            id = 3,
            title = "السنة الثالثة (التحكم والمتحكمات والمشغلات)",
            englishTitle = "Third Year (Control, Embedded & Actuators)",
            description = "جوهر هندسة الميكاترونكس: التحكم الآلي PID، الأردوينو والميكروكنترولر، الحساسات والمشغلات الهيدروليكية",
            subjects = listOf(
                Subject(
                    id = "control",
                    name = "أنظمة التحكم الآلي ونظرية التحكم",
                    englishName = "Automatic Control Systems & PID",
                    code = "MCE301",
                    iconName = "Tune",
                    description = "المخططات الصندوقية، استقرار روت-هورفيتز، ومتحكم التناسب والتكامل والتفاضل PID",
                    lessons = listOf(
                        Lesson(
                            id = "ctrl_1",
                            title = "PID Controller Design & Tuning",
                            arabicTitle = "تصميم وضبط متحكم PID التناسبي التكاملي التفاضلي",
                            summary = "أكثر خوارزميات التحكم انتشاراً عالمياً للتحكم في سرعة المحركات والحرارة ومواضع الروبوت بدقة.",
                            fullContent = """
                                معادلة متحكم PID في المجال الزمني:
                                u(t) = Kp · e(t) + Ki · ∫ e(t) dt + Kd · (de(t)/dt)
                                
                                وفي مجال لابلاس S-Domain:
                                C(s) = Kp + Ki/s + Kd · s
                                
                                وظائف الأجزاء الثلاثة:
                                1. الحد التناسبي (Kp): يستجيب للخطأ اللحظي؛ زيادته تسرع استجابة النظام لكنها قد تسبب تذبذباً (Overshoot).
                                2. الحد التكاملي (Ki): يجمع الخطأ التراكمي عبر الزمن؛ يزيل الخطأ في الحالة المستقرة (Steady-state error) نهائياً.
                                3. الحد الاشتقاقي (Kd): يستشعر معدل تغير الخطأ؛ يعمل كمكبح تخميد (Damping) للحد من التجاوز والتذبذب.
                            """.trimIndent(),
                            keyFormulas = listOf("u(t) = Kp e + Ki ∫e dt + Kd (de/dt)", "e(t) = Setpoint - Feedback", "C(s) = Kp + Ki/s + Kd s"),
                            practicalExample = "التحكم في توازن روبوت ثنائي العجلات (Self-balancing Robot): زاوية الميلان الحالية 5 درجات، يطبق Kp قوة سريعة، و Kd يقاوم السقوط السريع، و Ki يضمن الوقوف العمودي التام 0 درجة.",
                            eiuLabTip = "في معمل التحكم بالجامعة الإماراتية، ابدأ دائماً بضبط Kp حتى يبدأ النظام بالتذبذب، ثم أضف Kd لتثبيته، وأخيراً أضف Ki قليلاً لإزالة أي فارق دائم."
                        )
                    )
                ),
                Subject(
                    id = "microcontrollers",
                    name = "المتحكمات الدقيقة والأنظمة المدمجة",
                    englishName = "Microcontrollers & Embedded Systems",
                    code = "MCE302",
                    iconName = "DeveloperBoard",
                    description = "برمجة Arduino و STM32 و PIC، الموقتات، المقاطعات (Interrupts)، ومنافذ الاتصال UART/I2C/SPI",
                    lessons = listOf(
                        Lesson(
                            id = "uc_1",
                            title = "Interrupts & Timers / PWM",
                            arabicTitle = "المقاطعات البرمجية وتوليد نبضات PWM للتحكم بالمحركات",
                            summary = "الاستجابة الفورية لحساسات الطوارئ وتوليد إشارات التعديل العرضي للنبضة PWM.",
                            fullContent = """
                                تعديل عرض النبضة (PWM - Pulse Width Modulation):
                                طريقة لتوليد جهد تماثلي مكافئ عبر تشغيل وإطفاء المفتاح بسرعة فائقة.
                                نسبة التشغيل (Duty Cycle D):
                                D = (T_on / T_total) × 100%
                                الجهد المتوسط الناتج:
                                V_avg = D × V_max
                                
                                المقاطعات الخارجية (Hardware Interrupts):
                                إيقاف البرنامج الرئيسي فوراً عند حدوث حدث فيزيائي حرج (مثل ضغط زر طوارئ أو وصول إنكودر المحرك إلى نقطة معينة) عبر دالة ISR (Interrupt Service Routine).
                            """.trimIndent(),
                            keyFormulas = listOf("Duty Cycle % = (Ton / T) × 100", "V_avg = D × V_in", "Freq = 1 / T"),
                            practicalExample = "تغذية محرك DC بجهد 12V عبر دائرة H-Bridge (L298N). عندما نرسل PWM بقيمة 128 من أصل 255 (Duty 50%)، يكون الجهد المتوسط المطبق 6V ويدور المحرك بنصف سرعته القصوى.",
                            eiuLabTip = "لا تضع أبداً أوامر delay() أو دوال إرسال تسلسلي طويلة Serial.print داخل دالة المقاطعة ISR في الميكروكنترولر."
                        )
                    )
                ),
                Subject(
                    id = "sensors",
                    name = "الحساسات والمشغلات الكهروميكانيكية",
                    englishName = "Sensors & Actuators in Mechatronics",
                    code = "MCE303",
                    iconName = "Sensors",
                    description = "حساسات الضوء والحرارة والقرب، المشفرات البصرية Encoders، محركات الخطوة Stepper والمؤازرة Servo",
                    lessons = listOf(
                        Lesson(
                            id = "sens_1",
                            title = "Optical Encoders & Stepper Motors",
                            arabicTitle = "مشفرات الموضع (Encoders) ومحركات الخطوة (Stepper)",
                            summary = "قياس موضع وسرعة المفاصل بدقة فائقة وحساب زوايا الخطوة.",
                            fullContent = """
                                المشفر البصري التربيعي (Quadrature Optical Encoder):
                                يولد نبضتين متأخرتين بزاوية 90 درجة كهربائياً (قناة A وقناة B).
                                معرفة اتجاه الدوران:
                                • إذا كانت القناة A تسبق B -> دوران باتجاه عقارب الساعة (CW).
                                • إذا كانت القناة B تسبق A -> دوران عكس عقارب الساعة (CCW).
                                
                                محرك الخطوة (Stepper Motor):
                                يتحرك بزوايا محددة مسبقاً (Step Angle θ):
                                θ = 360° / عدد الخطوات الكلية (مثلاً 200 خطوة = 1.8° لكل خطوة).
                                التقطيع الدقيق (Microstepping):
                                تقسيم الخطوة الواحدة إلى 1/4 أو 1/16 أو 1/32 لحركة ناعمة جداً في الطابعات ثلاثية الأبعاد وماكينات CNC.
                            """.trimIndent(),
                            keyFormulas = listOf("Step Angle = 360° / Steps_per_rev", "Speed (RPM) = (Pulse_Freq × 60) / Steps", "Resolution = 4 × Pulses_per_rev"),
                            practicalExample = "محرك خطوة بزاوية 1.8 درجة لكل خطوة نحتاج تدويره 90 درجة: عدد النبضات المطلوبة = 90 / 1.8 = 50 نبضة.",
                            eiuLabTip = "في مشغل A4988 أو TMC2208، اضبط مقاومة VREF بدقة لتحديد أقصى تيار للمحرك وتجنب سخونة الملفات."
                        )
                    )
                )
            )
        ),
        AcademicYear(
            id = 4,
            title = "السنة الرابعة (الروبوتات والأنظمة الذكية والتخرج)",
            englishTitle = "Fourth Year (Robotics, PLC & Smart Industry)",
            description = "الحركيات المباشرة والعكسية، التحكم المنطقي الصناعي PLC، والذكاء الاصطناعي ومشاريع التخرج",
            subjects = listOf(
                Subject(
                    id = "robotics",
                    name = "حركيات وديناميكا الروبوتات",
                    englishName = "Robotics: Kinematics & Dynamics",
                    code = "MCE401",
                    iconName = "SmartToy",
                    description = "مصفوفات التحويل المتجانسة، بارامترات دنافيت-هارتنبرغ (DH Parameters)، والحركيات الأمامية والعكسية",
                    lessons = listOf(
                        Lesson(
                            id = "rob_1",
                            title = "DH Parameters & Forward Kinematics",
                            arabicTitle = "بارامترات دنفيت-هارتنبرغ (DH) وحساب موضع المستجيب النهائي",
                            summary = "تحديد موقع واتجاه قابض الروبوت أو الأداة في الفضاء بناءً على زوايا المفاصل.",
                            fullContent = """
                                بارامترات DH الأربعة لكل مفصل:
                                1. طول الرابط (Link Length a_i): المسافة على طول المحور x_i.
                                2. زاوية التواء الرابط (Link Twist α_i): الزاوية حول المحور x_i.
                                3. إزاحة الرابط (Link Offset d_i): المسافة على طول المحور z_(i-1).
                                4. زاوية المفصل (Joint Angle θ_i): الزاوية حول المحور z_(i-1).
                                
                                مصفوفة التحويل المتجانسة (Homogeneous Transformation Matrix T):
                                تدمج مصفوفة الدوران 3x3 ومتجه الإزاحة 3x1 في مصفوفة 4x4 واحدة.
                                T_total = T0_1 × T1_2 × T2_3 ... × T(n-1)_n
                            """.trimIndent(),
                            keyFormulas = listOf("T = [R, P; 0, 1]", "X = L1 cos(θ1) + L2 cos(θ1+θ2)", "Y = L1 sin(θ1) + L2 sin(θ1+θ2)"),
                            practicalExample = "ذراع مستوية ثنائية الوصلات بطول L1=20cm و L2=15cm وزوايا θ1=30° و θ2=45°: إحداثيات المستجيب النهائي: X = 20 cos(30) + 15 cos(75) = 21.2 cm، و Y = 20 sin(30) + 15 sin(75) = 24.5 cm.",
                            eiuLabTip = "في مشاريع التخرج بالجامعة الإماراتية، يتم فحص مصفوفات جاكوبيان (Jacobian) لتجنب النقاط المفردة (Singularities) التي تفقد فيها الذراع درجة من درجات الحرية."
                        )
                    )
                ),
                Subject(
                    id = "plc",
                    name = "التحكم المنطقي القابل للبرمجة (PLC & SCADA)",
                    englishName = "Programmable Logic Controllers (PLC)",
                    code = "MCE402",
                    iconName = "PrecisionManufacturing",
                    description = "مخططات السلم (Ladder Diagram)، التحكم بالخطوط الإنتاجية، وشاشات HMI وبروتوكولات Modbus",
                    lessons = listOf(
                        Lesson(
                            id = "plc_1",
                            title = "Ladder Logic & Industrial Automation",
                            arabicTitle = "برمجة لغة السلم (Ladder Diagram) ومؤقتات وعدادات PLC",
                            summary = "التحكم في خطوط الإنتاج والمصانع وحماية الأنظمة الصناعية.",
                            fullContent = """
                                المكونات الأساسية لمخطط السلم (Ladder Logic):
                                • التماسات المفتوحة طبيعياً (NO Contact --| |--): تصبح مغلقة عند وصول إشارة 24V.
                                • التماسات المغلقة طبيعياً (NC Contact --|/|--): تنفتح عند وصول الإشارة (تستخدم لأزرار الطوارئ Stop).
                                • ملف الخرج (Coil --( )--): يشغل الصمام أو الكونتاكتور.
                                
                                دائرة الإمساك الذاتي (Latch / Self-holding Circuit):
                                إبقاء المحرك أو خط الإنتاج في وضع التشغيل بعد الضغط على زر Start اللحظي عبر وضع تماس الخرج بالتوازي مع زر التشغيل.
                            """.trimIndent(),
                            keyFormulas = listOf("Output = (Start OR Output) AND (NOT Stop)", "TON (Timer On-Delay)", "CTU (Count Up)"),
                            practicalExample = "تشغيل سير ناقل لنقل قوارير العصير: حساس وجود العلبة يفعل المؤقت TON لمدة 3 ثوانٍ لتعبئة السائل، ثم يتم تشغيل السير لنقل العلبة التالية.",
                            eiuLabTip = "في معمل الـ PLC، تأكد دائماً من أن أسلاك الـ E-Stop مربوطة عتادياً كـ NC لضمان أمان أرواح المشغلين في حال انقطاع السلك."
                        )
                    )
                )
            )
        )
    )

    val physicalDimensions: List<PhysicalDimension> = listOf(
        PhysicalDimension(
            nameAr = "القوة الميكانيكية",
            nameEn = "Force",
            symbol = "F",
            dimensionFormula = "[M L T⁻²]",
            siUnit = "نيوتن (N) = kg·m/s²",
            derivation = "من قانون نيوتن الثاني: F = m · a = [M] · [L T⁻²] = [M L T⁻²]",
            mechatronicsApplication = "حساب قوى دفع المكابس الهيدروليكية وعزم محركات أذرع الروبوت."
        ),
        PhysicalDimension(
            nameAr = "الضغط والإجهاد",
            nameEn = "Pressure & Stress",
            symbol = "P, σ",
            dimensionFormula = "[M L⁻¹ T⁻²]",
            siUnit = "باسكال (Pa) = N/m²",
            derivation = "P = F / A = [M L T⁻²] / [L²] = [M L⁻¹ T⁻²]",
            mechatronicsApplication = "مراقبة ضغط الزيت في الأنظمة الهيدروليكية وضغط الهواء في خطوط النيوماتيك."
        ),
        PhysicalDimension(
            nameAr = "الطاقة والشغل الميكانيكي",
            nameEn = "Energy & Work",
            symbol = "E, W",
            dimensionFormula = "[M L² T⁻²]",
            siUnit = "جول (J) = N·m = kg·m²/s²",
            derivation = "W = F · d = [M L T⁻²] · [L] = [M L² T⁻²]",
            mechatronicsApplication = "حساب استهلاك الطاقة لبطاريات الروبوتات والأنظمة الذكية المتنقلة."
        ),
        PhysicalDimension(
            nameAr = "القدرة الميكانيكية والكهربائية",
            nameEn = "Power",
            symbol = "P",
            dimensionFormula = "[M L² T⁻³]",
            siUnit = "واط (W) = J/s",
            derivation = "P = W / t = [M L² T⁻²] / [T] = [M L² T⁻³]",
            mechatronicsApplication = "تحديد قدرة المحركات الكهربائية والمحولات واختيار مصادر التغذية SMPS."
        ),
        PhysicalDimension(
            nameAr = "عزم الدوران",
            nameEn = "Torque",
            symbol = "τ",
            dimensionFormula = "[M L² T⁻²]",
            siUnit = "نيوتن · متر (N·m)",
            derivation = "τ = r × F = [L] · [M L T⁻²] = [M L² T⁻²] (طاقة بعدياً لكن كمية متجهة)",
            mechatronicsApplication = "المحدد الرئيسي لاختيار محركات السيرفو ومحركات الخطوة في المفاصل الميكانيكية."
        ),
        PhysicalDimension(
            nameAr = "الجهد الكهربائي (فرق الجهد)",
            nameEn = "Electric Potential / Voltage",
            symbol = "V",
            dimensionFormula = "[M L² T⁻³ I⁻¹]",
            siUnit = "فولت (V) = W / A",
            derivation = "V = P / I = [M L² T⁻³] / [I] = [M L² T⁻³ I⁻¹]",
            mechatronicsApplication = "تغذية الدوائر المنطقية ومكبرات الإشارة وتوصيل حساسات الـ Analog بالـ ADC."
        ),
        PhysicalDimension(
            nameAr = "المقاومة الكهربائية",
            nameEn = "Electrical Resistance",
            symbol = "R",
            dimensionFormula = "[M L² T⁻³ I⁻²]",
            siUnit = "أوم (Ω) = V / A",
            derivation = "R = V / I = [M L² T⁻³ I⁻¹] / [I] = [M L² T⁻³ I⁻²]",
            mechatronicsApplication = "مقاومات تحديد التيار، مقسمات الجهد للحساسات، ومقاومات السحب Pull-up."
        ),
        PhysicalDimension(
            nameAr = "السعة الكهربائية",
            nameEn = "Capacitance",
            symbol = "C",
            dimensionFormula = "[M⁻¹ L⁻² T⁴ I²]",
            siUnit = "فاراد (F) = C / V",
            derivation = "C = Q / V = [I T] / [M L² T⁻³ I⁻¹] = [M⁻¹ L⁻² T⁴ I²]",
            mechatronicsApplication = "مرشحات تنقية إشارات الحساسات وفصل الضوضاء في مصادر التغذية Decoupling."
        ),
        PhysicalDimension(
            nameAr = "المحاثة الكهرومغناطيسية",
            nameEn = "Inductance",
            symbol = "L",
            dimensionFormula = "[M L² T⁻² I⁻²]",
            siUnit = "هنري (H) = V·s / A",
            derivation = "L = V / (di/dt) = [M L² T⁻³ I⁻¹] · [T] / [I] = [M L² T⁻² I⁻²]",
            mechatronicsApplication = "ملفات المحركات الحثية، محولات الفولتية Buck/Boost، وفلاتر الترددات العالية."
        ),
        PhysicalDimension(
            nameAr = "التردد",
            nameEn = "Frequency",
            symbol = "f",
            dimensionFormula = "[T⁻¹]",
            siUnit = "هيرتز (Hz) = 1/s",
            derivation = "f = 1 / T = [T⁻¹]",
            mechatronicsApplication = "ترددات نبضات الـ PWM، تردد ساعة المعالج Clock، ومعدل أخذ العينات Sampling."
        ),
        PhysicalDimension(
            nameAr = "اللزوجة الديناميكية",
            nameEn = "Dynamic Viscosity",
            symbol = "μ, η",
            dimensionFormula = "[M L⁻¹ T⁻¹]",
            siUnit = "باسكال · ثانية (Pa·s)",
            derivation = "μ = τ / (du/dy) = [M L⁻¹ T⁻²] / [T⁻¹] = [M L⁻¹ T⁻¹]",
            mechatronicsApplication = "اختيار زيت الهيدروليك المناسب في مكابس ومضخات الأنظمة الميكاترونية."
        )
    )

    val unitCategories: List<UnitCategory> = listOf(
        UnitCategory(
            id = "pressure",
            nameAr = "الضغط والإجهاد",
            nameEn = "Pressure",
            baseUnit = "Pa",
            units = listOf(
                ConversionUnit("باسكال (Pascal)", "Pa", 1.0),
                ConversionUnit("كيلو باسكال (Kilopascal)", "kPa", 1000.0),
                ConversionUnit("ميجاباسكال (Megapascal)", "MPa", 1000000.0),
                ConversionUnit("بار (Bar)", "bar", 100000.0),
                ConversionUnit("رطل/بوصة مربعة (PSI)", "psi", 6894.76),
                ConversionUnit("ضغط جوي (Atmosphere)", "atm", 101325.0),
                ConversionUnit("ملم زئبق (mmHg)", "mmHg", 133.322)
            )
        ),
        UnitCategory(
            id = "force",
            nameAr = "القوة الميكانيكية",
            nameEn = "Force",
            baseUnit = "N",
            units = listOf(
                ConversionUnit("نيوتن (Newton)", "N", 1.0),
                ConversionUnit("كيلو نيوتن (Kilonewton)", "kN", 1000.0),
                ConversionUnit("داين (Dyne)", "dyn", 1e-5),
                ConversionUnit("كيلوجرام قوة (kgf)", "kgf", 9.80665),
                ConversionUnit("رطل قوة (lbf)", "lbf", 4.44822)
            )
        ),
        UnitCategory(
            id = "torque",
            nameAr = "عزم الدوران",
            nameEn = "Torque",
            baseUnit = "N·m",
            units = listOf(
                ConversionUnit("نيوتن · متر (N·m)", "N·m", 1.0),
                ConversionUnit("نيوتن · سم (N·cm)", "N·cm", 0.01),
                ConversionUnit("كيلوجرام قوة · متر (kgf·m)", "kgf·m", 9.80665),
                ConversionUnit("رطل · قدم (lbf·ft)", "lbf·ft", 1.35582),
                ConversionUnit("أونصة · بوصة (oz·in)", "oz·in", 0.00706155)
            )
        ),
        UnitCategory(
            id = "power",
            nameAr = "القدرة",
            nameEn = "Power",
            baseUnit = "W",
            units = listOf(
                ConversionUnit("واط (Watt)", "W", 1.0),
                ConversionUnit("كيلو واط (Kilowatt)", "kW", 1000.0),
                ConversionUnit("حصان ميكانيكي (hp)", "hp", 745.7),
                ConversionUnit("حصان متري (cv)", "cv", 735.5),
                ConversionUnit("BTU لكل ساعة", "BTU/h", 0.293071)
            )
        ),
        UnitCategory(
            id = "energy",
            nameAr = "الطاقة والشغل",
            nameEn = "Energy",
            baseUnit = "J",
            units = listOf(
                ConversionUnit("جول (Joule)", "J", 1.0),
                ConversionUnit("كيلو جول (Kilojoule)", "kJ", 1000.0),
                ConversionUnit("سعر حراري (Calorie)", "cal", 4.184),
                ConversionUnit("كيلوواط · ساعة (kWh)", "kWh", 3600000.0),
                ConversionUnit("إلكترون فولت (eV)", "eV", 1.60218e-19)
            )
        )
    )

    val siBaseUnitsList: List<SIBaseUnitItem> = listOf(
        SIBaseUnitItem("الطول (المسافة)", "Length", "[L]", "متر", "m", "المسافة التي يقطعها الضوء في الفراغ خلال 1/299,792,458 ثانية"),
        SIBaseUnitItem("الكتلة", "Mass", "[M]", "كيلوجرام", "kg", "محددة بالقيمة العددية الثابتة لثابت بلانك h = 6.62607015×10⁻³⁴"),
        SIBaseUnitItem("الزمن", "Time", "[T]", "ثانية", "s", "مدة 9,192,631,770 دورة إشعاعية لانتقال ذرة السيزيوم 133"),
        SIBaseUnitItem("التيار الكهربائي", "Electric Current", "[I] / [A]", "أمبير", "A", "محدد بالقيمة الثابتة للشحنة الأولية e = 1.602176634×10⁻¹⁹ C"),
        SIBaseUnitItem("درجة الحرارة الديناميكية", "Thermodynamic Temperature", "[Θ]", "كلفن", "K", "محددة بثابت بولتزمان k = 1.380649×10⁻²³ J/K"),
        SIBaseUnitItem("كمية المادة", "Amount of Substance", "[N]", "مول", "mol", "يحتوي على 6.02214076×10²³ كيان أولي (عدد أفوغادرو)"),
        SIBaseUnitItem("شدة الإضاءة", "Luminous Intensity", "[J]", "شمعة", "cd", "شدة إضاءة مصدر أحادي التردد (540×10¹² Hz) في اتجاه معين")
    )

    val engineeringPrefixesList: List<EngineeringPrefixItem> = listOf(
        EngineeringPrefixItem("Giga", "جيجا", "G", "10⁹ (مليار)", 1e9),
        EngineeringPrefixItem("Mega", "ميجا", "M", "10⁶ (مليون)", 1e6),
        EngineeringPrefixItem("Kilo", "كيلو", "k", "10³ (ألف)", 1e3),
        EngineeringPrefixItem("Milli", "ملي", "m", "10⁻³ (جزء من ألف)", 1e-3),
        EngineeringPrefixItem("Micro", "ميكرو", "μ", "10⁻⁶ (جزء من مليون)", 1e-6),
        EngineeringPrefixItem("Nano", "نانو", "n", "10⁻⁹ (جزء من مليار)", 1e-9),
        EngineeringPrefixItem("Pico", "بيكو", "p", "10⁻¹² (جزء من تريليون)", 1e-12)
    )

    val mechatronicsReferenceTable: List<MechatronicsReferenceItem> = listOf(
        MechatronicsReferenceItem(
            id = "force",
            nameAr = "القوة الميكانيكية",
            nameEn = "Force",
            symbol = "F",
            category = DimensionCategory.MECHANICS,
            dimensionFormula = "[M L T⁻²]",
            siUnit = "نيوتن (N)",
            siBreakdown = "kg·m/s²",
            commonConversions = listOf(
                "1 N = 10⁵ dyn",
                "1 kgf = 9.80665 N ≈ 9.81 N",
                "1 lbf = 4.4482 N",
                "1 kN = 1,000 N"
            ),
            definingLaw = "F = m · a = dp/dt",
            mechatronicsApplication = "حساب قوى دفع أسطوانات النيوماتيك والهيدروليك، معايرة خلايا الحمل (Load Cells)، وحساب قوى دفع المحركات الخطية."
        ),
        MechatronicsReferenceItem(
            id = "torque",
            nameAr = "عزم الدوران",
            nameEn = "Torque",
            symbol = "τ, T",
            category = DimensionCategory.MECHANICS,
            dimensionFormula = "[M L² T⁻²]",
            siUnit = "نيوتن · متر (N·m)",
            siBreakdown = "kg·m²/s²",
            commonConversions = listOf(
                "1 N·m = 100 N·cm",
                "1 kgf·m = 9.80665 N·m",
                "1 lbf·ft = 1.3558 N·m",
                "1 N·m = 141.6 oz·in"
            ),
            definingLaw = "τ = r × F = I · α = P / ω",
            mechatronicsApplication = "المحدد الأساسي لاختيار محركات السيرفو (Servo Motors) ومحركات الخطوة (Stepper) ونسب تخفيض صناديق التروس لمفاصل الروبوت."
        ),
        MechatronicsReferenceItem(
            id = "pressure",
            nameAr = "الضغط والإجهاد",
            nameEn = "Pressure & Stress",
            symbol = "P, σ",
            category = DimensionCategory.FLUIDS,
            dimensionFormula = "[M L⁻¹ T⁻²]",
            siUnit = "باسكال (Pa)",
            siBreakdown = "N/m² = kg/(m·s²)",
            commonConversions = listOf(
                "1 bar = 10⁵ Pa = 0.1 MPa",
                "1 MPa = 10 bar = 1 N/mm²",
                "1 atm = 101.325 kPa = 1.013 bar",
                "1 psi = 6.895 kPa (1 bar ≈ 14.5 psi)",
                "1 bar = 750 mmHg"
            ),
            definingLaw = "P = F / A | σ = E · ε",
            mechatronicsApplication = "شبكات الهواء المضغوط للنيوماتيك (6 إلى 8 bar)، والضغوط العالية في وحدات القدرة الهيدروليكية HPU (حتى 250 bar)، وحساسات الضغط الكهروضغطية."
        ),
        MechatronicsReferenceItem(
            id = "power",
            nameAr = "القدرة الميكانيكية والكهربائية",
            nameEn = "Power",
            symbol = "P",
            category = DimensionCategory.THERMAL,
            dimensionFormula = "[M L² T⁻³]",
            siUnit = "واط (W)",
            siBreakdown = "J/s = kg·m²/s³",
            commonConversions = listOf(
                "1 kW = 1,000 W",
                "1 hp (ميكانيكي) = 745.7 W",
                "1 hp (متري) = 735.5 W",
                "1 kW = 1.341 hp",
                "1 BTU/h = 0.293 W"
            ),
            definingLaw = "P = τ · ω = V · I = F · v",
            mechatronicsApplication = "تحديد استطاعة المحركات الحثية ومحركات الـ BLDC، وتصميم دوائر التغذية SMPS وحساب تشتت الحرارة في ترانزستورات MOSFET."
        ),
        MechatronicsReferenceItem(
            id = "energy",
            nameAr = "الشغل والطاقة",
            nameEn = "Work & Energy",
            symbol = "W, E",
            category = DimensionCategory.THERMAL,
            dimensionFormula = "[M L² T⁻²]",
            siUnit = "جول (J)",
            siBreakdown = "N·m = kg·m²/s²",
            commonConversions = listOf(
                "1 kJ = 1,000 J",
                "1 kWh = 3.6 × 10⁶ J (3.6 MJ)",
                "1 cal = 4.184 J",
                "1 eV = 1.602 × 10⁻¹⁹ J"
            ),
            definingLaw = "W = ∫ F · dx = ½ m v² = ½ C V²",
            mechatronicsApplication = "حساب السعة التخزينية لبطاريات الروبوتات المتحركة (AGVs)، وحساب استهلاك القدرة اللحظية أثناء تسارع وتباطؤ المحركات."
        ),
        MechatronicsReferenceItem(
            id = "voltage",
            nameAr = "الجهد الكهربائي (فرق الجهد)",
            nameEn = "Voltage / Electric Potential",
            symbol = "V, U",
            category = DimensionCategory.ELECTRICAL,
            dimensionFormula = "[M L² T⁻³ I⁻¹]",
            siUnit = "فولت (V)",
            siBreakdown = "W/A = kg·m²/(s³·A)",
            commonConversions = listOf(
                "1 kV = 1,000 V",
                "1 mV = 10⁻³ V",
                "1 μV = 10⁻⁶ V"
            ),
            definingLaw = "V = I · R = P / I = -L (di/dt)",
            mechatronicsApplication = "معايرة مستويات الإشارة المنطقية (TTL 5V, CMOS 3.3V, Industrial PLC 24V DC)، وقراءة إشارات الحساسات التماثلية عبر ADC."
        ),
        MechatronicsReferenceItem(
            id = "resistance",
            nameAr = "المقاومة الكهربائية",
            nameEn = "Electrical Resistance",
            symbol = "R",
            category = DimensionCategory.ELECTRICAL,
            dimensionFormula = "[M L² T⁻³ I⁻²]",
            siUnit = "أوم (Ω)",
            siBreakdown = "V/A = kg·m²/(s³·A²)",
            commonConversions = listOf(
                "1 kΩ = 10³ Ω",
                "1 MΩ = 10⁶ Ω",
                "1 mΩ = 10⁻³ Ω"
            ),
            definingLaw = "R = ρ · (L / A) = V / I",
            mechatronicsApplication = "مقاومات تحديد التيار، مقاومات السحب (Pull-up/Pull-down) في مداخل المتحكمات، وقناطر ويتستون مع حساسات الانفعال Strain Gauges."
        ),
        MechatronicsReferenceItem(
            id = "capacitance",
            nameAr = "السعة الكهربائية",
            nameEn = "Capacitance",
            symbol = "C",
            category = DimensionCategory.ELECTRICAL,
            dimensionFormula = "[M⁻¹ L⁻² T⁴ I²]",
            siUnit = "فاراد (F)",
            siBreakdown = "C/V = s⁴·A²/(kg·m²)",
            commonConversions = listOf(
                "1 mF = 10⁻³ F",
                "1 μF = 10⁻⁶ F",
                "1 nF = 10⁻⁹ F",
                "1 pF = 10⁻¹² F"
            ),
            definingLaw = "C = ε · (A / d) = Q / V | i = C (dv/dt)",
            mechatronicsApplication = "مكثفات الترشيح وفصل الضوضاء (Decoupling) بجوار المتحكمات، ودوائر توقيت 555 ومكثفات دوائر تعويض معامل القدرة للمحركات."
        ),
        MechatronicsReferenceItem(
            id = "inductance",
            nameAr = "المحاثة الكهرومغناطيسية",
            nameEn = "Inductance",
            symbol = "L",
            category = DimensionCategory.MAGNETISM,
            dimensionFormula = "[M L² T⁻² I⁻²]",
            siUnit = "هنري (H)",
            siBreakdown = "V·s/A = kg·m²/(s²·A²)",
            commonConversions = listOf(
                "1 H = 1,000 mH",
                "1 mH = 10⁻³ H",
                "1 μH = 10⁻⁶ H"
            ),
            definingLaw = "v_L = L · (di/dt) | E_L = ½ L I²",
            mechatronicsApplication = "ملفات محركات التيار المستمر والخطوة، محولات التردد VFD، ودايودات الحماية من القوة الدافعة الكهربائية العكسية (Flyback Diode)."
        ),
        MechatronicsReferenceItem(
            id = "magnetic_b",
            nameAr = "كثافة الفيض المغناطيسي (المجال)",
            nameEn = "Magnetic Flux Density (B-Field)",
            symbol = "B",
            category = DimensionCategory.MAGNETISM,
            dimensionFormula = "[M T⁻² I⁻¹]",
            siUnit = "تسلا (T)",
            siBreakdown = "Wb/m² = N/(A·m) = kg/(s²·A)",
            commonConversions = listOf(
                "1 T = 10,000 Gauss (G)",
                "1 mT = 10 Gauss",
                "1 Gauss = 10⁻⁴ T"
            ),
            definingLaw = "F = q (v × B) = I (L × B)",
            mechatronicsApplication = "حساسات تأثير هول (Hall Effect) لقياس موضع وزاوية عمود الدوران في محركات BLDC والمشفرات المغناطيسية."
        ),
        MechatronicsReferenceItem(
            id = "magnetic_flux",
            nameAr = "الفيض المغناطيسي",
            nameEn = "Magnetic Flux",
            symbol = "Φ",
            category = DimensionCategory.MAGNETISM,
            dimensionFormula = "[M L² T⁻² I⁻¹]",
            siUnit = "ويبر (Wb)",
            siBreakdown = "V·s = kg·m²/(s²·A)",
            commonConversions = listOf(
                "1 Wb = 10⁸ Maxwell (Mx)",
                "1 Wb = 1 T·m²"
            ),
            definingLaw = "Φ = ∫ B · dA | e = -N (dΦ/dt)",
            mechatronicsApplication = "قانون فاراداي لتوليد القوة الدافعة الكهربائية في المولدات ومراقبة Back-EMF لتحديد سرعة محركات بدون فرش (Sensorless BLDC)."
        ),
        MechatronicsReferenceItem(
            id = "angular_velocity",
            nameAr = "السرعة الزاوية",
            nameEn = "Angular Velocity",
            symbol = "ω",
            category = DimensionCategory.MECHANICS,
            dimensionFormula = "[T⁻¹]",
            siUnit = "راديان / ثانية (rad/s)",
            siBreakdown = "1/s (rad هي نسبة مجردة)",
            commonConversions = listOf(
                "1 RPM = (2π / 60) rad/s ≈ 0.10472 rad/s",
                "1 rad/s = 9.5493 RPM",
                "1 rps = 60 RPM = 2π rad/s ≈ 6.283 rad/s",
                "1 rad/s = 57.296 deg/s"
            ),
            definingLaw = "ω = dθ/dt = 2π f = v / r",
            mechatronicsApplication = "حساب سرعات محركات الروبوت عبر الـ Encoders، ونقل الحركة، ومعادلات السرعة الخطية لمركبات AGV المستقلة."
        ),
        MechatronicsReferenceItem(
            id = "angular_accel",
            nameAr = "التسارع الزاوي",
            nameEn = "Angular Acceleration",
            symbol = "α",
            category = DimensionCategory.MECHANICS,
            dimensionFormula = "[T⁻²]",
            siUnit = "راديان / ثانية² (rad/s²)",
            siBreakdown = "1/s²",
            commonConversions = listOf(
                "1 rad/s² = 9.5493 RPM/s",
                "1 rev/s² = 2π rad/s² ≈ 6.283 rad/s²"
            ),
            definingLaw = "α = dω/dt = d²θ/dt² = τ / I",
            mechatronicsApplication = "تخطيط منحنيات الحركة الميكاترونية (S-Curve & Trapezoidal Trajectories) لمنع الاهتزازات الميكانيكية المفاجئة في الأذرع الصناعية."
        ),
        MechatronicsReferenceItem(
            id = "viscosity",
            nameAr = "اللزوجة الديناميكية",
            nameEn = "Dynamic Viscosity",
            symbol = "μ, η",
            category = DimensionCategory.FLUIDS,
            dimensionFormula = "[M L⁻¹ T⁻¹]",
            siUnit = "باسكال · ثانية (Pa·s)",
            siBreakdown = "kg/(m·s) = N·s/m²",
            commonConversions = listOf(
                "1 Pa·s = 10 Poise (P)",
                "1 Pa·s = 1,000 Centipoise (cP)",
                "1 cP = 1 mPa·s = 10⁻³ Pa·s"
            ),
            definingLaw = "τ = μ · (du/dy)",
            mechatronicsApplication = "اختيار زيت الهيدروليك المناسب لمعامل ومضخات الجامعة (مثل ISO VG 32 و VG 46) لضمان استقرار حركة الصمامات التناسبية."
        ),
        MechatronicsReferenceItem(
            id = "flow_rate",
            nameAr = "معدل التدفق الحجمي",
            nameEn = "Volumetric Flow Rate",
            symbol = "Q_v, Q",
            category = DimensionCategory.FLUIDS,
            dimensionFormula = "[L³ T⁻¹]",
            siUnit = "متر مكعب / ثانية (m³/s)",
            siBreakdown = "m³/s",
            commonConversions = listOf(
                "1 L/min (LPM) = 1.667 × 10⁻⁵ m³/s",
                "1 m³/h = 16.667 L/min",
                "1 GPM (US) = 3.785 L/min",
                "1 m³/s = 60,000 L/min"
            ),
            definingLaw = "Q = A · v = V_disp · N",
            mechatronicsApplication = "حساب سرعة حركة وتمدد المكابس الهيدروليكية v = Q / A، وحساب تدفق الهواء المطلوب لخطوط الإنتاج الأوتوماتيكية."
        ),
        MechatronicsReferenceItem(
            id = "young_modulus",
            nameAr = "معامل المرونة (معامل يونغ)",
            nameEn = "Modulus of Elasticity (Young's)",
            symbol = "E",
            category = DimensionCategory.MECHANICS,
            dimensionFormula = "[M L⁻¹ T⁻²]",
            siUnit = "باسكال (Pa) أو جيجاباسكال (GPa)",
            siBreakdown = "N/m² = kg/(m·s²)",
            commonConversions = listOf(
                "1 GPa = 10⁹ Pa = 1,000 MPa",
                "الصلب الإنشائي ≈ 200 إلى 210 GPa",
                "سبائك الألومنيوم ≈ 69 إلى 72 GPa",
                "التيتانيوم ≈ 110 GPa"
            ),
            definingLaw = "E = σ / ε = (F / A) / (ΔL / L₀)",
            mechatronicsApplication = "حساب انحناء وتشوه وصلات أذرع الروبوتات عند حمل الأوزان القصوى، ومعايرة جسور قياس الانفعال."
        ),
        MechatronicsReferenceItem(
            id = "electric_charge",
            nameAr = "الشحنة الكهربائية",
            nameEn = "Electric Charge",
            symbol = "Q, q",
            category = DimensionCategory.ELECTRICAL,
            dimensionFormula = "[I T]",
            siUnit = "كولوم (C)",
            siBreakdown = "A·s",
            commonConversions = listOf(
                "1 mAh = 3.6 C",
                "1 Ah = 3,600 C",
                "شحنة الإلكترون e = 1.602 × 10⁻¹⁹ C"
            ),
            definingLaw = "Q = I · t = C · V",
            mechatronicsApplication = "سعة بطاريات الليثيوم (LiPo / LiFePO4) المستخدمة في الطائرات المسيرة والروبوتات الجوالة وحساب زمن التشغيل."
        ),
        MechatronicsReferenceItem(
            id = "frequency",
            nameAr = "التردد الزمني",
            nameEn = "Frequency",
            symbol = "f, ν",
            category = DimensionCategory.THERMAL,
            dimensionFormula = "[T⁻¹]",
            siUnit = "هيرتز (Hz)",
            siBreakdown = "1/s (دورة بالثانية)",
            commonConversions = listOf(
                "1 kHz = 10³ Hz",
                "1 MHz = 10⁶ Hz",
                "1 GHz = 10⁹ Hz"
            ),
            definingLaw = "f = 1 / T = ω / (2π)",
            mechatronicsApplication = "تردد كريستالة ساعة المتحكم (16MHz في Arduino، 72MHz في STM32)، وتردد الـ PWM للتحكم في سرعة محركات DC (10kHz - 25kHz)."
        ),
        MechatronicsReferenceItem(
            id = "conductivity",
            nameAr = "الموصلية الكهربائية",
            nameEn = "Electrical Conductivity",
            symbol = "σ, κ",
            category = DimensionCategory.ELECTRICAL,
            dimensionFormula = "[M⁻¹ L⁻³ T³ I²]",
            siUnit = "سيمنز / متر (S/m)",
            siBreakdown = "1/(Ω·m) = A²·s³/(kg·m³)",
            commonConversions = listOf(
                "النحاس النقي ≈ 5.96 × 10⁷ S/m",
                "الألومنيوم ≈ 3.77 × 10⁷ S/m",
                "الذهب ≈ 4.1 × 10⁷ S/m"
            ),
            definingLaw = "σ = 1 / ρ = J / E",
            mechatronicsApplication = "تصميم مسارات اللوحات المطبوعة PCB Trace وحساب مقاومة وهبوط الجهد في خطوط القدرة ذات التيارات العالية."
        ),
        MechatronicsReferenceItem(
            id = "specific_heat",
            nameAr = "السعة الحرارية النوعية",
            nameEn = "Specific Heat Capacity",
            symbol = "c, c_p",
            category = DimensionCategory.THERMAL,
            dimensionFormula = "[L² T⁻² Θ⁻¹]",
            siUnit = "جول / (كجم · كلفن) [J/(kg·K)]",
            siBreakdown = "m²/(s²·K)",
            commonConversions = listOf(
                "1 cal/(g·°C) = 4,184 J/(kg·K)",
                "الماء السائل ≈ 4,184 J/(kg·K)",
                "الألومنيوم ≈ 900 J/(kg·K)",
                "النحاس ≈ 385 J/(kg·K)"
            ),
            definingLaw = "Q = m · c · ΔT",
            mechatronicsApplication = "حساب الإجهاد الحراري والتبريد اللازم لمشتتات حرارة مشغلات المحركات (H-Bridge Drivers & Inverters) في الروبوتات."
        )
    )
}
