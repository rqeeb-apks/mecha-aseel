package com.example.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface MechatronicsDao {

    // Profile & Subscription
    @Query("SELECT * FROM student_profile WHERE id = 1 LIMIT 1")
    fun getStudentProfile(): Flow<StudentProfileEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveStudentProfile(profile: StudentProfileEntity)

    // Summaries
    @Query("SELECT * FROM saved_summaries ORDER BY timestamp DESC")
    fun getAllSummaries(): Flow<List<SavedSummaryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSummary(summary: SavedSummaryEntity): Long

    @Query("DELETE FROM saved_summaries WHERE id = :id")
    suspend fun deleteSummary(id: Long)

    // Bookmarks
    @Query("SELECT * FROM bookmarked_lessons ORDER BY savedAt DESC")
    fun getAllBookmarks(): Flow<List<BookmarkedLessonEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBookmark(bookmark: BookmarkedLessonEntity)

    @Query("DELETE FROM bookmarked_lessons WHERE lessonId = :lessonId")
    suspend fun removeBookmark(lessonId: String)

    @Query("SELECT EXISTS(SELECT 1 FROM bookmarked_lessons WHERE lessonId = :lessonId)")
    fun isBookmarked(lessonId: String): Flow<Boolean>
}
